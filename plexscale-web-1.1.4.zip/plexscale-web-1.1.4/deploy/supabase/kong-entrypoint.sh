#!/bin/sh
# Builds the Kong declarative config from kong.yml and the container environment, then starts Kong.
# Based on the official Supabase entrypoint, limited to the legacy HS256 API keys PlexScale uses.
set -eu
for v in SUPABASE_ANON_KEY SUPABASE_SERVICE_KEY SITE_URL; do
  eval "val=\${$v:-}"
  [ -n "$val" ] || { echo "kong-entrypoint: $v is not set" >&2; exit 1; }
done
# A user session JWT in Authorization passes through; otherwise the apikey becomes the bearer token.
export LUA_AUTH_EXPR="\$((headers.authorization ~= nil and headers.authorization:sub(1, 10) ~= 'Bearer sb_' and headers.authorization) or headers.apikey)"

# awk substitution keeps YAML quoting intact (see the official Supabase entrypoint).
awk '{
  result = ""
  rest = $0
  while (match(rest, /\$[A-Za-z_][A-Za-z_0-9]*/)) {
    varname = substr(rest, RSTART + 1, RLENGTH - 1)
    if (varname in ENVIRON) {
      result = result substr(rest, 1, RSTART - 1) ENVIRON[varname]
    } else {
      result = result substr(rest, 1, RSTART + RLENGTH - 1)
    }
    rest = substr(rest, RSTART + RLENGTH)
  }
  print result rest
}' /home/kong/temp.yml > "$KONG_DECLARATIVE_CONFIG"
chmod 600 "$KONG_DECLARATIVE_CONFIG"
exec /entrypoint.sh kong docker-start
