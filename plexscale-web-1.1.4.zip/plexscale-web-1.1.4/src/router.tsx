import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import { PageLoader } from "@/components/ui-px/Spinner";
import { getCspNonce } from "@/lib/csp-nonce";

export const getRouter = () => {
  // One client per request: a module-level QueryClient leaks cached data between SSR requests.
  const queryClient = new QueryClient();

  const nonce = getCspNonce();
  const router = createRouter({
    routeTree,
    // Every script the server renders carries this request's CSP nonce.
    ...(nonce ? { ssr: { nonce } } : {}),
    context: { queryClient },
    scrollRestoration: true,
    // Lets Query own freshness; set caching defaults on the QueryClient, not the router.
    defaultPreloadStaleTime: 0,
    // Same preloader everywhere while a page is loading.
    defaultPendingComponent: () => <PageLoader />,
    defaultPendingMs: 150,
    defaultPendingMinMs: 300,
  });

  return router;
};
