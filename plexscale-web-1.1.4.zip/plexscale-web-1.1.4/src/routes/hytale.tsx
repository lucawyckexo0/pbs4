import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/hytale")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "hytale");
    const from = fromLabel(plans);
    const title = "Hytale Server Hosting in India | PlexScale";
    const description = `Hytale servers from ${from} a month on AMD EPYC 7763 with NVMe storage, mods and plugins. INR pricing with GST included.`;
    return pageHead({
      path: "/hytale", title, description, image: "/og/hytale.jpg", imageAlt: "Hytale server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/hytale", name: "PlexScale Hytale server hosting", serviceType: "Game server hosting", description, image: "/og/hytale.jpg", plans }), breadcrumbLd([{ name: "Hytale server hosting", path: "/hytale" }])],
    });
  },
  component: () => (
    <GamePage game="hytale" name="Hytale" image={img.hytale} sub="Get your Hytale world online on tuned EPYC hardware, close to your players." software={["Hytale dedicated server","Custom mods","Plugins"]} faq={homeFaq} />
  ),
});
