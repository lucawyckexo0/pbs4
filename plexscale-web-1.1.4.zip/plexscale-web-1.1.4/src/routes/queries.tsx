import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FaqList, SupportCards } from "@/components/sections/common";
import { faqTabs } from "@/config/faq";
import { breadcrumbLd, faqLd, pageHead } from "@/lib/seo";

/** Every question shown in the tabs, once (some appear under more than one tab). */
function uniqueQuestions() {
  const seen = new Set<string>();
  return faqTabs.flatMap((t) => t.items).filter((it) => (seen.has(it.q) ? false : (seen.add(it.q), true)));
}

const title = "Hosting FAQ: Setup, Billing & Refunds | PlexScale";
const desc = "Answers about server setup, hardware, billing, renewals, refunds and support for PlexScale game servers, VPS and Discord bot hosting.";

export const Route = createFileRoute("/queries")({
  // FAQPage lives here only: this is the page that shows every question and answer.
  head: () => pageHead({ path: "/queries", title, description: desc, jsonLd: [faqLd(uniqueQuestions()), breadcrumbLd([{ name: "Queries", path: "/queries" }])] }),
  component: Faq,
});

function Faq() {
  return (
    <>
      <section className="section container-px">
        <p className="eyebrow">Queries</p>
        <h1 className="mt-3 text-4xl md:text-5xl">How can we help?</h1>
        <Tabs defaultValue="start" className="mt-10">
          <TabsList className="h-auto flex-wrap border border-steel bg-graphite p-1">
            {faqTabs.map((t) => (
              <TabsTrigger key={t.key} value={t.key} className="px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">{t.label}</TabsTrigger>
            ))}
          </TabsList>
          {faqTabs.map((t) => (
            <TabsContent key={t.key} value={t.key} forceMount className="mt-6 data-[state=inactive]:hidden"><FaqList items={t.items} /></TabsContent>
          ))}
        </Tabs>
      </section>
      <SupportCards />
    </>
  );
}
