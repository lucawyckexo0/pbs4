import { createFileRoute } from "@tanstack/react-router";
import { SupportOptions } from "@/components/sections/common";
import { site } from "@/config/site";
import { absoluteUrl, breadcrumbLd, ORG_ID, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/contact")({
  head: () => pageHead({
    path: "/contact",
    title: "Contact PlexScale Support | Tickets, Discord, Email",
    description: "Reach the PlexScale team with an on-site support ticket, on Discord or by email. Average response time is about 60 seconds.",
    jsonLd: [{ "@type": "ContactPage", name: "Contact PlexScale", url: absoluteUrl("/contact"), about: { "@id": ORG_ID } }, breadcrumbLd([{ name: "Contact", path: "/contact" }])],
  }),
  component: Contact,
});

function Contact() {
  return (
    <section className="section container-px">
      <p className="eyebrow">Contact</p>
      <h1 className="mt-3 text-4xl md:text-5xl">Talk to us</h1>
      <p className="mt-4 max-w-xl text-muted-foreground">{site.responseTime}. Signed-in customers can open a private support ticket right here on the site.</p>
      <h2 className="sr-only">Ways to reach PlexScale</h2>
      <SupportOptions className="mt-10" />
    </section>
  );
}
