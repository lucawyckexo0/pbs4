import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/counter-strike-2")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "cs2");
    const from = fromLabel(plans);
    const title = "Counter Strike 2 Server Hosting in India | PlexScale";
    const description = `CS2 servers from ${from} a month on AMD EPYC 7763 in Mumbai, Hyderabad, Dubai, Frankfurt and Virginia. Workshop maps and SourceMod. GST included.`;
    return pageHead({
      path: "/counter-strike-2", title, description, image: "/og/counter-strike-2.jpg", imageAlt: "Counter Strike 2 server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/counter-strike-2", name: "PlexScale Counter Strike 2 server hosting", serviceType: "Game server hosting", description, image: "/og/counter-strike-2.jpg", plans }), breadcrumbLd([{ name: "Counter Strike 2 server hosting", path: "/counter-strike-2" }])],
    });
  },
  component: () => (
    <GamePage game="cs2" name="Counter Strike 2" image={img.cs2} sub="Low latency CS2 servers in India and Asia for scrims, retakes and community nights." software={["Competitive","Retakes","Deathmatch","Workshop maps","SourceMod"]} faq={homeFaq} />
  ),
});
