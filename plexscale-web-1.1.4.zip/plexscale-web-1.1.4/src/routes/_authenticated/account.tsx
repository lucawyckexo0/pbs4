import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { btn } from "@/components/ui-px/btn";
import { useSignOut } from "@/hooks/use-session";
import { PageLoader } from "@/components/ui-px/Spinner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [
    { title: "Account | PlexScale" },
    { name: "description", content: "Your PlexScale profile, billing details and connected logins." },
    { property: "og:title", content: "Account | PlexScale" },
    { property: "og:description", content: "Profile, billing details and connected logins." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Account,
});

const fields = [
  ["display_name", "Display name"],
  ["billing_name", "Billing name"],
  ["billing_phone", "Phone"],
  ["billing_address", "Billing address"],
  ["gstin", "GSTIN (optional)"],
] as const;
type Form = Record<(typeof fields)[number][0], string>;

function Account() {
  const qc = useQueryClient();
  const signOut = useSignOut();
  const { data } = useQuery({
    queryKey: ["account"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return { user: null, profile: null };
      const { data: p } = await supabase.from("profiles").select("id, avatar_url, display_name, billing_name, billing_phone, billing_address, gstin, created_at").eq("id", u.user.id).maybeSingle();
      return { user: u.user, profile: p };
    },
  });
  const [form, setForm] = useState<Form>({ display_name: "", billing_name: "", billing_phone: "", billing_address: "", gstin: "" });
  useEffect(() => {
    if (data?.profile) setForm({ display_name: data.profile.display_name ?? "", billing_name: data.profile.billing_name ?? "", billing_phone: data.profile.billing_phone ?? "", billing_address: data.profile.billing_address ?? "", gstin: data.profile.gstin ?? "" });
  }, [data?.profile]);

  if (!data) return <PageLoader text="Loading your account" />;
  if (!data.user) return <section className="section container-px"><p className="text-muted-foreground">Sign in to view your account.</p></section>;
  const { user } = data;
  const avatar = data.profile?.avatar_url ?? (user.user_metadata?.['avatar_url'] as string | undefined);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const clean = Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim() || null])) as Record<keyof Form, string | null>;
    const { error } = await supabase.from("profiles").update({ ...clean, updated_at: new Date().toISOString() }).eq("id", user.id);
    if (error) toast.error("Could not save your details."); else { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["account"] }); }
  }

  return (
    <section className="section container-px max-w-3xl">
      <p className="eyebrow">Account</p>
      <h1 className="mt-3 text-4xl">Your account</h1>

      <div className="panel mt-10 flex items-center gap-5 p-6">
        {avatar ? <img src={avatar} alt="" className="size-14 rounded-full" referrerPolicy="no-referrer" /> : <div className="size-14 rounded-full bg-accent" />}
        <div className="flex-1">
          <p className="font-display text-lg">{form.display_name || user.email}</p>
          <p className="text-sm text-muted-foreground">{user.email} · member since {new Date(user.created_at).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}</p>
        </div>
        <button type="button" onClick={signOut} className={btn({ variant: "secondary" })}>Sign out</button>
      </div>

      <form onSubmit={save} className="panel mt-6 grid gap-4 p-6">
        <h2 className="text-xl">Profile and billing details</h2>
        {fields.map(([k, label]) => (
          <label key={k} className="grid gap-1 text-sm">
            <span className="text-muted-foreground">{label}</span>
            <input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} maxLength={k === "billing_address" ? 300 : 100} className="h-10 rounded-md border border-steel bg-transparent px-3" />
          </label>
        ))}
        <button className={`${btn()} w-fit`}>Save changes</button>
      </form>

      <div className="panel mt-6 p-6">
        <h2 className="text-xl">Connected logins</h2>
        <p className="mt-1 text-sm text-muted-foreground">You sign in with these. There is no password on your account.</p>
        <ul className="mt-4 space-y-2">
          {(user.identities ?? []).map((i) => (
            <li key={i.identity_id} className="flex justify-between rounded-md border border-steel px-4 py-3 text-sm">
              <span className="capitalize">{i.provider}</span>
              <span className="text-muted-foreground">{(i.identity_data?.['email'] as string | undefined) ?? "Connected"}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
