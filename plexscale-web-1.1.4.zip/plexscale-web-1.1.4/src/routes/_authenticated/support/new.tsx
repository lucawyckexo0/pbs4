import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { btn } from "@/components/ui-px/btn";
import { Spinner } from "@/components/ui-px/Spinner";
import { newTicketInput, ticketCategories, ticketPriorities } from "@/config/support";
import { productNames, type ProductKey } from "@/config/plans";
import { supabase } from "@/integrations/supabase/client";
import { createTicket } from "@/lib/support.functions";
import { getTurnstileConfig } from "@/lib/turnstile.functions";
import { TurnstileBox, type TurnstileHandle } from "@/components/security/TurnstileBox";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

type Search = { category?: string | undefined; orderId?: string | undefined };

export const Route = createFileRoute("/_authenticated/support/new")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    category: typeof s["category"] === "string" && ticketCategories.some((c) => c.key === s["category"]) ? s["category"] : undefined,
    orderId: typeof s["orderId"] === "string" && /^[0-9a-f-]{36}$/i.test(s["orderId"]) ? s["orderId"] : undefined,
  }),
  head: () => ({ meta: [
    { title: "Open a support ticket | PlexScale" },
    { name: "description", content: "Tell the PlexScale team what you need help with." },
    { property: "og:title", content: "Open a support ticket | PlexScale" },
    { property: "og:description", content: "Tell our team what you need help with." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
    { name: "robots", content: "noindex" },
  ] }),
  loader: () => getTurnstileConfig(),
  component: NewTicket,
});

const field = "w-full rounded-md border border-steel bg-ink px-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-azure focus:outline-none";

function NewTicket() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const create = useServerFn(createTicket);
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState(search.category ?? "technical");
  const [priority, setPriority] = useState("normal");
  const [orderId, setOrderId] = useState(search.orderId ?? "");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { siteKey } = Route.useLoaderData();
  const [token, setToken] = useState<string | null>(null);
  const [widgetError, setWidgetError] = useState(false);
  const turnstile = useRef<TurnstileHandle>(null);
  const { data: services } = useQuery({
    queryKey: ["ticket-services"],
    queryFn: async () => (await supabase.from("orders").select("id, server_name, plan_name, product, status").eq("kind", "new").not("paid_at", "is", null).order("created_at", { ascending: false }).limit(100)).data ?? [],
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!token) { setError("Please complete the security check."); return; }
    const input = { subject, category, priority, orderId, body, turnstileToken: token };
    const check = newTicketInput.safeParse(input);
    if (!check.success) { setError(check.error.issues[0]?.message ?? "Please check the form."); return; }
    // Tokens are single use: the next attempt needs a fresh one.
    turnstile.current?.reset();
    setBusy(true);
    try {
      const t = await create({ data: input });
      toast.success(`Ticket #${t.number} opened. We’ll email you when we reply.`);
      qc.invalidateQueries({ queryKey: ["my-tickets"] });
      navigate({ to: "/support/$ticketId", params: { ticketId: t.id } });
    } catch (err) {
      setError(shownError(err, "Could not open your ticket. Please try again."));
      setBusy(false);
    }
  }

  return (
    <section className="section container-px max-w-3xl">
      <Link to="/support" className={cn(btn({ variant: "text" }), "-ml-2")}><ArrowLeft />All tickets</Link>
      <h1 className="mt-4 text-4xl">Open a ticket</h1>
      <p className="mt-3 text-muted-foreground">Share as much detail as you can. Never include passwords.</p>
      <form onSubmit={submit} className="panel mt-8 grid gap-5 p-6">
        <label className="grid gap-1.5 text-sm">
          <span className="font-semibold">Subject</span>
          <input value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={120} required placeholder="My server won’t start after an update" className={cn(field, "h-11")} />
        </label>
        <div className="grid gap-5 sm:grid-cols-2">
          <label className="grid gap-1.5 text-sm">
            <span className="font-semibold">Category</span>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className={cn(field, "h-11")}>{ticketCategories.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}</select>
          </label>
          <label className="grid gap-1.5 text-sm">
            <span className="font-semibold">Priority</span>
            <select value={priority} onChange={(e) => setPriority(e.target.value)} className={cn(field, "h-11")}>{ticketPriorities.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}</select>
          </label>
        </div>
        <label className="grid gap-1.5 text-sm">
          <span className="font-semibold">Related service <span className="font-normal text-muted-foreground">(optional)</span></span>
          <select value={orderId} onChange={(e) => setOrderId(e.target.value)} className={cn(field, "h-11")}>
            <option value="">Not about a specific service</option>
            {(services ?? []).map((o) => <option key={o.id} value={o.id}>{o.server_name || o.plan_name} · {productNames[o.product as ProductKey] ?? o.product} · {o.status}</option>)}
          </select>
        </label>
        <label className="grid gap-1.5 text-sm">
          <span className="font-semibold">How can we help?</span>
          <textarea value={body} onChange={(e) => setBody(e.target.value)} maxLength={5000} rows={8} required placeholder="What happened, what you expected, and any error messages." className={cn(field, "py-3")} />
          <span className="text-xs text-muted-foreground">{body.length}/5000</span>
        </label>
        <div>
          {siteKey
            ? <TurnstileBox ref={turnstile} siteKey={siteKey} action="ticket" onToken={(t) => { setToken(t); if (t) setWidgetError(false); }} onError={() => setWidgetError(true)} />
            : <p className="text-xs text-destructive">New tickets are unavailable right now. Please try again later.</p>}
          {widgetError && <p className="mt-1 text-xs text-destructive">The security check could not load. Refresh the page and try again.</p>}
        </div>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <button type="submit" disabled={busy || !token} className={cn(btn({ size: "lg" }), "w-full sm:w-fit")}>{busy && <Spinner size="xs" />}{busy ? "Opening ticket" : "Open ticket"}</button>
      </form>
    </section>
  );
}
