import { createFileRoute, redirect } from "@tanstack/react-router";

// Old Discord shortcut. Sign-in always goes through /auth so the security check runs first.
export const Route = createFileRoute("/auth_/discord")({
  head: () => ({ meta: [
    { title: "Sign in with Discord | PlexScale" },
    { name: "description", content: "Discord sign-in for PlexScale accounts." },
    { property: "og:title", content: "Sign in with Discord | PlexScale" },
    { property: "og:description", content: "Discord sign-in for PlexScale accounts." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  beforeLoad: () => { throw redirect({ to: "/auth", replace: true }); },
});
