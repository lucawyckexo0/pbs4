import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

import "@fontsource-variable/sora";
import "@fontsource-variable/figtree";
import appCss from "../styles.css?url";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ConfirmHost } from "@/components/ui-px/ConfirmHost";
import { NotFound } from "@/components/layout/NotFound";
import { Toaster } from "@/components/ui/sonner";
import { Announcement } from "@/components/layout/Announcement";
import { supabase } from "@/integrations/supabase/client";
import { settingsQuery } from "@/lib/settings.functions";
import { ensureWelcome } from "@/lib/orders.functions";
import { MaintenanceScreen } from "@/components/layout/Maintenance";
import { useSettings } from "@/hooks/use-settings";
import { useIsAdmin, useUser } from "@/hooks/use-session";
import { installClientGuard } from "@/lib/client-guard";

function ErrorComponent({ reset }: ErrorComponentProps) {
  const router = useRouter();

  return (
    <section className="flex min-h-[70vh] items-center justify-center px-4 py-16">
      <div className="panel max-w-lg p-10 text-center">
        <p className="eyebrow">Something went wrong</p>
        <h1 className="mt-2 text-3xl">This page didn’t load</h1>
        <p className="mt-4 text-muted-foreground">We’re having trouble loading this page. Please try again in a moment.</p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Button onClick={() => { router.invalidate(); reset(); }}>Try again</Button>
          <Button asChild variant="secondary"><Link to="/">Return home</Link></Button>
        </div>
      </div>
    </section>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "PlexScale: Game Servers, VPS & Bot Hosting in India" },
      { name: "description", content: "Game servers, VPS and Discord bot hosting on AMD EPYC 7763 with NVMe storage. INR pricing, GST included." },
      { property: "og:title", content: "PlexScale: Game Servers, VPS & Bot Hosting in India" },
      { property: "og:description", content: "Tuned AMD EPYC hardware, NVMe storage and a team that replies in minutes." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "PlexScale" },
      { property: "og:locale", content: "en_IN" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#070b1a" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", type: "image/png", sizes: "32x32", href: "/favicon-32.png" },
      { rel: "icon", type: "image/png", sizes: "192x192", href: "/favicon.png" },
      { rel: "apple-touch-icon", sizes: "180x180", href: "/apple-touch-icon.png" },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(settingsQuery),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFound,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const hideFooter = useRouterState({ select: (st) => st.location.pathname.startsWith("/administrator") || st.location.pathname.startsWith("/auth") });
  const { queryClient } = Route.useRouteContext();
  const router = useRouter();
  useEffect(() => { installClientGuard(); }, []);
  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    try {
      const { data } = supabase.auth.onAuthStateChange((event, session) => {
        if (event === "SIGNED_IN" && session?.user) {
          // Welcome email: the server sends it at most once, only for brand new accounts.
          const key = `px-welcome-${session.user.id}`;
          if (!sessionStorage.getItem(key)) {
            sessionStorage.setItem(key, "1");
            void ensureWelcome().catch(() => sessionStorage.removeItem(key));
          }
        }
        if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
        router.invalidate();
        if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
      });
      unsubscribe = () => data.subscription.unsubscribe();
    } catch {
      // Public pages remain available if authentication is not configured.
    }
    return () => unsubscribe?.();
  }, [router, queryClient]);
  return (
    <QueryClientProvider client={queryClient}>
      <MaintenanceGate>
        <div className="flex min-h-screen flex-col">
          <Announcement />
          <Navbar />
          <main className="flex-1">
            {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
            <Outlet />
          </main>
          {hideFooter ? <p className="py-6 text-center text-xs text-muted-foreground">© PlexScale. All Rights Reserved.</p> : <Footer />}
        </div>
      </MaintenanceGate>
      <Toaster />
      <ConfirmHost />
    </QueryClientProvider>
  );
}

/** Locks every page for visitors and customers while maintenance is on. Only administrators get through. */
function MaintenanceGate({ children }: { children: ReactNode }) {
  const s = useSettings();
  const path = useRouterState({ select: (st) => st.location.pathname });
  const { user, ready } = useUser();
  const isAdmin = useIsAdmin(user?.id);
  if (!s.maintenance.enabled) return <>{children}</>;
  if (path === "/auth" || path.startsWith("/auth/")) return <>{children}</>;
  if (isAdmin) return <>{children}</>;
  return <MaintenanceScreen checking={!ready} />;
}
