import { createFileRoute } from "@tanstack/react-router";

// Uptime checks: 200 when the app and database answer. Returns no private data.
export const Route = createFileRoute("/api/public/health")({
  server: {
    handlers: {
      GET: async () => {
        const started = Date.now();
        let db = false;
        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { error } = await supabaseAdmin.from("site_settings").select("id").eq("id", 1).maybeSingle();
          db = !error;
        } catch { db = false; }
        return Response.json({ ok: db, db, ms: Date.now() - started }, { status: db ? 200 : 503, headers: { "cache-control": "no-store" } });
      },
    },
  },
});
