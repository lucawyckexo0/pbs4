import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { NotFound } from "@/components/layout/NotFound";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { getAdminMe } from "@/lib/admin.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/administrator")({
  ssr: false,
  head: () => ({ meta: [
    { title: "Administration | PlexScale" },
    { name: "description", content: "Private PlexScale service administration." },
    { property: "og:title", content: "Administration | PlexScale" },
    { property: "og:description", content: "Private PlexScale service administration." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex, nofollow" },
  ] }),
  component: Admin,
});

// Non-admins see a normal 404 so the page's existence is not revealed. Every action is re-checked on the server.
function Admin() {
  const me = useServerFn(getAdminMe);
  const { data, isLoading } = useQuery({
    queryKey: ["admin-gate"],
    queryFn: async () => {
      const { data: s } = await supabase.auth.getSession();
      if (!s.session) return { isAdmin: false };
      try { return await me(); } catch { return { isAdmin: false }; }
    },
  });
  if (isLoading) return null;
  if (!data?.isAdmin) return <NotFound />;
  return <AdminPanel />;
}
