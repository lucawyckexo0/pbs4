import { createFileRoute, Link } from "@tanstack/react-router";
import { Star, Cpu, HardDrive, MemoryStick, Network, CreditCard, Globe2, HeartHandshake, Lock, Rocket, Server, Settings2, ShieldCheck, Timer, Zap, Gauge, Split, Route as RouteIcon, ExternalLink } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { ClosingBanner, Divider, FaqSection, SectionHead, SupportCards } from "@/components/sections/common";
import { LocationsSection } from "@/components/sections/locations";
import { homeFaq } from "@/config/faq";
import { PanelSlider } from "@/components/sections/PanelSlider";
import { LandingPreloader } from "@/components/layout/LandingPreloader";
import { TrustpilotLink, TrustpilotStars, TrustpilotWordmark } from "@/components/layout/Trustpilot";
import { img, partnerLogoSize, partners } from "@/config/images";
import { products } from "@/config/products";
import { site, specs } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { effectivePlans, formatINR, fromPrice } from "@/config/plans";
import { organizationLd, pageHead, websiteLd } from "@/lib/seo";

export const Route = createFileRoute("/")({
  head: () => pageHead({
    path: "/",
    title: "PlexScale: Game Servers, VPS & Bot Hosting in India",
    description: "Minecraft, Rust, CS2 and Hytale servers, VPS and Discord bot hosting on AMD EPYC 7763 with NVMe storage. INR pricing, GST included.",
    image: "/og/home.jpg",
    imageAlt: "PlexScale game servers, VPS and bot hosting in India",
    jsonLd: [organizationLd(), websiteLd()],
  }),
  component: Home,
});

function RatedCard() {
  return (
    <TrustpilotLink className="group relative mx-auto block w-full max-w-xs overflow-hidden rounded-lg border border-foreground/15 bg-graphite/55 p-6 backdrop-blur-md transition-colors hover:border-trustpilot/60 lg:mx-0">
      <div className="flex items-center justify-between gap-3">
        <TrustpilotWordmark className="text-lg" />
        <ExternalLink className="size-4 text-muted-foreground transition-colors group-hover:text-trustpilot" />
      </div>
      <p className="mt-5 font-display text-2xl font-bold leading-tight text-foreground">Excellent</p>
      <TrustpilotStars className="mt-3" size="lg" />
      <p className="mt-4 text-sm text-muted-foreground">TrustScore <span className="font-semibold text-foreground">{site.trustpilotScore}</span> out of 5</p>
      <p className="mt-1 text-xs text-trustpilot">Read our reviews on Trustpilot</p>
    </TrustpilotLink>
  );
}

function Hero() {
  const s = useSettings();
  return (
    <section className="relative -mt-16 overflow-hidden pt-16">
      <img src={img.minecraft} alt="Minecraft world artwork for PlexScale game server hosting" width={1280} height={720} fetchPriority="high" className="absolute inset-0 h-full w-full object-cover opacity-85" />
      <div className="hero-veil absolute inset-0" />
      <div className="container-px relative grid items-center gap-12 pb-24 pt-16 md:pb-36 md:pt-28 lg:grid-cols-12">
        <div className="animate-rise lg:col-span-7">
          <h1 className="mt-4 text-[40px] leading-[1.08] md:text-[56px] xl:text-[64px]"><span className="block">Spin up. Speed up.</span><span className="block">Scale up with <span className="text-azure-bright">PlexScale!</span></span></h1>
          <p className="measure mt-6 text-lg text-muted-foreground">Game servers, VPS and bot hosting that run smooth and cost less than you’d expect.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/deploy" className={btn({ size: "lg" })}>Deploy a server</Link>
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "glass" })}>Join our Discord</a>
          </div>
        </div>
        <div className="animate-rise [animation-delay:80ms] lg:col-span-5 lg:flex lg:justify-end"><RatedCard /></div>
      </div>
    </section>
  );
}

const trust = [
  { icon: <Timer />, k: "99.95%*", v: "uptime" },
  { icon: <Globe2 />, k: "5+", v: "locations" },
  { icon: <Cpu />, k: "AMD EPYC", v: "Powerful CPUs" },
  { icon: <CreditCard />, k: "UPI", v: "cards and netbanking" },
];

function TrustRow() {
  const { locations } = useSettings();
  return (
    <section className="container-px relative mt-10 md:mt-14">
      <ul className="panel grid grid-cols-2 divide-steel md:grid-cols-4 md:divide-x">
        {trust.map((t) => (
          <li key={t.v} className="flex items-center gap-4 p-6">
            <span className="text-azure [&_svg]:size-6">{t.icon}</span>
            <div><p className="font-display text-lg font-bold">{t.v === "locations" ? locations.length : t.k}</p><p className="text-sm text-muted-foreground">{t.v}</p></div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Partners() {
  return (
    <section className="section container-px text-center">
      <h2 className="text-2xl md:text-3xl">Built on trusted technology</h2>
      <p className="mx-auto mt-3 measure text-muted-foreground">PlexScale runs on and is protected by technology the industry trusts.</p>
      <ul className="mx-auto mt-12 flex flex-wrap items-center justify-center gap-x-10 gap-y-10 xl:gap-x-12">
        {partners.map((p) => {
          const size = partnerLogoSize(p.ratio);
          return (
            <li key={p.name} className="flex h-12 shrink-0 items-center justify-center">
              <img src={p.src} alt={p.name} loading="lazy" width={size.width} height={size.height} style={size} className={`partner-logo opacity-90 transition-opacity hover:opacity-100 ${p.boost}`} />
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function Games() {
  const s = useSettings();
  return (
    <section className="section container-px">
      <SectionHead eyebrow="What we host" title="Pick your game" sub="Every plan runs on the same EPYC hardware, with NVMe storage and DDoS protection included." />
      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <Link key={p.key} to={p.to} className="group panel animated-outline relative flex aspect-[16/10] flex-col justify-end overflow-hidden">
            <img src={p.image} alt={`${p.name} artwork`} loading="lazy" width={1280} height={720} className="absolute inset-0 h-full w-full object-cover" />
            <div className="fade-ink absolute inset-0" />
            <div className="relative p-5">
              <h3 className="text-2xl font-bold">{p.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{p.blurb}</p>
              <p className="mt-3 text-sm">from <span className="font-display text-xl font-bold text-azure">{formatINR(fromPrice(effectivePlans(p.key, s.plans)))}</span><span className="text-muted-foreground">/mo</span></p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}

function Steps() {
  const steps = [
    { n: "01", icon: <Server />, t: "Choose a plan", b: "Pick your game, the memory you need and the location closest to your players. Prices are clear and in rupees." },
    { n: "02", icon: <Settings2 />, t: "Pick your setup", b: "Choose your software or modpack and we install it for you. There is nothing to configure by hand." },
    { n: "03", icon: <Rocket />, t: "Jump in", b: "Your server comes online in about a minute. Share the IP and start playing." },
  ];
  return (
    <section className="section container-px">
      <SectionHead eyebrow="How it works" title="Zero to online in about a minute" />
      <ol className="mt-10 grid gap-6 md:grid-cols-3">
        {steps.map((s) => (
          <li key={s.n} className="panel p-8">
            <div className="flex items-center justify-between"><span className="text-azure [&_svg]:size-6">{s.icon}</span><span className="font-display text-sm text-muted-foreground">{s.n}</span></div>
            <h3 className="mt-6 text-xl font-semibold">{s.t}</h3>
            <p className="mt-2 text-muted-foreground">{s.b}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}

function Pillars() {
  const items = [
    { icon: <ShieldCheck />, k: "99.95%* uptime target", t: "Online when it counts", b: "Raid night, ranked finals, a Friday SMP session. A filtered network and redundant power keep your server reachable, and our SLA puts the promise in writing." },
    { icon: <Lock />, k: "Reserved resources", t: "Your slice stays yours", b: "The memory in your plan belongs to you. We do not cram extra servers onto a node, so a busy neighbour never turns into your lag spike." },
    { icon: <HeartHandshake />, k: "Real support", t: "Humans who play", b: "Crashing modpack? Plugin conflict? Open a ticket, message us on Discord or send an email. You will talk to someone who knows what a tick rate is, and replies average about a minute." },
    { icon: <Zap />, k: "AMD EPYC 7763", t: "Made for tick rate", b: "Fast single-core speed, DDR4 3200 memory and NVMe Gen 4 disks. Chunks load quickly, ticks hold steady and restarts take seconds." },
  ];
  return (
    <section className="section container-px">
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {items.map((it) => (
          <div key={it.t} className="panel relative overflow-hidden p-6">
            <span className="text-azure [&_svg]:size-7">{it.icon}</span>
            <p className="mt-5 text-xs font-semibold uppercase tracking-wider text-azure-bright">{it.k}</p>
            <h3 className="mt-1 text-xl font-semibold">{it.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{it.b}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export function Hardware() {
  const specIcons = { CPU: Cpu, Memory: MemoryStick, Storage: HardDrive, Uplink: Network, DDoS: ShieldCheck, Uptime: Timer };
  return (
    <section id="hardware" className="section container-px">
      <div className="grid items-center gap-12 lg:grid-cols-12">
        <div className="relative lg:col-span-5">
          <div className="hardware-portrait relative mx-auto aspect-square w-full max-w-[420px]">
            <img src={img.epyc} alt="AMD EPYC 7763 processor" loading="lazy" width={1200} height={859} className="relative h-full w-full object-contain p-6" />
          </div>
        </div>
        <div className="lg:col-span-7">
          <SectionHead eyebrow="Hardware" title="Serious hardware. Sensible pricing." sub="Games reward fast single cores, so every node runs an AMD EPYC 7763 with DDR4 3200 memory and NVMe Gen 4 storage, tuned for steady clocks and quick disk reads. Whether you rent a small Minecraft world or a full Rust map, you get the same machines and the same attention." />
          <dl className="mt-8 grid gap-3 sm:grid-cols-2">
            {specs.map((s) => {
              const Icon = specIcons[s.label as keyof typeof specIcons];
              return <div key={s.label} className="hardware-spec relative flex min-h-32 flex-col justify-between gap-4 p-5 text-sm">
                <dt className="flex items-center justify-between gap-3 text-muted-foreground">{s.label}<Icon className="size-4 text-azure" /></dt>
                <dd className="font-display font-medium leading-relaxed">{s.value}</dd>
              </div>;
            })}
          </dl>
        </div>
      </div>
    </section>
  );
}

export function Networking() {
  const items = [
    { icon: Gauge, t: "Accelerated Networking (SR-IOV)", b: "Hardware-assisted networking that reduces virtualization overhead, improves throughput, and helps deliver lower network latency." },
    { icon: RouteIcon, t: "BGP Anycast Routing", b: "BGP-based routing allows the same IP prefix to be advertised from multiple network locations, so traffic reaches the right endpoint automatically." },
    { icon: Split, t: "Layer 4 Load Balancing", b: "TCP and UDP load balancing for efficient traffic distribution across healthy backend instances." },
  ];
  return (
    <section id="networking" className="section container-px">
      <p className="eyebrow">The PlexScale advantage</p>
      <h2 className="mt-2 text-2xl md:text-3xl">Advanced Networking Infrastructure</h2>
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map(({ icon: Icon, t, b }) => (
          <div key={t} className="hardware-spec relative flex flex-col gap-3 p-5 text-sm">
            <Icon className="size-5 text-azure" />
            <h3 className="font-display font-medium">{t}</h3>
            <p className="leading-relaxed text-muted-foreground">{b}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Reviews() {
  const reviews = [
    { initials: "AK", name: "Arjun K.", product: "Minecraft", title: "Our weekend world, without the lag", body: "Moved our survival world over and spent the evening playing instead of tweaking settings. Setup was straightforward.", rating: 5 },
    { initials: "SM", name: "Sneha M.", product: "Bot Hosting", title: "A small bot, a lot less hassle", body: "Just wanted our community bot to stay online. Got it running quickly, and the panel keeps everything in one place.", rating: 5 },
    { initials: "RD", name: "Rohan D.", product: "VPS", title: "Good value for a side project", body: "Root access and pricing in rupees were what I needed. A little help getting started made the move much easier.", rating: 4 },
  ];
  return (
    <section className="section container-px">
      <SectionHead eyebrow="Community" title="Good games. Better company." />
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {reviews.map((r) => <article key={r.name} className="panel flex flex-col rounded-lg p-6">
          <div className="flex gap-1" aria-label={`${r.rating} out of 5 stars`}>{[0, 1, 2, 3, 4].map((i) => <Star key={i} className={`size-4 text-azure ${i < r.rating ? "fill-azure" : ""}`} />)}</div>
          <h3 className="mt-5 text-lg font-semibold leading-snug">{r.title}</h3>
          <p className="mb-6 mt-3 text-sm text-muted-foreground">“{r.body}”</p>
          <div className="mt-auto flex items-center gap-3 border-t border-steel pt-5"><span className="grid size-9 shrink-0 place-items-center rounded-full bg-accent text-xs font-semibold">{r.initials}</span><div><p className="text-sm font-semibold">{r.name}</p><p className="text-xs text-muted-foreground">{r.product}</p></div></div>
        </article>)}
      </div>
    </section>
  );
}

function WhyPlexScale() {
  const tags = ["Minecraft", "Hytale", "Counter Strike 2", "Rust", "VPS", "Bot Hosting"];
  return (
    <section className="section container-px">
      <div className="relative mx-auto max-w-5xl pt-6">
        <div className="absolute left-1/2 top-0 z-10 -translate-x-1/2 whitespace-nowrap rounded-lg border border-azure/50 bg-graphite px-6 py-3 shadow-lg">
          <h2 className="flex items-center gap-3 text-xl md:text-3xl"><HeartHandshake className="size-6 text-azure md:size-7" />Why <span className="text-azure">PlexScale</span>?</h2>
        </div>
        <div className="panel animated-outline relative overflow-hidden rounded-xl px-6 pb-10 pt-14 text-center md:px-14">
          <div className="glow-azure absolute inset-0 opacity-60" />
          <p className="relative mx-auto max-w-3xl text-muted-foreground md:text-lg">
            We have been providing affordable and reliable servers since February 2026, with a wide choice of games, server software and modpacks. Every plan runs on tuned AMD EPYC 7763 hardware with NVMe Gen 4 storage, DDoS protection and support from people who actually play.
          </p>
          <ul className="relative mt-8 flex flex-wrap justify-center gap-2">
            {tags.map((t) => <li key={t} className="rounded-full border border-steel bg-ink/40 px-3 py-1 text-xs text-muted-foreground">{t}</li>)}
          </ul>
          <TrustpilotLink className="relative mx-auto mt-8 flex max-w-xl flex-wrap items-center justify-center gap-x-4 gap-y-2 rounded-lg border border-steel bg-ink/40 px-5 py-3 text-sm transition-colors hover:border-trustpilot/60">
            <span className="font-display font-bold tracking-wide">Excellent</span>
            <TrustpilotStars size="sm" />
            <span className="font-semibold">{site.trustpilotScore} out of 5</span>
            <TrustpilotWordmark />
          </TrustpilotLink>
        </div>
      </div>
    </section>
  );
}

function Home() {
  return (
    <>
      <LandingPreloader />
      <Hero />
      <TrustRow />
      <Partners />
      <Divider />
      <Games />
      <WhyPlexScale />
      <Steps />
      <Divider />
      <Pillars />
      <Divider />
      <Hardware />
      <LocationsSection />
      <Divider />
      <Networking />
      <PanelSlider />
      <Divider />
      <Reviews />
      <SupportCards />
      <FaqSection items={homeFaq} />
      <ClosingBanner title="Ready when you are." />
    </>
  );
}
