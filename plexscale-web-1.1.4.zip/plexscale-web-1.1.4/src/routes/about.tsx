import { createFileRoute, Link } from "@tanstack/react-router";
import { Cpu, Gauge, Globe2, HeartHandshake, IndianRupee, LifeBuoy, Lock, MessageCircle, ShieldCheck, Sparkles, Terminal, Timer } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { ClosingBanner, PageHero, SectionHead } from "@/components/sections/common";
import { flags, img } from "@/config/images";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";
import { absoluteUrl, breadcrumbLd, ORG_ID, pageHead } from "@/lib/seo";

const title = "About PlexScale | Indian Game & VPS Hosting";
const desc = "PlexScale is an Indian host for game servers, VPS and Discord bots on AMD EPYC 7763, with its own Plexus VPS panel and real human support.";

export const Route = createFileRoute("/about")({
  head: () => pageHead({ path: "/about", title, description: desc, image: "/og/about.jpg", imageAlt: "Server racks behind the PlexScale team", jsonLd: [{ "@type": "AboutPage", name: title, url: absoluteUrl("/about"), about: { "@id": ORG_ID } }, breadcrumbLd([{ name: "About", path: "/about" }])] }),
  component: About,
});

const values = [
  { icon: Lock, t: "No overselling", b: "Every plan gets the memory it pays for. We would rather say a node is full than squeeze in one more server." },
  { icon: IndianRupee, t: "Honest pricing", b: "Prices in rupees with GST included. Nothing renews behind your back, and reminders arrive before anything expires." },
  { icon: HeartHandshake, t: "People, not scripts", b: "Tickets, Discord and email are answered by a team that runs game servers themselves." },
  { icon: Sparkles, t: "Built in-house", b: "Our Plexus VPS panel is designed and built by the PlexScale team, with live console, OS rebuilds and firewalls." },
];

const milestones = [
  { when: "February 2026", t: "PlexScale opens", b: "First Minecraft servers go live on tuned AMD EPYC 7763 nodes in India." },
  { when: "2026", t: "More games, more places", b: "Hytale, Counter Strike 2, Rust, VPS and bot hosting join, across India, the UAE, Germany and the United States." },
  { when: "Today", t: "Plexus and on-site support", b: "Our own VPS panel and a built-in ticket system put everything in one place." },
];

const leaders = [
  { name: "Prateek J.", role: "Founder & CEO", b: "Sets the direction and keeps the infrastructure honest." },
  { name: "Shashank M.", role: "Co-Founder & Director", b: "Runs operations, partners and the day-to-day of the company." },
  { name: "Ayaan R.", role: "Marketing Lead", b: "Looks after the community and how people hear about us." },
];

const initials = (n: string) => n.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

function About() {
  const s = useSettings();
  const stats = [
    { icon: Timer, k: "99.95%*", v: "uptime target" },
    { icon: Globe2, k: String(s.locations.length), v: "locations" },
    { icon: ShieldCheck, k: "480 Gbps", v: "DDoS mitigation" },
    { icon: Gauge, k: "18 Gbps+", v: "network uplink" },
  ];
  return (
    <>
      <PageHero eyebrow="About PlexScale" title="Hosting made by players, for players" sub="We started PlexScale because Indian communities deserved fast servers, fair INR pricing and support that actually replies." image={img.racks} imageAlt="Server racks in a PlexScale data centre">
        <Link to="/" hash="locations" className={btn({ size: "lg" })}>See our locations</Link>
        <Link to="/contact" className={btn({ size: "lg", variant: "glass" })}>Talk to us</Link>
      </PageHero>

      <section className="container-px relative -mt-6">
        <ul className="panel grid grid-cols-2 divide-steel md:grid-cols-4 md:divide-x">
          {stats.map(({ icon: Icon, k, v }) => (
            <li key={v} className="flex items-center gap-4 p-6">
              <Icon className="size-6 shrink-0 text-azure" />
              <div><p className="font-display text-xl font-bold">{k}</p><p className="text-sm text-muted-foreground">{v}</p></div>
            </li>
          ))}
        </ul>
      </section>

      <section className="section container-px grid gap-12 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <SectionHead eyebrow="Our story" title="Fast servers shouldn’t be a luxury" />
          <div className="measure mt-6 space-y-4 text-muted-foreground">
            <p>Most hosts treated Indian players as an afterthought: servers far away, prices in dollars and support queues that took days. We wanted the opposite, so we built it.</p>
            <p>Every PlexScale server runs on AMD EPYC 7763 hardware with NVMe Gen 4 storage, in data centres close to the people who play on them. Game servers are created on the panel automatically the moment you pay, and VPS customers get Plexus, a panel we built ourselves.</p>
            <p>If something breaks, you talk to a real person through an on-site support ticket, Discord or email.</p>
          </div>
        </div>
        <aside className="lg:col-span-5">
          <div className="panel relative overflow-hidden p-6">
            <div className="glow-azure pointer-events-none absolute inset-0 opacity-50" />
            <div className="relative">
              <p className="eyebrow">At a glance</p>
              <dl className="mt-4 divide-y divide-steel text-sm">
                {[["Company", site.legalName], ["Website", site.domain], ["Headquarters", "India"], ["Founded", "February 2026"], ["Email", s.supportEmail], ["Discord", s.discordLabel]].map(([k, v]) => (
                  <div key={k} className="grid grid-cols-3 gap-3 py-3"><dt className="text-muted-foreground">{k}</dt><dd className="col-span-2 break-words font-medium">{v}</dd></div>
                ))}
              </dl>
            </div>
          </div>
        </aside>
      </section>

      <section className="section container-px pt-0">
        <SectionHead eyebrow="What we stand for" title="Four promises we keep" />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {values.map(({ icon: Icon, t, b }) => (
            <div key={t} className="panel animated-outline relative p-6">
              <span className="grid size-11 place-items-center rounded-md border border-steel bg-ink/50"><Icon className="size-5 text-azure" /></span>
              <h3 className="mt-5 text-lg font-semibold">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{b}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section container-px pt-0">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHead eyebrow="Journey" title="How we got here" sub="Young, focused and growing with the communities that host with us." />
            <div className="mt-8 grid grid-cols-2 gap-3">
              <div className="hardware-spec relative p-5 text-sm"><Cpu className="size-5 text-azure" /><p className="mt-3 font-display font-semibold">AMD EPYC 7763</p><p className="text-muted-foreground">up to 3.5 GHz</p></div>
              <div className="hardware-spec relative p-5 text-sm"><Terminal className="size-5 text-azure" /><p className="mt-3 font-display font-semibold">Plexus panel</p><p className="text-muted-foreground">built by our team</p></div>
            </div>
          </div>
          <ol className="relative border-l border-steel pl-8 lg:col-span-7">
            {milestones.map((m) => (
              <li key={m.t} className="relative pb-10 last:pb-0">
                <span className="absolute -left-[41px] top-1 size-4 rounded-full border-2 border-azure bg-ink" />
                <p className="text-sm font-semibold text-azure">{m.when}</p>
                <h3 className="mt-1 text-xl font-semibold">{m.t}</h3>
                <p className="mt-2 text-muted-foreground">{m.b}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section container-px pt-0">
        <SectionHead eyebrow="Where we run" title="Close to your players" />
        <ul className="mt-8 flex flex-wrap gap-3">
          {s.locations.map((l) => (
            <li key={l.id} className="flex items-center gap-3 rounded-full border border-steel bg-graphite px-4 py-2 text-sm">
              {flags[l.country] && <img src={flags[l.country]} alt="" width={24} height={12} loading="lazy" className="h-3 w-6 rounded-sm object-cover ring-1 ring-steel" />}
              <span className="font-medium">{l.city}</span><span className="text-muted-foreground">{l.region}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="section container-px pt-0">
        <SectionHead eyebrow="Leadership" title="The people behind PlexScale" />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {leaders.map((p) => (
            <article key={p.name} className="panel flex items-start gap-4 p-6">
              <span className="grid size-12 shrink-0 place-items-center rounded-full border border-azure/50 bg-azure/10 font-display text-sm font-bold text-azure">{initials(p.name)}</span>
              <div>
                <h3 className="text-xl font-semibold">{p.name}</h3>
                <p className="text-sm text-azure">{p.role}</p>
                <p className="mt-3 text-sm text-muted-foreground">{p.b}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section container-px pt-0">
        <div className="panel grid gap-6 p-8 md:grid-cols-[1fr_auto] md:items-center">
          <div>
            <h2 className="text-2xl md:text-3xl">Have a question for the team?</h2>
            <p className="mt-2 text-muted-foreground">{site.responseTime}. Open a ticket on the site or reach us on Discord.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link to="/support/new" className={btn({ size: "lg" })}><LifeBuoy />Open a ticket</Link>
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ size: "lg", variant: "secondary" })}><MessageCircle />Discord</a>
          </div>
        </div>
      </section>

      <ClosingBanner />
    </>
  );
}
