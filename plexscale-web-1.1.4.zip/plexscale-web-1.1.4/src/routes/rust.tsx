import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/rust")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "rust");
    const from = fromLabel(plans);
    const title = "Rust Server Hosting in India | PlexScale";
    const description = `Rust servers from ${from} a month on AMD EPYC 7763 with NVMe storage, Oxide plugins and DDoS protection. GST included.`;
    return pageHead({
      path: "/rust", title, description, image: "/og/rust.jpg", imageAlt: "Rust server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/rust", name: "PlexScale Rust server hosting", serviceType: "Game server hosting", description, image: "/og/rust.jpg", plans }), breadcrumbLd([{ name: "Rust server hosting", path: "/rust" }])],
    });
  },
  component: () => (
    <GamePage game="rust" name="Rust" image={img.rust} sub="Survive, build and raid with your clan. Fast EPYC servers, set up for you in minutes." software={["Rust dedicated server", "Oxide plugins", "Procedural maps"]} faq={homeFaq} />
  ),
});
