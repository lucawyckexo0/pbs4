import { createFileRoute } from "@tanstack/react-router";
import { GamePage } from "@/components/sections/GamePage";
import { homeFaq } from "@/config/faq";
import { img } from "@/config/images";
import { breadcrumbLd, hostingLd, pageHead } from "@/lib/seo";
import { fromLabel, seoPlans } from "@/lib/seo-plans";

export const Route = createFileRoute("/minecraft")({
  head: ({ matches }) => {
    const plans = seoPlans(matches, "minecraft");
    const from = fromLabel(plans);
    const title = "Minecraft Server Hosting in India | PlexScale";
    const description = `Minecraft servers from ${from} a month: PaperMC, Fabric, Forge, SpigotMC, NeoForge and Vanilla on AMD EPYC 7763. GST included.`;
    return pageHead({
      path: "/minecraft", title, description, image: "/og/minecraft.jpg", imageAlt: "Minecraft server hosting by PlexScale",
      jsonLd: [...hostingLd({ path: "/minecraft", name: "PlexScale Minecraft server hosting", serviceType: "Game server hosting", description, image: "/og/minecraft.jpg", plans }), breadcrumbLd([{ name: "Minecraft server hosting", path: "/minecraft" }])],
    });
  },
  component: () => (
    <GamePage game="minecraft" name="Minecraft" image={img.minecraft} sub="PaperMC, Fabric, Forge and more on AMD EPYC with NVMe storage. Live in about a minute." software={["PaperMC","Fabric","Forge","SpigotMC","NeoForge","Vanilla"]} faq={homeFaq} />
  ),
});
