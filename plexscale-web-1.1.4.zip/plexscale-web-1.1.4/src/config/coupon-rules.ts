import { z } from "zod";
import { productKeys } from "./plans";

/** Codes are stored upper-case: letters, numbers, dash and underscore. */
const COUPON_CODE_RE = /^[A-Z0-9_-]{3,32}$/;
const normalizeCouponCode = (s: string) => s.trim().toUpperCase();

const isoDate = z.string().datetime({ offset: true });

/** What an administrator can set on a coupon. The database enforces the same limits again. */
export const couponInput = z.object({
  id: z.string().uuid().optional(),
  code: z.string().transform(normalizeCouponCode).pipe(z.string().regex(COUPON_CODE_RE, "3 to 32 letters, numbers, dashes or underscores")),
  kind: z.enum(["percent", "fixed"]),
  value: z.number().int().min(1),
  maxDiscount: z.number().int().min(1).max(1_000_000).nullable().optional(),
  minAmount: z.number().int().min(0).max(10_000_000).default(0),
  products: z.array(z.enum(productKeys as [string, ...string[]])).max(10).default([]),
  maxUses: z.number().int().min(1).max(1_000_000).nullable().optional(),
  perUserLimit: z.number().int().min(1).max(100).default(1),
  startsAt: isoDate.nullable().optional(),
  expiresAt: isoDate.nullable().optional(),
  active: z.boolean().default(true),
  note: z.string().trim().max(200).default(""),
}).superRefine((d, ctx) => {
  if (d.kind === "percent" && d.value > 100) ctx.addIssue({ code: "custom", path: ["value"], message: "A percentage can be at most 100." });
  if (d.kind === "fixed" && d.value > 1_000_000) ctx.addIssue({ code: "custom", path: ["value"], message: "Amount is too large." });
  if (d.startsAt && d.expiresAt && Date.parse(d.expiresAt) <= Date.parse(d.startsAt)) ctx.addIssue({ code: "custom", path: ["expiresAt"], message: "Expiry must be after the start." });
});
export type CouponInput = z.infer<typeof couponInput>;

/** Customer input on the deploy page. */
export const couponCodeInput = z.string().transform(normalizeCouponCode).pipe(z.string().regex(COUPON_CODE_RE, "That coupon code is not valid."));

interface CouponTerms { kind: "percent" | "fixed"; value: number; max_discount: number | null }

/**
 * Discount in whole rupees for an order total. Same formula as the database's apply_coupon:
 * percent rounds down, an optional cap applies, and the customer always pays at least ₹1.
 */
export function couponDiscount(c: CouponTerms, amount: number): number {
  if (!Number.isInteger(amount) || amount < 2) return 0;
  let d = c.kind === "percent" ? Math.floor((amount * c.value) / 100) : c.value;
  if (c.max_discount !== null) d = Math.min(d, c.max_discount);
  return Math.max(0, Math.min(d, amount - 1));
}

interface CouponRow extends CouponTerms {
  active: boolean;
  starts_at: string | null;
  expires_at: string | null;
  products: string[];
  min_amount: number;
  max_uses: number | null;
  per_user_limit: number;
}

/** Reason a coupon cannot be used, as the database would decide it. Null means it applies. */
export function couponProblem(c: CouponRow, ctx: { product: string; amount: number; uses: number; userUses: number; now?: number }): CouponErrorKey | null {
  const now = ctx.now ?? Date.now();
  if (!c.active) return "coupon_invalid";
  if (c.starts_at && now < Date.parse(c.starts_at)) return "coupon_not_started";
  if (c.expires_at && now >= Date.parse(c.expires_at)) return "coupon_expired";
  if (c.products.length > 0 && !c.products.includes(ctx.product)) return "coupon_product";
  if (ctx.amount < c.min_amount) return "coupon_min_amount";
  if (c.max_uses !== null && ctx.uses >= c.max_uses) return "coupon_used_up";
  if (ctx.userUses >= c.per_user_limit) return "coupon_already_used";
  if (couponDiscount(c, ctx.amount) <= 0) return "coupon_no_discount";
  return null;
}

export const couponErrors = {
  coupon_invalid: "That coupon code is not valid.",
  coupon_not_started: "That coupon is not active yet.",
  coupon_expired: "That coupon has expired.",
  coupon_product: "That coupon does not apply to this product.",
  coupon_min_amount: "Your order total is below this coupon's minimum.",
  coupon_used_up: "That coupon has been fully used.",
  coupon_already_used: "You have already used this coupon. If a checkout with it is still unpaid, finish that one or try again in an hour.",
  coupon_no_discount: "That coupon gives no discount on this order.",
  coupon_order_invalid: "This order cannot take a coupon.",
} as const;
type CouponErrorKey = keyof typeof couponErrors;

/** Maps a database error message (from apply_coupon) to a customer-safe sentence. */
export function couponErrorMessage(raw: string | null | undefined): string {
  const key = (Object.keys(couponErrors) as CouponErrorKey[]).find((k) => raw?.includes(k));
  return key ? couponErrors[key] : "That coupon could not be applied. Please try again.";
}
