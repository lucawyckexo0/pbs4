import { games } from "./products";

/** Public pages that show the product menus and Discord button. Account, billing, deploy, support and admin pages hide them. */
const publicPages = new Set(["/", "/about", "/contact", "/queries", "/vps", "/bot-hosting", ...games.map((g) => g.to)]);

export const showsProducts = (path: string) => publicPages.has(path.replace(/\/+$/, "") || "/") || path === "/legal" || path.startsWith("/legal/");
