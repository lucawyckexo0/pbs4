// Fixed brand facts. Links, contact details, banners and status live in site settings (Administrator).
export const site = {
  name: "PlexScale",
  domain: "plexscale.com",
  url: "https://plexscale.com",
  responseTime: "Average Response Time: 60 seconds",
  legalName: "PlexScale",
  address: "India",
  blurb: "Fast game servers, VPS and bot hosting on tuned AMD EPYC hardware, at honest prices.",
  statusUrl: "https://status.plexscale.com",
  legalUrl: "https://legal.plexscale.com",
  trustpilotUrl: "https://www.trustpilot.com/review/plexscale.com",
  trustpilotScore: 4.4,
  copyright: "© PlexScale. All Rights Reserved.",
};

export const specs = [
  { label: "CPU", value: "AMD EPYC 7763, up to 3.5 GHz" },
  { label: "Memory", value: "DDR4 3200 MHz" },
  { label: "Storage", value: "NVMe Gen 4 SSD" },
  { label: "Uplink", value: "18 Gbps+" },
  { label: "DDoS", value: "Standard L3/L4/L7 mitigation, up to 480 Gbps" },
  { label: "Uptime", value: "99.95%*" },
];

interface Location {
  id: string;
  city: string;
  region: string;
  country: string;
  x: number; // percent across map
  y: number;
  mockPing: number;
}

export const locations: Location[] = [
  { id: "mumbai", city: "Mumbai", region: "India", country: "IN", x: 34, y: 56, mockPing: 12 },
  { id: "virginia", city: "Virginia", region: "United States", country: "US", x: 10, y: 30, mockPing: 210 },
  { id: "hyderabad", city: "Hyderabad", region: "India", country: "IN", x: 39, y: 59, mockPing: 15 },
  { id: "dubai", city: "Dubai", region: "UAE", country: "AE", x: 23, y: 48, mockPing: 46 },
  { id: "frankfurt", city: "Frankfurt", region: "Germany", country: "DE", x: 8, y: 22, mockPing: 128 },
];

