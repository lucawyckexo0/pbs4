import { img } from "./images";
import { botPlans, fromPrice, gamePlans, vpsPlans, type GameKey } from "./plans";

interface Product {
  key: string;
  name: string;
  to: string;
  image: string;
  blurb: string;
  from: number;
}

export const products: Product[] = [
  { key: "minecraft", name: "Minecraft", to: "/minecraft", image: img.minecraft, blurb: "Paper, Fabric, Forge and more, one click away.", from: fromPrice(gamePlans("minecraft")) },
  { key: "hytale", name: "Hytale", to: "/hytale", image: img.hytale, blurb: "Ready for adventure worlds and custom content.", from: fromPrice(gamePlans("hytale")) },
  { key: "cs2", name: "Counter Strike 2", to: "/counter-strike-2", image: img.cs2, blurb: "128 tick feel with low latency India routes.", from: fromPrice(gamePlans("cs2")) },
  { key: "rust", name: "Rust", to: "/rust", image: img.rust, blurb: "Survive, build and raid on fast EPYC hardware.", from: fromPrice(gamePlans("rust")) },
  { key: "vps", name: "VPS", to: "/vps", image: img.vps, blurb: "Full root access on EPYC with NVMe storage.", from: fromPrice(vpsPlans) },
  { key: "bot", name: "Bot Hosting", to: "/bot-hosting", image: img.bot, blurb: "Keep your Discord bot online all day, every day.", from: fromPrice(botPlans) },
];

export const games: { key: GameKey; name: string; to: string }[] = [
  { key: "minecraft", name: "Minecraft", to: "/minecraft" },
  { key: "hytale", name: "Hytale", to: "/hytale" },
  { key: "cs2", name: "Counter Strike 2", to: "/counter-strike-2" },
  { key: "rust", name: "Rust", to: "/rust" },
];
