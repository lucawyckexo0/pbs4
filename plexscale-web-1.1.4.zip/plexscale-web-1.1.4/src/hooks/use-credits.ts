import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyCredits } from "@/lib/credits.functions";

/** The signed-in customer's credit balance and recent activity. */
export function useCredits(enabled = true) {
  const fn = useServerFn(getMyCredits);
  return useQuery({ queryKey: ["credits"], queryFn: () => fn(), enabled, staleTime: 15_000, retry: 1 });
}
