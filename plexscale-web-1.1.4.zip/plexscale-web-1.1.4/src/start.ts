import { createStart, createCsrfMiddleware, createMiddleware } from "@tanstack/react-start";
import { isNotFound, isRedirect } from "@tanstack/react-router";

import { renderErrorPage } from "./lib/error-page";
import { publicMessage } from "./lib/public-error";
import { logEvent } from "./lib/log";
import { attachSupabaseAuth } from "@/integrations/supabase/auth-attacher";

// Page requests: any crash becomes the plain error page.
const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) throw error;
    logEvent("error", "request.failed", { message: error instanceof Error ? error.message : "unknown" });
    return new Response(renderErrorPage(), { status: 500, headers: { "content-type": "text/html; charset=utf-8" } });
  }
});

// Server functions: only friendly messages leave the server; details stay in the logs.
const maskErrors = createMiddleware({ type: "function" }).server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error instanceof Response || isRedirect(error) || isNotFound(error)) throw error;
    const message = publicMessage(error);
    if (!(error instanceof Error && "expose" in error)) logEvent("error", "fn.failed", { message: error instanceof Error ? error.message.slice(0, 300) : "unknown" });
    throw new Error(message);
  }
});

// Blocks cross-site calls to server functions.
const csrfMiddleware = createCsrfMiddleware({
  filter: (ctx) => ctx.handlerType === "serverFn",
});

export const startInstance = createStart(() => ({
  functionMiddleware: [maskErrors, attachSupabaseAuth],
  requestMiddleware: [errorMiddleware, csrfMiddleware],
}));
