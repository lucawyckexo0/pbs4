// Content-Security-Policy for production pages. Kept free of framework imports so it can be unit tested.

/**
 * The origin of the PlexScale API (auth + data) that browsers call, for example https://api.example.com.
 * Only an https origin with a plain host name is accepted; anything else yields null and the policy then
 * allows only this site ('self'), so a bad value fails closed instead of opening connect-src.
 */
export function apiOrigin(raw: string | undefined): string | null {
  if (!raw) return null;
  let u: URL;
  try { u = new URL(raw); } catch { return null; }
  if (u.protocol !== "https:" || u.username || u.password || !/^[a-z0-9.-]+$/i.test(u.hostname) || !u.hostname.includes(".")) return null;
  return `https://${u.host.toLowerCase()}`;
}

/** Inline scripts run only with this request's nonce. No framing. Only named hosts may be contacted. */
export function buildCsp(nonce: string, api: string | null): string {
  const connect = ["'self'", ...(api ? [api] : []), "https://*.razorpay.com", "https://challenges.cloudflare.com"];
  return [
    "default-src 'self'",
    "base-uri 'self'",
    "object-src 'none'",
    "frame-ancestors 'none'",
    "form-action 'self' https://*.razorpay.com",
    `script-src 'self' 'nonce-${nonce}' https://checkout.razorpay.com https://*.razorpay.com https://challenges.cloudflare.com`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https:",
    "font-src 'self' data: https://*.razorpay.com",
    `connect-src ${connect.join(" ")}`,
    "frame-src 'self' https://*.razorpay.com https://challenges.cloudflare.com",
    "worker-src 'self' blob:",
    "upgrade-insecure-requests",
  ].join("; ");
}
