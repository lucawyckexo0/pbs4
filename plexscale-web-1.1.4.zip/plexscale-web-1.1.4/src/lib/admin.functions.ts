import { PublicError } from "@/lib/public-error";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Json } from "@/integrations/supabase/types";
import { panelSettingsSchema, siteSettingsSchema } from "@/config/settings";
import { isOrderRefundEligible } from "@/config/refund-rules";
import { couponInput } from "@/config/coupon-rules";

import { assertAdmin } from "@/lib/admin-guard";

const uuid = z.string().uuid();
const orderStatus = z.enum(["pending", "provisioning", "active", "suspended", "cancelled", "refunded", "failed"]);

/** Tells the client whether the signed-in account is an administrator. */
export const getAdminMe = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    return { isAdmin: data === true };
  });

export const getAdminData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadSiteSettings, loadPanelSettings, razorpayConfigured, razorpayWebhookConfigured } = await import("@/lib/billing.server");
    const { panelConfigured } = await import("@/lib/pterodactyl.server");
    const { normalizePanelSettings } = await import("@/config/settings");
    const [orders, refunds, profiles, roles, auditRows, site, panel] = await Promise.all([
      context.supabase.from("orders").select("id, user_id, kind, parent_order_id, product, plan_name, billing, amount, status, created_at, paid_at, renews_at, server_name, software, version, location, ptero_identifier, ptero_server_id, provision_error, server_deleted_at, discount, coupon_id, paid_with").order("created_at", { ascending: false }).limit(1000),
      context.supabase.from("refunds").select("id, order_id, user_id, reason, status, created_at").order("created_at", { ascending: false }).limit(500),
      context.supabase.from("profiles").select("id, email, display_name, created_at").order("created_at", { ascending: false }).limit(1000),
      supabaseAdmin.from("user_roles").select("user_id, role").eq("role", "admin"),
      supabaseAdmin.from("audit_log").select("id, actor_id, action, target, details, ip, created_at").eq("scope", "admin").order("created_at", { ascending: false }).limit(100),
      loadSiteSettings(),
      loadPanelSettings(),
    ]);
    return {
      orders: orders.data ?? [],
      refunds: refunds.data ?? [],
      profiles: profiles.data ?? [],
      adminIds: (roles.data ?? []).map((r) => r.user_id),
      audit: (auditRows.data ?? []).map((a) => ({ id: a.id, actor_id: a.actor_id, action: a.action, target: a.target, details: (a.details && typeof a.details === "object" && !Array.isArray(a.details) ? a.details : {}) as { [key: string]: Json | undefined }, ip: a.ip, created_at: a.created_at })),
      site,
      panel: normalizePanelSettings(panel),
      setup: { razorpay: razorpayConfigured(), webhook: razorpayWebhookConfigured(), panel: panelConfigured(), plexus: Boolean(process.env["PLEXUS_URL"] && process.env["PLEXUS_API_KEY"]), turnstile: Boolean(process.env["TURNSTILE_SITE_KEY"] && process.env["TURNSTILE_SECRET_KEY"]) },
    };
  });

export const saveSiteSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => siteSettingsSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit, loadSiteSettings } = await import("@/lib/billing.server");
    const before = (await loadSiteSettings()) as Record<string, unknown>;
    // OS list is edited only in the Plexus section, so keep the stored one.
    const merged = { ...data, vpsOs: (before as { vpsOs?: unknown }).vpsOs ?? data.vpsOs };
    const { data: saved, error } = await supabaseAdmin.from("site_settings").update({ data: merged as never, updated_at: new Date().toISOString() }).eq("id", 1).select("id").maybeSingle();
    if (error || !saved) throw new PublicError("Could not save settings.");
    const sections = Object.keys(data).filter((k) => JSON.stringify((data as Record<string, unknown>)[k]) !== JSON.stringify(before[k])).slice(0, 20);
    await adminAudit(context.userId, "settings.site.update", null, { sections });
    return { ok: true };
  });

export const savePanelSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => panelSettingsSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit, loadPanelSettings } = await import("@/lib/billing.server");
    const { normalizePanelSettings } = await import("@/config/settings");
    // Plexus mappings are edited only in the Plexus section, so keep the stored ones.
    const merged = { ...data, plexus: normalizePanelSettings(await loadPanelSettings()).plexus };
    const { data: saved, error } = await supabaseAdmin.from("panel_settings").update({ data: merged as never, updated_at: new Date().toISOString() }).eq("id", 1).select("id").maybeSingle();
    if (error || !saved) throw new PublicError("Could not save panel settings.");
    await adminAudit(context.userId, "settings.panel.update", null);
    return { ok: true };
  });

export const testPanelConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { testPanel, listEggs } = await import("@/lib/pterodactyl.server");
    const { adminAudit } = await import("@/lib/billing.server");
    await adminAudit(context.userId, "panel.test", null);
    try {
      const [locations, eggs] = await Promise.all([testPanel(), listEggs()]);
      return { ok: true as const, locations, eggs };
    } catch (e) {
      console.error("Administrator panel test failed", e);
      return { ok: false as const, message: "Could not complete the panel connection test." };
    }
  });

export const setOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string; status: string }) => z.object({ orderId: uuid, status: orderStatus }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { setSuspended } = await import("@/lib/pterodactyl.server");
    const { data: order } = await supabaseAdmin.from("orders").select("id, kind, status, ptero_server_id").eq("id", data.orderId).maybeSingle();
    if (!order) throw new PublicError("Order not found.");
    if (order.kind !== "new") throw new PublicError("Only service orders can change status.");
    if (order.ptero_server_id) {
      const offStates = ["suspended", "cancelled", "refunded"];
      try {
        if (offStates.includes(data.status) && !offStates.includes(order.status)) await setSuspended(order.ptero_server_id, true);
        if (data.status === "active" && offStates.includes(order.status)) await setSuspended(order.ptero_server_id, false);
      } catch (e) {
        console.error("Administrator panel status update failed", e);
        throw new PublicError("The service status could not be updated. Please try again or contact support.");
      }
    }
    await supabaseAdmin.from("orders").update({ status: data.status, ...(data.status === "refunded" && order.status !== "refunded" ? { refunded_at: new Date().toISOString() } : {}) }).eq("id", order.id);
    await adminAudit(context.userId, "order.status", order.id, { from: order.status, to: data.status });
    return { ok: true, message: "Status updated." };
  });

export const retryProvision = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string }) => ({ orderId: uuid.parse(d.orderId) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { provisionOrder, adminAudit } = await import("@/lib/billing.server");
    const r = await provisionOrder(data.orderId);
    await adminAudit(context.userId, "order.provision", data.orderId, { ok: r.ok });
    return r;
  });

export const decideRefund = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { refundId: string; approve: boolean; note?: string }) => z.object({ refundId: uuid, approve: z.boolean(), note: z.string().trim().max(300).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit, rzp, suspendOnPanel } = await import("@/lib/billing.server");
    const { data: refund } = await supabaseAdmin.from("refunds").select("id, order_id, status, created_at").eq("id", data.refundId).maybeSingle();
    if (!refund || refund.status !== "requested") throw new PublicError("This refund was already handled.");
    if (!data.approve) {
      await supabaseAdmin.from("refunds").update({ status: "rejected", admin_note: data.note ?? null }).eq("id", refund.id);
      await adminAudit(context.userId, "refund.reject", refund.id);
      return { ok: true, message: "Refund rejected." };
    }
    const { data: order } = await supabaseAdmin.from("orders").select("*").eq("id", refund.order_id).maybeSingle();
    if (!order?.razorpay_payment_id) throw new PublicError("No payment found for this order.");
    const toCredits = order.paid_with === "credits";
    if (!isOrderRefundEligible(order.kind, order.product, order.paid_at, Date.parse(refund.created_at)) || ["refunded", "cancelled", "failed"].includes(order.status)) {
      throw new PublicError("This purchase is outside the eligible refund window.");
    }
    // Claim the refund first so two clicks can never refund twice.
    const { data: claimed } = await supabaseAdmin.from("refunds").update({ status: "approved", admin_note: data.note ?? null }).eq("id", refund.id).eq("status", "requested").select("id").maybeSingle();
    if (!claimed) throw new PublicError("This refund was already handled.");
    try {
      if (toCredits) {
        // Paid from credits: the amount goes back to the customer's balance, never to a card.
        const { error } = await supabaseAdmin.rpc("refund_order_to_credits", { _order_id: order.id, _by: context.userId, _note: "Refund to credits" });
        if (error) throw error;
      } else {
        if (!/^pay_[A-Za-z0-9]{6,40}$/.test(order.razorpay_payment_id)) throw new PublicError("bad payment id");
        await rzp(`/payments/${order.razorpay_payment_id}/refund`, { method: "POST", body: { amount: order.amount * 100, notes: { order_id: order.id } } });
      }
    } catch {
      await supabaseAdmin.from("refunds").update({ status: "requested" }).eq("id", refund.id);
      throw new PublicError(toCredits ? "The refund to credits could not be completed. Nothing changed." : "Razorpay could not process the refund. Nothing was charged back.");
    }
    await supabaseAdmin.from("refunds").update({ status: "paid" }).eq("id", refund.id);
    // A failed suspend raises a panel alert; the server is deleted 24 hours after the refund either way.
    await suspendOnPanel(order);
    await supabaseAdmin.from("orders").update({ status: "refunded", refunded_at: new Date().toISOString() }).eq("id", order.id);
    await adminAudit(context.userId, "refund.paid", refund.id, { order: order.id, amount: order.amount, to: toCredits ? "credits" : "razorpay" });
    return { ok: true, message: toCredits ? "Refund added back to the customer's credits." : "Refund sent through Razorpay." };
  });

export const setAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { email: string; admin: boolean }) => z.object({ email: z.string().trim().toLowerCase().email().max(120), admin: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { data: profile } = await supabaseAdmin.from("profiles").select("id").eq("email", data.email).maybeSingle();
    if (!profile) throw new PublicError("No account with that email. They need to sign in once first.");
    if (!data.admin && profile.id === context.userId) throw new PublicError("You cannot remove your own admin access.");
    if (data.admin) await supabaseAdmin.from("user_roles").upsert({ user_id: profile.id, role: "admin" }, { onConflict: "user_id,role" });
    else await supabaseAdmin.from("user_roles").delete().eq("user_id", profile.id).eq("role", "admin");
    await adminAudit(context.userId, data.admin ? "admin.grant" : "admin.revoke", profile.id);
    return { ok: true };
  });

export const retryUpgrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { orderId: string }) => ({ orderId: uuid.parse(d.orderId) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { applyUpgrade, adminAudit } = await import("@/lib/billing.server");
    const r = await applyUpgrade(data.orderId);
    await adminAudit(context.userId, "order.upgrade.retry", data.orderId, { ok: r.ok });
    return r;
  });

// ---------- Panel alerts ----------

export const listPanelAlerts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { status?: string; q?: string }) => z.object({ status: z.enum(["open", "resolved", "all"]).default("open"), q: z.string().trim().max(120).default("") }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    let query = context.supabase.from("panel_alerts")
      .select("id, created_at, last_seen_at, count, action, order_id, user_id, user_email, product, http_status, panel_code, panel_detail, raw, status, resolved_at")
      .order("last_seen_at", { ascending: false }).limit(300);
    if (data.status !== "all") query = query.eq("status", data.status);
    const q = data.q.replace(/[%_,()]/g, "");
    if (q) query = uuid.safeParse(q).success ? query.eq("order_id", q) : query.or(`user_email.ilike.%${q}%,panel_detail.ilike.%${q}%`);
    const { data: rows, error } = await query;
    if (error) throw new PublicError("Could not load alerts.");
    return rows ?? [];
  });

export const resolvePanelAlert = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { id: string }) => ({ id: uuid.parse(d.id) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { adminAudit } = await import("@/lib/billing.server");
    const { data: row, error } = await context.supabase.from("panel_alerts")
      .update({ status: "resolved", resolved_by: context.userId, resolved_at: new Date().toISOString() })
      .eq("id", data.id).eq("status", "open").select("id, action").maybeSingle();
    if (error) throw new PublicError("Could not resolve the alert.");
    if (!row) return { ok: true, message: "Already resolved." };
    await adminAudit(context.userId, "alert.resolve", data.id, { action: row.action });
    return { ok: true, message: "Alert resolved." };
  });

// ---------- Coupons ----------

export const listCoupons = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ data: coupons }, { data: used }] = await Promise.all([
      supabaseAdmin.from("coupons").select("*").order("created_at", { ascending: false }).limit(500),
      supabaseAdmin.from("orders").select("coupon_id, status, discount").not("coupon_id", "is", null).neq("status", "failed").limit(10000),
    ]);
    const stats = new Map<string, { uses: number; paid: number; discount: number }>();
    for (const o of used ?? []) {
      const s = stats.get(o.coupon_id!) ?? { uses: 0, paid: 0, discount: 0 };
      s.uses++;
      if (o.status !== "pending") { s.paid++; s.discount += o.discount; }
      stats.set(o.coupon_id!, s);
    }
    return (coupons ?? []).map((c) => ({ ...c, ...(stats.get(c.id) ?? { uses: 0, paid: 0, discount: 0 }) }));
  });

export const saveCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => couponInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const row = {
      code: data.code, kind: data.kind, value: data.value, max_discount: data.maxDiscount ?? null, min_amount: data.minAmount,
      products: data.products, max_uses: data.maxUses ?? null, per_user_limit: data.perUserLimit,
      starts_at: data.startsAt ?? null, expires_at: data.expiresAt ?? null, active: data.active, note: data.note || null,
    };
    if (data.id) {
      const { data: saved, error } = await supabaseAdmin.from("coupons").update(row).eq("id", data.id).select("id").maybeSingle();
      if (error) throw new PublicError(error.code === "23505" ? "That code is already used by another coupon." : "Could not save the coupon.");
      if (!saved) throw new PublicError("Coupon not found.");
      await adminAudit(context.userId, "coupon.update", data.id, { code: data.code });
      return { ok: true, id: saved.id };
    }
    const { data: saved, error } = await supabaseAdmin.from("coupons").insert({ ...row, created_by: context.userId }).select("id").single();
    if (error || !saved) throw new PublicError(error?.code === "23505" ? "That code already exists." : "Could not create the coupon.");
    await adminAudit(context.userId, "coupon.create", saved.id, { code: data.code });
    return { ok: true, id: saved.id };
  });

export const deleteCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { id: string }) => ({ id: uuid.parse(d.id) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { count } = await supabaseAdmin.from("orders").select("id", { count: "exact", head: true }).eq("coupon_id", data.id);
    // Used coupons are only switched off so order history keeps its link.
    if ((count ?? 0) > 0) {
      await supabaseAdmin.from("coupons").update({ active: false }).eq("id", data.id);
      await adminAudit(context.userId, "coupon.disable", data.id);
      return { ok: true, message: "Coupon was already used, so it was switched off instead." };
    }
    await supabaseAdmin.from("coupons").delete().eq("id", data.id);
    await adminAudit(context.userId, "coupon.delete", data.id);
    return { ok: true, message: "Coupon deleted." };
  });

const plexusInput = z.object({
  clusters: z.record(z.string().max(40), z.number().int().min(1)),
  images: z.record(z.string().max(40), z.number().int().min(1)),
  vpsOs: siteSettingsSchema.shape.vpsOs,
});

/** Saves Plexus cluster / image mappings (private) and the VPS OS list (public). */
export const savePlexusSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => plexusInput.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit, loadPanelSettings, loadSiteSettings } = await import("@/lib/billing.server");
    const { normalizePanelSettings } = await import("@/config/settings");
    const keys = new Set(data.vpsOs.map((o) => o.key));
    const images = Object.fromEntries(Object.entries(data.images).filter(([k]) => keys.has(k)));
    const panel = { ...normalizePanelSettings(await loadPanelSettings()), plexus: { clusters: data.clusters, images } };
    const site = { ...(await loadSiteSettings()), vpsOs: data.vpsOs };
    const [p, s] = await Promise.all([
      supabaseAdmin.from("panel_settings").update({ data: panel as never, updated_at: new Date().toISOString() }).eq("id", 1).select("id").maybeSingle(),
      supabaseAdmin.from("site_settings").update({ data: site as never, updated_at: new Date().toISOString() }).eq("id", 1).select("id").maybeSingle(),
    ]);
    if (p.error || !p.data || s.error || !s.data) throw new PublicError("Could not save Plexus settings.");
    await adminAudit(context.userId, "settings.plexus.update", null);
    return { ok: true };
  });

/** Reads clusters and images from Plexus so the admin can map them. */
export const testPlexusConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { plexusCatalog } = await import("@/lib/plexus.server");
    const { adminAudit } = await import("@/lib/billing.server");
    await adminAudit(context.userId, "plexus.test", null);
    try {
      return { ok: true as const, ...(await plexusCatalog()) };
    } catch (e) {
      const detail = e instanceof Error && "detail" in e ? String((e as { detail: unknown }).detail ?? "") : "";
      console.error("Plexus test failed", detail);
      return { ok: false as const, message: "Could not reach Plexus. Check the address and API key." };
    }
  });
