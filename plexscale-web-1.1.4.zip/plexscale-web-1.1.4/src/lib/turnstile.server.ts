// Server-only Cloudflare Turnstile verification. Tokens are single use and expire after 5 minutes.
// There is no test mode: without both keys every check fails, so sign-in and new tickets are refused.
import { clientIp } from "./client-ip.server";

type TurnstileAction = "login" | "ticket";

// Cloudflare's public testing keys (1x..., 2x..., 3x...) always pass or always fail; they are never accepted.
const TEST_KEY = /^[123]x0{8,}/i;

/** The public site key, or null when Turnstile is not fully configured (both real keys are required). */
export function turnstileSiteKey(): string | null {
  const siteKey = process.env["TURNSTILE_SITE_KEY"]?.trim();
  const secretKey = process.env["TURNSTILE_SECRET_KEY"]?.trim();
  if (!siteKey || !secretKey || TEST_KEY.test(siteKey) || TEST_KEY.test(secretKey)) return null;
  return siteKey;
}

export async function verifyTurnstileToken(token: string, action: TurnstileAction): Promise<boolean> {
  const secretKey = process.env["TURNSTILE_SECRET_KEY"]?.trim();
  if (!turnstileSiteKey() || !secretKey) return false;
  const body = new URLSearchParams({ secret: secretKey, response: token });
  const ip = clientIp();
  if (ip) body.set("remoteip", ip);
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", { method: "POST", body, signal: AbortSignal.timeout(8000) });
    if (!res.ok) return false;
    const r = (await res.json()) as { success?: unknown; action?: unknown };
    return r.success === true && r.action === action;
  } catch {
    return false;
  }
}
