import { PublicError } from "@/lib/public-error";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { MAX_OPEN_TICKETS, MAX_REPLIES_PER_10_MIN, MAX_TICKETS_PER_HOUR, newTicketInput, replyBody } from "@/config/support";

const uuid = z.string().uuid();
import { assertAdmin } from "@/lib/admin-guard";

// ---------- Customer ----------

export const createTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: unknown) => newTicketInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    const { verifyTurnstileToken } = await import("@/lib/turnstile.server");
    await assertRateLimit("ticket", { userId: context.userId, perUser: 5, perIp: 15, windowSeconds: 3600, message: "You opened several tickets recently. Please wait a little before opening another." });
    if (!(await verifyTurnstileToken(data.turnstileToken, "ticket"))) throw new PublicError("Security check failed. Please complete it again.");
    await assertNotMaintenance(context.userId);
    const [{ count: open }, { count: recent }] = await Promise.all([
      supabaseAdmin.from("support_tickets").select("id", { count: "exact", head: true }).eq("user_id", context.userId).neq("status", "closed"),
      supabaseAdmin.from("support_tickets").select("id", { count: "exact", head: true }).eq("user_id", context.userId).gte("created_at", new Date(Date.now() - 3600_000).toISOString()),
    ]);
    if ((open ?? 0) >= MAX_OPEN_TICKETS) throw new PublicError(`You have ${MAX_OPEN_TICKETS} open tickets. Please reply in an existing ticket or close one first.`);
    if ((recent ?? 0) >= MAX_TICKETS_PER_HOUR) throw new PublicError("You opened several tickets recently. Please wait a little before opening another.");
    let orderId: string | null = null;
    if (data.orderId) {
      const { data: o } = await supabaseAdmin.from("orders").select("id, user_id").eq("id", data.orderId).maybeSingle();
      if (!o || o.user_id !== context.userId) throw new PublicError("That service was not found on your account.");
      orderId = o.id;
    }
    const { data: ticket, error } = await supabaseAdmin.from("support_tickets").insert({ user_id: context.userId, subject: data.subject, category: data.category, priority: data.priority, order_id: orderId }).select("id, number").single();
    if (error || !ticket) throw new PublicError("Could not open your ticket. Please try again.");
    const { error: msgError } = await supabaseAdmin.from("ticket_messages").insert({ ticket_id: ticket.id, author_id: context.userId, is_staff: false, body: data.body });
    if (msgError) {
      await supabaseAdmin.from("support_tickets").delete().eq("id", ticket.id);
      throw new PublicError("Could not open your ticket. Please try again.");
    }
    const { notifyTicket } = await import("@/lib/notify.server");
    await notifyTicket("created", ticket.id, data.body);
    return { id: ticket.id, number: ticket.number };
  });

export const replyTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string; body: string }) => z.object({ ticketId: uuid, body: replyBody }).parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("reply", { userId: context.userId, perUser: 20, perIp: 60, windowSeconds: 600, message: "You are sending messages too quickly. Please wait a few minutes." });
    await assertNotMaintenance(context.userId);
    const { data: t } = await supabaseAdmin.from("support_tickets").select("id, user_id, status").eq("id", data.ticketId).maybeSingle();
    if (!t || t.user_id !== context.userId) throw new PublicError("Ticket not found.");
    const { count } = await supabaseAdmin.from("ticket_messages").select("id", { count: "exact", head: true }).eq("author_id", context.userId).gte("created_at", new Date(Date.now() - 10 * 60_000).toISOString());
    if ((count ?? 0) >= MAX_REPLIES_PER_10_MIN) throw new PublicError("You are sending messages too quickly. Please wait a few minutes.");
    const { error } = await supabaseAdmin.from("ticket_messages").insert({ ticket_id: t.id, author_id: context.userId, is_staff: false, body: data.body });
    if (error) throw new PublicError("Could not send your reply.");
    const now = new Date().toISOString();
    await supabaseAdmin.from("support_tickets").update({ status: "customer_reply", last_message_at: now, user_last_read_at: now }).eq("id", t.id);
    const { notifyTicket } = await import("@/lib/notify.server");
    await notifyTicket("customer_reply", t.id, data.body);
    return { ok: true };
  });

export const closeMyTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string }) => ({ ticketId: uuid.parse(d.ticketId) }))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: t } = await supabaseAdmin.from("support_tickets").update({ status: "closed" }).eq("id", data.ticketId).eq("user_id", context.userId).select("id").maybeSingle();
    if (!t) throw new PublicError("Ticket not found.");
    return { ok: true };
  });

export const markTicketRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string }) => ({ ticketId: uuid.parse(d.ticketId) }))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("support_tickets").update({ user_last_read_at: new Date().toISOString() }).eq("id", data.ticketId).eq("user_id", context.userId);
    return { ok: true };
  });

// ---------- Staff ----------

export const adminListTickets = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: tickets } = await supabaseAdmin.from("support_tickets").select("id, number, user_id, subject, category, priority, status, order_id, last_message_at, staff_last_read_at, created_at").order("last_message_at", { ascending: false }).limit(500);
    const ids = [...new Set((tickets ?? []).map((t) => t.user_id))];
    const { data: profiles } = ids.length ? await supabaseAdmin.from("profiles").select("id, email, display_name").in("id", ids) : { data: [] };
    return { tickets: tickets ?? [], profiles: profiles ?? [] };
  });

export const adminGetTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string }) => ({ ticketId: uuid.parse(d.ticketId) }))
  .handler(async ({ data, context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: ticket } = await supabaseAdmin.from("support_tickets").select("*").eq("id", data.ticketId).maybeSingle();
    if (!ticket) throw new PublicError("Ticket not found.");
    const [{ data: messages }, { data: profile }, order] = await Promise.all([
      supabaseAdmin.from("ticket_messages").select("id, author_id, is_staff, is_internal, body, created_at").eq("ticket_id", ticket.id).order("created_at", { ascending: true }).limit(500),
      supabaseAdmin.from("profiles").select("id, email, display_name").eq("id", ticket.user_id).maybeSingle(),
      ticket.order_id ? supabaseAdmin.from("orders").select("id, server_name, plan_name, product, status, renews_at").eq("id", ticket.order_id).maybeSingle() : Promise.resolve({ data: null }),
    ]);
    await supabaseAdmin.from("support_tickets").update({ staff_last_read_at: new Date().toISOString() }).eq("id", ticket.id);
    const staffIds = [...new Set((messages ?? []).filter((m) => m.is_staff && m.author_id).map((m) => m.author_id as string))];
    const { data: staff } = staffIds.length ? await supabaseAdmin.from("profiles").select("id, email, display_name").in("id", staffIds) : { data: [] };
    return { ticket, messages: messages ?? [], customer: profile, order: order.data, staff: staff ?? [] };
  });

export const adminReplyTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string; body: string; internal?: boolean; close?: boolean }) => z.object({ ticketId: uuid, body: replyBody, internal: z.boolean().optional(), close: z.boolean().optional() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { data: t } = await supabaseAdmin.from("support_tickets").select("id").eq("id", data.ticketId).maybeSingle();
    if (!t) throw new PublicError("Ticket not found.");
    const { error } = await supabaseAdmin.from("ticket_messages").insert({ ticket_id: t.id, author_id: context.userId, is_staff: true, is_internal: Boolean(data.internal), body: data.body });
    if (error) throw new PublicError("Could not send the reply.");
    const now = new Date().toISOString();
    if (!data.internal) {
      await supabaseAdmin.from("support_tickets").update({ status: data.close ? "closed" : "answered", last_message_at: now, staff_last_read_at: now }).eq("id", t.id);
      const { notifyTicket } = await import("@/lib/notify.server");
      await notifyTicket("staff_reply", t.id, data.body);
    } else {
      await supabaseAdmin.from("support_tickets").update({ staff_last_read_at: now }).eq("id", t.id);
    }
    await adminAudit(context.userId, data.internal ? "ticket.note" : "ticket.reply", t.id);
    return { ok: true };
  });

export const adminSetTicket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { ticketId: string; status?: string; priority?: string }) => z.object({ ticketId: uuid, status: z.enum(["open", "answered", "customer_reply", "closed"]).optional(), priority: z.enum(["low", "normal", "high", "urgent"]).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const patch: { status?: string; priority?: string } = {};
    if (data.status) patch.status = data.status;
    if (data.priority) patch.priority = data.priority;
    if (!Object.keys(patch).length) return { ok: true };
    const { data: t } = await supabaseAdmin.from("support_tickets").update(patch).eq("id", data.ticketId).select("id").maybeSingle();
    if (!t) throw new PublicError("Ticket not found.");
    await adminAudit(context.userId, "ticket.update", t.id, patch);
    return { ok: true };
  });
