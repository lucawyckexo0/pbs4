// Production browser hardening: quiet console, no context menu or view-source shortcuts, no image dragging.
// This only raises the bar for casual copying; anything a browser downloads can still be saved by a determined user.

const editable = (t: EventTarget | null) =>
  t instanceof HTMLElement && (t.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(t.tagName));

function blockedShortcut(e: KeyboardEvent) {
  const k = e.key.toLowerCase();
  const mod = e.ctrlKey || e.metaKey;
  if (k === "f12") return true;
  if (mod && (e.shiftKey || e.altKey) && ["i", "j", "c", "k"].includes(k)) return true;
  if (mod && ["u", "s"].includes(k)) return true;
  return false;
}

let installed = false;

export function installClientGuard() {
  if (installed || typeof window === "undefined" || !import.meta.env.PROD) return;
  installed = true;

  const quiet = () => undefined;
  for (const m of ["log", "info", "debug", "warn", "error", "trace", "table", "dir", "dirxml", "group", "groupCollapsed", "time", "timeEnd", "count", "assert"] as const) {
    try { (console as unknown as Record<string, unknown>)[m] = quiet; } catch { /* read-only console */ }
  }

  // Uncaught errors stay out of the console.
  window.addEventListener("error", (e) => e.preventDefault(), true);
  window.addEventListener("unhandledrejection", (e) => e.preventDefault(), true);

  document.addEventListener("contextmenu", (e) => { if (!editable(e.target)) e.preventDefault(); }, true);
  document.addEventListener("keydown", (e) => { if (blockedShortcut(e)) { e.preventDefault(); e.stopPropagation(); } }, true);
  document.addEventListener("dragstart", (e) => { if (e.target instanceof HTMLImageElement) e.preventDefault(); }, true);
  document.addEventListener("copy", (e) => {
    const sel = window.getSelection();
    if (sel && sel.toString().length > 2000 && !editable(e.target)) e.preventDefault();
  }, true);
}
