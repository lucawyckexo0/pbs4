// Server-only: renders invoice PDFs with pdf-lib (pure JavaScript, no filesystem).
import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from "pdf-lib";
import { LOGO_PNG_BASE64, LOGO_PNG_HEIGHT, LOGO_PNG_WIDTH } from "./brand-logo.server";

export interface InvoiceData {
  number: string;
  issuedAt: string;
  kind: "new" | "renewal" | "upgrade" | "credits";
  seller: { name: string; address: string; gstin: string; email: string };
  buyer: { name: string; email: string; address: string; phone: string; gstin: string };
  items: { description: string; detail: string; amount: number }[];
  total: number;
  paymentId: string;
  orderId: string;
  note: string;
}

// Standard PDF fonts only cover Latin-1; anything else becomes "?" instead of breaking the file.
const safe = (s: string) => s.replace(/₹/g, "INR ").replace(/[^\x20-\x7e\u00a0-\u00ff]/g, "?");
const money = (n: number) => `INR ${new Intl.NumberFormat("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n)}`;
const day = (iso: string) => new Date(iso).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", timeZone: "Asia/Kolkata" });

function wrapText(text: string, font: PDFFont, size: number, width: number): string[] {
  const out: string[] = [];
  for (const para of safe(text).split(/\n/)) {
    let line = "";
    for (const word of para.split(/\s+/)) {
      const next = line ? `${line} ${word}` : word;
      if (font.widthOfTextAtSize(next, size) <= width) line = next;
      else { if (line) out.push(line); line = word; }
    }
    out.push(line);
  }
  return out;
}

export async function renderInvoicePdf(inv: InvoiceData): Promise<Uint8Array> {
  const pdf = await PDFDocument.create();
  pdf.setTitle(`Invoice ${inv.number}`);
  pdf.setAuthor(safe(inv.seller.name));
  pdf.setCreator("PlexScale");
  pdf.setProducer("PlexScale");
  const page: PDFPage = pdf.addPage([595.28, 841.89]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.03, 0.04, 0.1);
  const muted = rgb(0.42, 0.47, 0.6);
  const banner = rgb(0.184, 0.435, 0.929); // #2f6fed, same blue as the email header
  const white = rgb(0.96, 0.97, 1);
  const onBanner = rgb(0.87, 0.91, 1);
  const line = rgb(0.88, 0.9, 0.95);
  const W = page.getWidth();
  const M = 48;

  page.drawRectangle({ x: 0, y: 841.89 - 110, width: W, height: 110, color: banner });
  try {
    const logo = await pdf.embedPng(Uint8Array.from(atob(LOGO_PNG_BASE64), (c) => c.charCodeAt(0)));
    const logoH = 26;
    page.drawImage(logo, { x: M, y: 841.89 - 68, width: (LOGO_PNG_WIDTH / LOGO_PNG_HEIGHT) * logoH, height: logoH });
  } catch {
    // Fall back to the text wordmark if the image cannot be embedded.
    page.drawText("PlexScale", { x: M, y: 841.89 - 64, size: 24, font: bold, color: white });
  }
  page.drawText("Game servers, VPS and bot hosting", { x: M, y: 841.89 - 84, size: 9, font, color: onBanner });
  const title = "INVOICE";
  page.drawText(title, { x: W - M - bold.widthOfTextAtSize(title, 22), y: 841.89 - 62, size: 22, font: bold, color: white });
  const num = safe(inv.number);
  page.drawText(num, { x: W - M - font.widthOfTextAtSize(num, 10), y: 841.89 - 82, size: 10, font, color: onBanner });

  let y = 841.89 - 150;
  const label = (t: string, x: number, yy: number) => page.drawText(t, { x, y: yy, size: 8, font: bold, color: muted });
  const text = (t: string, x: number, yy: number, size = 10, f: PDFFont = font, color = ink) => page.drawText(safe(t), { x, y: yy, size, font: f, color });

  label("BILLED BY", M, y);
  label("BILLED TO", W / 2, y);
  y -= 16;
  const sellerLines = [inv.seller.name, ...wrapText(inv.seller.address, font, 10, W / 2 - M - 20), inv.seller.gstin ? `GSTIN: ${inv.seller.gstin}` : "", inv.seller.email].filter(Boolean);
  const buyerLines = [inv.buyer.name || inv.buyer.email, ...(inv.buyer.address ? wrapText(inv.buyer.address, font, 10, W / 2 - M) : []), inv.buyer.phone, inv.buyer.gstin ? `GSTIN: ${inv.buyer.gstin}` : "", inv.buyer.name ? inv.buyer.email : ""].filter(Boolean);
  const rows = Math.max(sellerLines.length, buyerLines.length);
  for (let i = 0; i < rows; i++) {
    if (sellerLines[i]) text(sellerLines[i]!, M, y, 10, i === 0 ? bold : font);
    if (buyerLines[i]) text(buyerLines[i]!, W / 2, y, 10, i === 0 ? bold : font);
    y -= 14;
  }

  y -= 14;
  const paidWithCredits = inv.paymentId.startsWith("credits_");
  const meta: [string, string][] = [["Invoice date", day(inv.issuedAt)], ["Invoice number", inv.number], ["Order reference", inv.orderId.slice(0, 8).toUpperCase()], ["Payment", paidWithCredits ? "PlexScale Credits" : inv.paymentId || "-"]];
  const colW = (W - 2 * M) / meta.length;
  page.drawRectangle({ x: M, y: y - 34, width: W - 2 * M, height: 46, color: rgb(0.965, 0.972, 0.99), borderColor: line, borderWidth: 1 });
  meta.forEach(([k, v], i) => { label(k.toUpperCase(), M + 12 + i * colW, y - 2); text(v, M + 12 + i * colW, y - 20, 9.5, bold); });
  y -= 72;

  label("DESCRIPTION", M, y);
  const amtLabel = "AMOUNT";
  label(amtLabel, W - M - bold.widthOfTextAtSize(amtLabel, 8), y);
  y -= 8;
  page.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: 1, color: line });
  y -= 20;
  for (const it of inv.items) {
    text(it.description, M, y, 11, bold);
    const a = money(it.amount);
    text(a, W - M - bold.widthOfTextAtSize(safe(a), 11), y, 11, bold);
    y -= 15;
    for (const l of wrapText(it.detail, font, 9.5, W - 2 * M - 120)) { text(l, M, y, 9.5, font, muted); y -= 13; }
    y -= 10;
    page.drawLine({ start: { x: M, y: y + 4 }, end: { x: W - M, y: y + 4 }, thickness: 0.5, color: line });
    y -= 10;
  }

  y -= 6;
  const totalLabel = "Total paid";
  const totalValue = money(inv.total);
  page.drawRectangle({ x: W / 2, y: y - 14, width: W / 2 - M, height: 38, color: ink });
  text(totalLabel, W / 2 + 14, y, 11, bold, white);
  text(totalValue, W - M - 14 - bold.widthOfTextAtSize(safe(totalValue), 13), y, 13, bold, white);
  y -= 44;
  text(paidWithCredits ? "Status: PAID with PlexScale Credits" : "Status: PAID via Razorpay", W / 2, y, 9, bold, rgb(0.18, 0.62, 0.38));

  let fy = 110;
  for (const l of wrapText(inv.note, font, 8.5, W - 2 * M)) { text(l, M, fy, 8.5, font, muted); fy -= 12; }
  text("This is a computer generated invoice and does not require a signature.", M, fy - 4, 8.5, font, muted);
  page.drawLine({ start: { x: M, y: 130 }, end: { x: W - M, y: 130 }, thickness: 0.5, color: line });
  text("Thank you for choosing PlexScale.", M, 48, 9, bold, banner);

  return pdf.save();
}
