// Plan prices for page titles and JSON-LD, including Administrator price overrides from the root loader.
import { effectivePlans, formatINR, fromPrice, type Plan, type PlanOverride } from "@/config/plans";

type RootMatch = { loaderData?: { plans?: Record<string, PlanOverride> } } | undefined;

/** Visible plans for a product, using the site settings the root route loaded (matches[0]). */
export function seoPlans(matches: readonly unknown[] | undefined, product: string): Plan[] {
  const root = matches?.[0] as RootMatch;
  return effectivePlans(product, root?.loaderData?.plans ?? {});
}

export const fromLabel = (plans: Plan[]) => formatINR(fromPrice(plans));
