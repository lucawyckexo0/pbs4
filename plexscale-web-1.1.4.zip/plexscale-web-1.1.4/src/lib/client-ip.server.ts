import { getRequestHeader } from "@tanstack/react-start/server";
import { cloudflareIp } from "@/lib/ip";

/**
 * The visitor's IP for the current request, taken only from Cloudflare's CF-Connecting-IP header.
 * The site is reachable only through the Cloudflare tunnel, which always sets it. X-Forwarded-For,
 * X-Real-IP and every other forwarded-IP header are ignored because a client can write them.
 */
export function clientIp(): string | null {
  try {
    return cloudflareIp({ get: (name: string) => getRequestHeader(name) ?? null });
  } catch {
    return null;
  }
}
