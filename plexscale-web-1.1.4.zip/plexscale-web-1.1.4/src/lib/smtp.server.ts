// Server-only minimal SMTP client on Node's built-in net/tls (submission over STARTTLS on 587 or implicit TLS on 465).
import net, { type Socket as Sock } from "node:net";
import tls from "node:tls";
// Plaintext authentication is refused: the connection must be encrypted before credentials are sent.

interface SmtpConfig {
  host: string;
  port: number;
  security: "starttls" | "tls";
  username: string;
  password: string;
}

export interface MailAttachment { filename: string; contentType: string; content: Uint8Array }
interface Mail {
  fromName: string;
  fromEmail: string;
  to: string;
  replyTo?: string | undefined;
  subject: string;
  text: string;
  html: string;
  attachments?: MailAttachment[] | undefined;
}

class SmtpError extends Error {}

const EMAIL_RE = /^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,24}$/;
export const isSafeEmail = (e: string) => e.length <= 254 && EMAIL_RE.test(e);

const enc = new TextEncoder();
const dec = new TextDecoder();

function b64(bytes: Uint8Array) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
const wrap76 = (s: string) => s.replace(/.{1,76}/g, "$&\r\n").trimEnd();
const encodeWord = (s: string) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(enc.encode(s))}?=`);
const stripHeader = (s: string) => s.replace(/[\r\n\0]/g, " ").trim();

interface Transport {
  write(data: string): Promise<void>;
  readChunk(): Promise<string>;
  upgrade(): Promise<void>;
  close(): void;
}

// Node's built-in net / tls modules. Certificates are always verified against the system CA store.
async function nodeTransport(cfg: SmtpConfig): Promise<Transport> {
  let chunks: string[] = [];
  let waiter: ((v: string | Error) => void) | null = null;
  let failure: Error | null = null;
  const push = (v: string | Error) => {
    if (waiter) { const w = waiter; waiter = null; w(v); return; }
    if (v instanceof Error) failure = v; else chunks.push(v);
  };
  const attach = (s: Sock) => {
    s.on("data", (d: Buffer) => push(d.toString("utf8")));
    s.on("error", (e: Error) => push(new SmtpError(`Mail server connection failed: ${e.message.slice(0, 120)}`)));
    s.on("close", () => push(new SmtpError("Connection closed by the mail server.")));
  };
  let sock: Sock = await new Promise<Sock>((resolve, reject) => {
    const s = cfg.security === "tls"
      ? tls.connect({ host: cfg.host, port: cfg.port, servername: cfg.host, rejectUnauthorized: true, minVersion: "TLSv1.2" }, () => resolve(s))
      : net.connect({ host: cfg.host, port: cfg.port }, () => resolve(s));
    s.once("error", reject);
  });
  attach(sock);
  return {
    async write(data) { await new Promise<void>((res, rej) => sock.write(data, (e) => (e ? rej(e) : res()))); },
    readChunk() {
      if (failure) return Promise.reject(failure);
      const next = chunks.shift();
      if (next !== undefined) return Promise.resolve(next);
      return new Promise<string>((res, rej) => { waiter = (v) => (v instanceof Error ? rej(v) : res(v)); });
    },
    async upgrade() {
      sock.removeAllListeners("data"); sock.removeAllListeners("error"); sock.removeAllListeners("close");
      chunks = []; failure = null;
      sock = await new Promise<Sock>((resolve, reject) => {
        const s = tls.connect({ socket: sock, servername: cfg.host, rejectUnauthorized: true, minVersion: "TLSv1.2" }, () => resolve(s));
        s.once("error", reject);
      });
      attach(sock);
    },
    close() { try { sock.end(); sock.destroy(); } catch { /* already closed */ } },
  };
}

class Conversation {
  private buf = "";
  constructor(private t: Transport, private deadline: number) {}

  private async withTimeout<T>(p: Promise<T>): Promise<T> {
    const left = this.deadline - Date.now();
    if (left <= 0) throw new SmtpError("The mail server took too long to respond.");
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([p, new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new SmtpError("The mail server took too long to respond.")), left); })]);
    } finally { if (timer) clearTimeout(timer); }
  }

  async response(): Promise<{ code: number; lines: string[] }> {
    const lines: string[] = [];
    for (;;) {
      let idx = this.buf.indexOf("\r\n");
      while (idx === -1) {
        if (this.buf.length > 64_000) throw new SmtpError("Unexpected reply from the mail server.");
        this.buf += await this.withTimeout(this.t.readChunk());
        idx = this.buf.indexOf("\r\n");
      }
      const line = this.buf.slice(0, idx);
      this.buf = this.buf.slice(idx + 2);
      lines.push(line);
      if (/^\d{3}(?: |$)/.test(line)) return { code: Number(line.slice(0, 3)), lines };
      if (!/^\d{3}-/.test(line)) throw new SmtpError("Unexpected reply from the mail server.");
    }
  }

  async expect(codes: number[], label: string) {
    const r = await this.response();
    if (!codes.includes(r.code)) throw new SmtpError(`${label} was refused by the mail server (${r.code} ${(r.lines.at(-1) ?? "").slice(4, 120)}).`);
    return r;
  }

  async cmd(line: string, codes: number[], label: string) {
    await this.withTimeout(this.t.write(`${line}\r\n`));
    return this.expect(codes, label);
  }

  async raw(data: string) { await this.withTimeout(this.t.write(data)); }
  resetBuffer() { this.buf = ""; }
}

function buildMessage(m: Mail) {
  const domain = m.fromEmail.split("@")[1] ?? "localhost";
  const id = crypto.randomUUID();
  const mixed = `mixed_${id.replace(/-/g, "")}`;
  const alt = `alt_${id.replace(/-/g, "")}`;
  const headers = [
    `From: ${m.fromName ? `${encodeWord(stripHeader(m.fromName))} ` : ""}<${m.fromEmail}>`,
    `To: <${m.to}>`,
    ...(m.replyTo ? [`Reply-To: <${m.replyTo}>`] : []),
    `Subject: ${encodeWord(stripHeader(m.subject))}`,
    `Date: ${new Date().toUTCString().replace("GMT", "+0000")}`,
    `Message-ID: <${id}@${domain}>`,
    "MIME-Version: 1.0",
    "Auto-Submitted: auto-generated",
    `Content-Type: multipart/mixed; boundary="${mixed}"`,
  ];
  const parts = [
    `--${mixed}`,
    `Content-Type: multipart/alternative; boundary="${alt}"`,
    "",
    `--${alt}`,
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(b64(enc.encode(m.text))),
    `--${alt}`,
    "Content-Type: text/html; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    wrap76(b64(enc.encode(m.html))),
    `--${alt}--`,
  ];
  for (const a of m.attachments ?? []) {
    const filename = a.filename.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 80) || "attachment";
    const type = /^[a-z]+\/[a-z0-9.+-]+$/i.test(a.contentType) ? a.contentType : "application/octet-stream";
    parts.push(`--${mixed}`, `Content-Type: ${type}; name="${filename}"`, "Content-Transfer-Encoding: base64", `Content-Disposition: attachment; filename="${filename}"`, "", wrap76(b64(a.content)));
  }
  parts.push(`--${mixed}--`);
  // Base64 bodies never start a line with "." so no dot-stuffing is needed; headers are checked above.
  return `${headers.join("\r\n")}\r\n\r\n${parts.join("\r\n")}\r\n`;
}

/** Sends one email. Throws SmtpError with a short, credential-free reason on failure. */
export async function sendSmtp(cfg: SmtpConfig, mail: Mail, timeoutMs = 25_000): Promise<void> {
  if (!cfg.host || !cfg.port) throw new SmtpError("SMTP server is not configured.");
  if (!isSafeEmail(mail.fromEmail) || !isSafeEmail(mail.to) || (mail.replyTo && !isSafeEmail(mail.replyTo))) throw new SmtpError("Invalid email address.");
  if (cfg.port === 25) throw new SmtpError("Port 25 is not supported. Use 587 (STARTTLS) or 465 (TLS).");

  const t = await nodeTransport(cfg);
  const c = new Conversation(t, Date.now() + timeoutMs);
  const ehloName = mail.fromEmail.split("@")[1] ?? "localhost";
  try {
    await c.expect([220], "Connection");
    let ehlo = await c.cmd(`EHLO ${ehloName}`, [250], "Greeting");
    if (cfg.security === "starttls") {
      if (!ehlo.lines.some((l) => /^250[ -]STARTTLS/i.test(l))) throw new SmtpError("The mail server does not offer STARTTLS. Use port 465 with TLS instead.");
      await c.cmd("STARTTLS", [220], "STARTTLS");
      await t.upgrade();
      c.resetBuffer();
      ehlo = await c.cmd(`EHLO ${ehloName}`, [250], "Greeting");
    }
    if (cfg.username) {
      const auth = ehlo.lines.find((l) => /^250[ -]AUTH/i.test(l))?.toUpperCase() ?? "";
      if (auth.includes("PLAIN") || !auth.includes("LOGIN")) {
        await c.cmd(`AUTH PLAIN ${b64(enc.encode(`\0${cfg.username}\0${cfg.password}`))}`, [235], "Sign-in");
      } else {
        await c.cmd("AUTH LOGIN", [334], "Sign-in");
        await c.cmd(b64(enc.encode(cfg.username)), [334], "Sign-in");
        await c.cmd(b64(enc.encode(cfg.password)), [235], "Sign-in");
      }
    }
    await c.cmd(`MAIL FROM:<${mail.fromEmail}>`, [250], "Sender");
    await c.cmd(`RCPT TO:<${mail.to}>`, [250, 251], "Recipient");
    await c.cmd("DATA", [354], "Message");
    await c.raw(buildMessage(mail));
    await c.cmd(".", [250], "Message");
    try { await c.cmd("QUIT", [221], "Quit"); } catch { /* message already accepted */ }
  } catch (e) {
    if (e instanceof SmtpError) throw e;
    throw new SmtpError("Could not reach the mail server. Check the host, port and security setting.");
  } finally {
    t.close();
  }
}
