import { PublicError } from "@/lib/public-error";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/admin-guard";
import { creditTopupInput, creditsErrorMessage, topupProblem } from "@/config/credits";
import { MAX_PENDING_PER_HOUR } from "@/config/order-rules";

/** The signed-in customer's balance and latest credit activity. Read through their own token (row level security). */
export const getMyCredits = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [w, tx] = await Promise.all([
      context.supabase.from("credit_wallets").select("balance, updated_at").eq("user_id", context.userId).maybeSingle(),
      context.supabase.from("credit_transactions").select("id, amount, balance_after, kind, order_id, note, created_at").eq("user_id", context.userId).order("created_at", { ascending: false }).limit(50),
    ]);
    return { balance: w.data?.balance ?? 0, transactions: tx.data ?? [] };
  });

/** Starts a Razorpay payment for a credit top-up. The amount is checked against live limits on the server. */
export const createCreditTopup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { amount: number }) => creditTopupInput.parse(d))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { loadSiteSettings, razorpayKeys, startOrderPayment, assertNotMaintenance } = await import("@/lib/billing.server");
    const { assertRateLimit } = await import("@/lib/rate-limit.server");
    await assertRateLimit("credits_topup", { userId: context.userId, perUser: 10, perIp: 30, windowSeconds: 600, failClosed: true, message: "Too many top-up attempts. Please wait a few minutes." });
    await assertNotMaintenance(context.userId);
    const settings = await loadSiteSettings();
    razorpayKeys();
    const { data: w } = await supabaseAdmin.from("credit_wallets").select("balance").eq("user_id", context.userId).maybeSingle();
    const problem = topupProblem(data.amount, w?.balance ?? 0, settings.credits);
    if (problem) throw new PublicError(problem);
    // The database re-checks the limit under a per-customer lock, counting every unpaid top-up.
    const { data: orderId, error } = await supabaseAdmin.rpc("create_topup_order", { _user_id: context.userId, _amount: data.amount, _max_balance: settings.credits.maxBalance, _max_open: MAX_PENDING_PER_HOUR });
    if (error || !orderId) {
      const code = error?.message ?? "";
      if (code.includes("topup_too_many_open")) throw new PublicError("Please finish a pending top-up before starting another.");
      if (code.includes("topup_over_limit")) throw new PublicError(`Your balance can hold up to ₹${settings.credits.maxBalance.toLocaleString("en-IN")} in credits, including unpaid top-ups.`);
      throw new PublicError("Could not start your top-up.");
    }
    const order = { id: orderId };
    const started = await startOrderPayment({ id: order.id, amount: data.amount }, { useCredits: false, notes: { kind: "credits" } });
    return started;
  });

// ---------- Administrator ----------

export const adminCreditsOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const [wallets, tx] = await Promise.all([
      context.supabase.from("credit_wallets").select("user_id, balance, updated_at").gt("balance", 0).order("balance", { ascending: false }).limit(500),
      context.supabase.from("credit_transactions").select("id, user_id, amount, balance_after, kind, order_id, note, created_by, created_at").order("created_at", { ascending: false }).limit(200),
    ]);
    const ids = [...new Set([...(wallets.data ?? []).map((w) => w.user_id), ...(tx.data ?? []).flatMap((t) => [t.user_id, t.created_by].filter((x): x is string => Boolean(x)))])];
    const { data: profiles } = ids.length ? await context.supabase.from("profiles").select("id, email, display_name").in("id", ids.slice(0, 1000)) : { data: [] };
    const outstanding = (wallets.data ?? []).reduce((s, w) => s + w.balance, 0);
    return { wallets: wallets.data ?? [], transactions: tx.data ?? [], profiles: profiles ?? [], outstanding };
  });

export const adminAdjustCredits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { email: string; amount: number; note: string }) => z.object({
    email: z.string().trim().toLowerCase().email().max(120),
    amount: z.number().int().refine((n) => n !== 0 && Math.abs(n) <= 1_000_000, "Enter an amount between -10,00,000 and 10,00,000, not zero"),
    note: z.string().trim().min(3).max(200),
  }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context, { mutate: true });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { adminAudit } = await import("@/lib/billing.server");
    const { data: profile } = await supabaseAdmin.from("profiles").select("id").eq("email", data.email).maybeSingle();
    if (!profile) throw new PublicError("No account with that email.");
    const { data: balance, error } = await supabaseAdmin.rpc("admin_adjust_credits", { _user_id: profile.id, _amount: data.amount, _note: data.note, _by: context.userId });
    if (error || balance === null) throw new PublicError(creditsErrorMessage(error?.message));
    await adminAudit(context.userId, data.amount > 0 ? "credits.grant" : "credits.deduct", profile.id, { amount: data.amount, note: data.note.slice(0, 120) });
    return { ok: true, balance };
  });
