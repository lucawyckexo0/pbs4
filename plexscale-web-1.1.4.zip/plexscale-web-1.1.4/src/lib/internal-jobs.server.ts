// Scheduled jobs (expire-services, reconcile-payments) may only be called by this server itself.
//
// Three independent checks must all pass:
// 1. The request arrived on the private Unix socket of server/index.mjs. Only that listener stamps the
//    per-process marker header; the public (tunnel) listener strips it and answers 404 for /api/internal/*.
// 2. No Cloudflare edge header is present, so a request that came through the tunnel is refused even if a
//    hostname were ever pointed at the socket by mistake.
// 3. The bearer secret matches CRON_SECRET (or CRON_SECRET_PREVIOUS while rotating), compared in constant time.
const INTERNAL_MARKER_HEADER = "x-plexscale-internal";
const MARKER_KEY = Symbol.for("plexscale.internalMarker");
const EDGE_HEADERS = ["cf-connecting-ip", "cf-ray", "cf-ipcountry", "cf-visitor", "cf-warp-tag-id", "cdn-loop", "x-forwarded-for"];

const enc = new TextEncoder();

async function digest(value: string) {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(value)));
}

function sameBytes(a: Uint8Array, b: Uint8Array) {
  let diff = a.length ^ b.length;
  for (let i = 0; i < Math.max(a.length, b.length); i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
  return diff === 0;
}

/** The marker the Node server generated at start-up, or null outside that server (dev, tests). */
function processMarker(): string | null {
  const v = (globalThis as Record<symbol, unknown>)[MARKER_KEY];
  return typeof v === "string" && v.length >= 32 ? v : null;
}

/** Returns null when the request may run the job, otherwise the response to send. Never says which check failed. */
export async function authenticateInternalJob(request: Request): Promise<Response | null> {
  const notFound = () => new Response("Not found", { status: 404 });
  const marker = processMarker();
  const given = request.headers.get(INTERNAL_MARKER_HEADER);
  if (!marker || !given || !sameBytes(await digest(given), await digest(marker))) return notFound();
  if (EDGE_HEADERS.some((h) => request.headers.has(h))) return notFound();

  const current = process.env["CRON_SECRET"];
  const previous = process.env["CRON_SECRET_PREVIOUS"];
  if (!current || current.length < 32) return new Response("Unavailable", { status: 503 });
  const token = /^Bearer ([^\s,]+)$/.exec(request.headers.get("authorization") ?? "")?.[1];
  if (!token) return new Response("Unauthorized", { status: 401 });
  const t = await digest(token);
  const ok = sameBytes(t, await digest(current)) || (previous ? sameBytes(t, await digest(previous)) : false);
  return ok ? null : new Response("Unauthorized", { status: 401 });
}
