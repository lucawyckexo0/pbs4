export function renderErrorPage(): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>PlexScale · Site syncing</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      :root { color-scheme: dark; --background: oklch(0.13 0.035 265); --foreground: oklch(0.97 0.01 260); --muted: oklch(0.72 0.025 260); --primary: oklch(0.69 0.15 255); --border: oklch(0.28 0.04 265); }
      body { font: 16px/1.6 system-ui, -apple-system, sans-serif; background: var(--background); color: var(--foreground); display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 34rem; width: 100%; text-align: center; padding: 2rem; }
      .brand { color: var(--primary); font-size: .8rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
      h1 { font-size: 1.75rem; margin: 1rem 0 .5rem; }
      p { color: var(--muted); margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.6rem 1rem; border-radius: 6px; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: var(--primary); color: var(--background); }
      .secondary { background: transparent; color: var(--foreground); border-color: var(--border); }
    </style>
  </head>
  <body>
    <div class="card">
      <div class="brand">PlexScale · Site syncing</div>
      <h1>We’re reconnecting your page</h1>
      <p>We’re having trouble loading this page. Please try again in a moment.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Return home</a>
      </div>
    </div>
  </body>
</html>`;
}
