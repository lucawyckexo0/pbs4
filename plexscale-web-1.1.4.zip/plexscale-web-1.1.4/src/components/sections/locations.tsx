import { Activity, ArrowUpRight, Signal } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLocations, useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";
import { flags } from "@/config/images";

function LocationMap({ pings }: { pings?: Record<string, number> | undefined }) {
  const settings = useSettings();
  const locations = settings.locations;
  return (
    <ul className="grid gap-3 sm:grid-cols-2">
      {locations.map((l) => (
        <li key={l.id} className="panel animated-outline min-h-32 rounded-lg p-5">
          <div className="flex items-center gap-3">
            {flags[l.country] && <img src={flags[l.country]} alt={`${l.region} flag`} width={32} height={16} loading="lazy" className="h-4 w-8 shrink-0 rounded-sm object-cover ring-1 ring-steel" />}
            <h3 className="text-base font-semibold">{l.city}</h3>
          </div>
          <p className="mt-2 text-sm text-muted-foreground">{l.region}</p>
          <div className="mt-4 flex items-center justify-between gap-2 text-xs">
            <span className="inline-flex items-center gap-2 text-ok"><span className="size-1.5 rounded-full bg-ok" />Online</span>
            <span className="inline-flex items-center gap-1.5 text-muted-foreground"><Signal className="size-3.5 text-azure" /><span className="tabular-nums">{pings?.[l.id] != null ? `${pings[l.id]} ms` : "EPYC · NVMe"}</span></span>
          </div>
        </li>
      ))}
      <li className="flex min-h-32 flex-col justify-center border-l-2 border-azure px-5"><p className="font-display text-sm font-semibold">One network. {locations.length} locations.</p><p className="mt-2 text-xs text-muted-foreground">{[...new Set(locations.map((l) => l.region))].join(" · ")} <ArrowUpRight className="ml-1 inline size-3" /></p></li>
    </ul>
  );
}

function usePingTest() {
  const locations = useLocations();
  const [pings, setPings] = useState<Record<string, number> | undefined>();
  const [running, setRunning] = useState(false);
  const run = () => {
    setRunning(true);
    setPings(undefined);
    // Mock values until the backend ping endpoints exist.
    setTimeout(() => {
      setPings(Object.fromEntries(locations.map((l) => [l.id, l.mockPing + Math.round(Math.random() * 6)])));
      setRunning(false);
    }, 900);
  };
  return { pings, running, run };
}

export function LocationsSection({ withCards }: { withCards?: boolean }) {
  const locations = useLocations();
  const { pings, running, run } = usePingTest();
  return (
    <section id="locations" className="section container-px scroll-mt-20">
      <div className={cn("grid gap-10 lg:items-center", withCards ? "lg:grid-cols-[1fr_2fr]" : "lg:grid-cols-[1fr_2fr]")}>
        <div>
          <p className="eyebrow">Locations</p>
          <h2 className="mt-2">Close to your players</h2>
          <p className="measure mt-4 text-muted-foreground">{locations.map((l) => l.city).join(", ")}. Pick the one nearest your community.</p>
          <Button onClick={run} disabled={running} size="lg" className="mt-8">
            <Activity /> {running ? "Testing..." : "Test your ping"}
          </Button>
          <p className="mt-3 text-xs text-muted-foreground">Approximate ping to each location.</p>
        </div>
        <div><LocationMap pings={pings} /></div>
      </div>
    </section>
  );
}
