import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { useEffect, useState } from "react";
import { btn } from "@/components/ui-px/btn";
import { billingPeriods, cpuLabel, formatINR, periodSuffix, periodTotal, planLines, type Billing, type Plan } from "@/config/plans";
import { cn } from "@/lib/utils";
import { usePlans, useSettings } from "@/hooks/use-settings";

export function BillingToggle({ value, onChange }: { value: Billing; onChange: (b: Billing) => void }) {
  return (
    <div role="radiogroup" aria-label="Billing period" className="inline-flex max-w-full flex-wrap rounded-md border border-steel bg-graphite p-1">
      {billingPeriods.map((p) => (
        <button
          key={p.key}
          type="button"
          role="radio"
          aria-checked={value === p.key}
          onClick={() => onChange(p.key)}
          className={cn(
            "rounded-[6px] px-3 py-1.5 text-sm whitespace-nowrap transition-colors duration-150",
            value === p.key ? "bg-primary text-primary-foreground font-semibold" : "text-muted-foreground hover:text-foreground",
          )}
        >
          {p.label}
          {p.discount > 0 && <span className={cn("ml-1 text-xs", value === p.key ? "text-primary-foreground/75" : "text-azure")}>{Math.round(p.discount * 100)}% off</span>}
        </button>
      ))}
    </div>
  );
}

function Price({ value, className }: { value: number; className?: string }) {
  const [k, setK] = useState(0);
  useEffect(() => setK((x) => x + 1), [value]);
  return <span key={k} className={cn("inline-block animate-tick tabular-nums", className)}>{formatINR(value)}</span>;
}

/** One plan feature line. "Label: value" shows the label muted. */
export function PlanLine({ line }: { line: string }) {
  const i = line.indexOf(":");
  const hasLabel = i > 0 && i < 24;
  return (
    <li className="flex gap-2">
      <Check className="mt-0.5 size-4 shrink-0 text-azure" />
      <span>{hasLabel ? <><span className="text-muted-foreground">{line.slice(0, i + 1)}</span>{line.slice(i + 1)}</> : line}</span>
    </li>
  );
}

function PlanCard({ plan, billing, kind, features, outOfStock }: { plan: Plan; billing: Billing; kind: string; features: string[]; outOfStock?: boolean }) {
  const total = periodTotal(plan.monthly, billing);
  return (
    <article className={cn("panel relative flex flex-col p-6 transition-colors duration-150 hover:border-azure/60", plan.popular && "border-azure")}>
      {plan.popular && !outOfStock && <span className="absolute -top-3 left-6 rounded-md bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">Most popular</span>}
      {outOfStock && <span className="absolute -top-3 left-6 rounded-md border border-destructive/60 bg-graphite px-2 py-0.5 text-xs font-semibold text-destructive">Out of stock</span>}
      <p className="text-sm text-muted-foreground">{plan.name.includes("GB") ? "Memory" : plan.name}</p>
      <h3 className="mt-1 text-3xl font-bold">{plan.ramLabel} <span className="text-base font-medium text-muted-foreground">RAM</span></h3>
      <p className="mt-1 text-sm text-muted-foreground">{plan.vcpu ? `${plan.vcpu} vCPU` : cpuLabel(plan)} · {plan.storage} NVMe</p>
      <p className="mt-6 font-display text-3xl font-bold text-azure">
        <Price value={total} />
        <span className="ml-1 text-sm font-medium text-muted-foreground">{periodSuffix[billing]}</span>
      </p>
      <p className="text-xs text-muted-foreground">GST included</p>
      <ul className="mt-6 space-y-2 border-t border-steel pt-6 text-sm">
        {planLines(plan, features).map((line, i) => <PlanLine key={`${i}-${line}`} line={line} />)}
      </ul>
      {outOfStock ? (
        <button type="button" disabled className={cn(btn({ variant: "secondary" }), "mt-8 w-full")}>Out of stock</button>
      ) : (
        <Link to="/deploy" search={{ product: kind, plan: plan.id, billing }} className={cn(btn({ variant: "secondary" }), "mt-8 w-full")}>
          Select
        </Link>
      )}
    </article>
  );
}

export function PlanGrid({ kind, features, refundNote, title = "Pick your plan" }: { plans?: Plan[]; kind: string; features: string[]; refundNote?: boolean; title?: string }) {
  const [billing, setBilling] = useState<Billing>("monthly");
  const plans = usePlans(kind);
  const { ordering } = useSettings();
  const outOfStock = ordering.disabledProducts.includes(kind);
  const paused = !ordering.enabled || outOfStock;
  return (
    <section id="plans" className="section container-px">
      <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="eyebrow">Plans</p>
          <h2 className="mt-2">{title}</h2>
          <p className="mt-2 text-muted-foreground">All prices in INR, GST included. No auto renew.</p>
        </div>
        <BillingToggle value={billing} onChange={setBilling} />
      </div>
      {paused && <p role="status" className={cn("panel mt-8 p-4 text-sm", outOfStock ? "border-destructive/50" : "border-azure/50")}>{outOfStock ? "This product is out of stock right now. Existing services are not affected. Please check back soon." : ordering.pausedMessage || "New orders are paused right now."}</p>}
      <div className={cn("mt-10 grid gap-6 sm:grid-cols-2", plans.length > 4 ? "lg:grid-cols-4" : plans.length === 4 ? "lg:grid-cols-4" : "lg:grid-cols-3")}>
        {plans.map((p) => <PlanCard key={p.id} plan={p} billing={billing} kind={kind} features={features} outOfStock={outOfStock} />)}
      </div>
      {refundNote && <p className="mt-6 text-sm text-muted-foreground">Eligible game hosting can be refunded within 24 hours of payment. Renewals are not refundable.</p>}
    </section>
  );
}
