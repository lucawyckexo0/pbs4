import { CreditCard, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { canPayWithCredits, creditsAllowedFor } from "@/config/credits";
import { formatINR } from "@/config/plans";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

/**
 * The two ways to pay: from the credit balance (only when it covers the whole amount) or with Razorpay.
 * The server checks the balance again; this only decides which buttons to show.
 */
export function PayChoice({ amount, balance, product, disabled, onPay, className, size = "lg" }: { amount: number | null; balance: number | undefined; product: string; disabled?: boolean; onPay: (useCredits: boolean) => void; className?: string; size?: "md" | "lg" }) {
  const s = useSettings();
  const showCredits = creditsAllowedFor(product, s.credits) && amount !== null && amount > 0;
  const enough = amount !== null && balance !== undefined && canPayWithCredits(balance, amount, s.credits, product);
  return (
    <div className={cn("grid gap-2", className)}>
      {showCredits && (
        <Button size={size} className="w-full" disabled={disabled || !enough} onClick={() => onPay(true)}>
          <Wallet />{enough ? `Pay ${formatINR(amount)} with credits` : "Not enough credits"}
        </Button>
      )}
      <Button size={size} variant={showCredits && enough ? "secondary" : "primary"} className="w-full" disabled={disabled || amount === null} onClick={() => onPay(false)}>
        <CreditCard />{amount === null ? "Pay" : `Pay ${formatINR(amount)} with Razorpay`}
      </Button>
      {showCredits && balance !== undefined && (
        <p className="text-center text-xs text-muted-foreground">Credit balance: <span className="font-semibold text-foreground">{formatINR(balance)}</span>{!enough && amount !== null ? ` · add ${formatINR(Math.max(0, amount - balance))} more to pay with credits` : ""}</p>
      )}
    </div>
  );
}
