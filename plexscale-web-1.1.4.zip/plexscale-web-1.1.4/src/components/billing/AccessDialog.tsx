import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Check, Copy, ExternalLink, KeyRound, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { btn } from "@/components/ui-px/btn";
import { Spinner } from "@/components/ui-px/Spinner";
import { SuccessTick } from "@/components/ui-px/SuccessTick";
import { generatePanelAccess } from "@/lib/orders.functions";
import { cn } from "@/lib/utils";
import { shownError } from "@/lib/public-error";

type Result = Awaited<ReturnType<typeof generatePanelAccess>>;

function CopyRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="rounded-lg border border-steel bg-ink/70 p-3 text-left">
      <p className="text-xs text-muted-foreground">{label}</p>
      <div className="mt-1 flex items-center justify-between gap-3">
        <span className={cn("min-w-0 break-all text-sm text-foreground", mono && "font-mono")}>{value}</span>
        <button type="button" aria-label={`Copy ${label.toLowerCase()}`} className={btn({ variant: "ghost", size: "sm" })}
          onClick={async () => { await navigator.clipboard.writeText(value); setCopied(true); toast.success(`${label} copied`); setTimeout(() => setCopied(false), 1500); }}>
          {copied ? <Check className="text-ok" /> : <Copy />}
        </button>
      </div>
    </div>
  );
}

export function AccessDialog({ order, onClose }: { order: { id: string; product: string; server_name: string; plan_name: string }; onClose: () => void }) {
  const generate = useServerFn(generatePanelAccess);
  const kind = order.product === "vps" ? "VPS" : "Game";
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  async function run() {
    setBusy(true);
    try { setResult(await generate({ data: { orderId: order.id } })); }
    catch (e) { toast.error(shownError(e, "We couldn’t generate new credentials. Please try again.")); }
    setBusy(false);
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md text-center">
        {!result ? (
          <>
            <DialogHeader className="items-center text-center sm:text-center">
              <span className="popup-icon popup-icon-info"><KeyRound className="size-8" /></span>
              <DialogTitle className="mt-4 font-display text-2xl">Generate {kind} Panel Access Credentials</DialogTitle>
              <DialogDescription>
                A new password is set for your {kind === "VPS" ? "Plexus VPS" : "Pterodactyl game"} panel account for {order.server_name || order.plan_name}. Your old password stops working.
              </DialogDescription>
            </DialogHeader>
            <div className="mt-2 flex flex-col gap-2">
              <button type="button" className={cn(btn({ size: "lg" }), "w-full")} disabled={busy} onClick={() => void run()}>{busy ? <Spinner size="xs" /> : <KeyRound />}{busy ? "Generating…" : "Generate credentials"}</button>
              <button type="button" className={btn({ variant: "text" })} onClick={onClose}>Cancel</button>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="items-center text-center sm:text-center">
              <SuccessTick />
              <DialogTitle className="mt-4 font-display text-2xl">Credentials ready</DialogTitle>
              <DialogDescription>Sign in to the {result.panel === "vps" ? "VPS" : "Game"} panel with these details.</DialogDescription>
            </DialogHeader>
            <div className="mt-2 grid gap-2">
              <CopyRow label="Email" value={result.email} />
              <CopyRow label="Password" value={result.password} mono />
            </div>
            <p className="mt-1 flex items-start gap-2 rounded-lg border border-azure/30 bg-azure/10 p-3 text-left text-xs text-muted-foreground"><ShieldAlert className="size-4 shrink-0 text-azure" />This password is shown only once. Copy it now and keep it safe.</p>
            <div className="mt-2 flex flex-col gap-2">
              <a href={result.panelUrl} target="_blank" rel="noopener noreferrer" className={cn(btn({ size: "lg" }), "w-full")}><ExternalLink />Open {result.panel === "vps" ? "VPS" : "Game"} panel</a>
              <button type="button" className={btn({ variant: "text" })} onClick={onClose}>Done</button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
