import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export { inputCls, thCls as th, tdCls as td } from "@/components/ui-px/form";

export function Field({ label, hint, children, className }: { label: string; hint?: string | undefined; children: ReactNode; className?: string }) {
  return (
    <label className={cn("grid min-w-0 gap-1.5 text-sm", className)}>
      <span className="font-semibold">{label}</span>
      {children}
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
}

export function Card({ title, sub, children, actions }: { title: string; sub?: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section className="admin-card panel min-w-0 p-5 md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div><h3 className="text-lg font-semibold">{title}</h3>{sub && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{sub}</p>}</div>
        {actions}
      </div>
      <div className="mt-5 min-w-0">{children}</div>
    </section>
  );
}

/** Small pill switcher for views inside one section. */
export function Segmented<T extends string>({ value, options, onChange, label }: { value: T; options: readonly { value: T; label: string; count?: number }[]; onChange: (v: T) => void; label: string }) {
  return (
    <div role="tablist" aria-label={label} className="inline-flex flex-wrap gap-1 rounded-lg border border-steel bg-ink p-1">
      {options.map((o) => (
        <button key={o.value} type="button" role="tab" aria-selected={value === o.value} onClick={() => onChange(o.value)}
          className={cn("inline-flex h-8 items-center gap-2 rounded-md px-3 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            value === o.value ? "bg-graphite text-foreground shadow-sm ring-1 ring-steel" : "text-muted-foreground hover:text-foreground")}>
          {o.label}
          {o.count !== undefined && o.count > 0 && <span className="rounded-full bg-destructive/15 px-1.5 text-xs text-destructive">{o.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="size-4 accent-azure" />
      {label}
    </label>
  );
}

export function Pill({ ok, children }: { ok: boolean; children: ReactNode }) {
  return <span className={cn("badge", ok ? "badge-ok" : "badge-bad")}><span aria-hidden className="size-1.5 rounded-full bg-current" />{children}</span>;
}

/** Parses an optional number input; empty stays undefined. */
export const num = (v: string) => (v.trim() === "" ? undefined : Number(v));
