import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowDown, ArrowUp, Eye, EyeOff, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { btn } from "@/components/ui-px/btn";
import type { PanelSettings, SiteSettings, VpsOs } from "@/config/settings";
import { locationsForProduct } from "@/config/settings";
import { savePlexusSettings, testPlexusConnection } from "@/lib/admin.functions";
import { Card, Field, inputCls, Pill, td, th } from "./fields";

type Probe = Awaited<ReturnType<typeof testPlexusConnection>>;

export function PlexusSettingsPanel({ panel, site, connected, onSaved }: { panel: PanelSettings; site: SiteSettings; connected: boolean; onSaved: () => void }) {
  const save = useServerFn(savePlexusSettings);
  const test = useServerFn(testPlexusConnection);
  const [clusters, setClusters] = useState<Record<string, number>>(panel.plexus.clusters);
  const [images, setImages] = useState<Record<string, number>>(panel.plexus.images);
  const [os, setOs] = useState<VpsOs[]>(site.vpsOs);
  const [probe, setProbe] = useState<Probe | null>(null);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const vpsLocations = locationsForProduct(site, "vps");
  const catalogImages = probe?.ok ? probe.images : [];
  const catalogClusters = probe?.ok ? probe.clusters : [];

  const setNum = (setter: typeof setClusters, key: string, v: string) => setter((cur) => {
    const next = { ...cur }; const n = Number(v);
    if (!v.trim() || !Number.isInteger(n) || n < 1) delete next[key]; else next[key] = n;
    return next;
  });
  const patchOs = (i: number, patch: Partial<VpsOs>) => setOs((l) => l.map((o, j) => (j === i ? { ...o, ...patch } : o)));
  const move = (i: number, dir: -1 | 1) => setOs((l) => { const n = [...l]; const j = i + dir; if (j < 0 || j >= n.length) return l; [n[i], n[j]] = [n[j]!, n[i]!]; return n; });
  const addOs = () => setOs((l) => [...l, { key: `os-${l.length + 1}`, family: "ubuntu", name: "Ubuntu", version: "", hint: "", hidden: true }]);

  async function runTest() {
    setTesting(true);
    try { const r = await test(); setProbe(r); if (r.ok) toast.success("Connected to Plexus"); else toast.error(r.message); } catch { toast.error("Could not reach Plexus."); }
    setTesting(false);
  }
  async function submit() {
    if (os.some((o) => !o.version.trim() || !o.name.trim())) { toast.error("Every OS needs a name and a version."); return; }
    if (new Set(os.map((o) => o.key)).size !== os.length) { toast.error("OS keys must be unique."); return; }
    if (!os.some((o) => !o.hidden)) { toast.error("Keep at least one OS visible."); return; }
    setSaving(true);
    try { await save({ data: { clusters, images, vpsOs: os } }); toast.success("Plexus settings saved"); onSaved(); } catch { toast.error("Plexus settings could not be saved. Check the values and try again."); }
    setSaving(false);
  }

  return (
    <div className="space-y-6">
      <Card title="Plexus API" sub="Set PLEXUS_URL (https) and PLEXUS_API_KEY as server secrets. The key needs catalog, accounts and machines read/write scopes."
        actions={<Button type="button" variant="secondary" disabled={testing} onClick={() => void runTest()}>{testing ? "Testing…" : "Test connection"}</Button>}>
        <Pill ok={connected}>{connected ? "API key set" : "API key missing"}</Pill>
        {probe && !probe.ok && <p className="mt-3 text-sm text-destructive">{probe.message}</p>}
        {probe?.ok && (
          <div className="mt-4 grid gap-4 text-sm md:grid-cols-2">
            <div><p className="font-semibold">Clusters</p><ul className="mt-2 space-y-1 text-muted-foreground">{probe.clusters.map((c) => <li key={c.id}>#{c.id} · {c.name}{c.location ? ` · ${c.location}` : ""} · {c.free_ipv4} free IPv4{c.maintenance ? " · maintenance" : ""}</li>)}</ul></div>
            <div><p className="font-semibold">Active images</p><ul className="mt-2 space-y-1 text-muted-foreground">{probe.images.map((i) => <li key={i.id}>#{i.id} · {i.name}{i.os_family ? ` · ${i.os_family}` : ""}</li>)}</ul></div>
          </div>
        )}
      </Card>

      <Card title="Location cluster mappings" sub="Which Plexus cluster each VPS location deploys to.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {vpsLocations.map((l) => (
            <Field key={l.id} label={`${l.city} (${l.id})`}>
              {catalogClusters.length ? (
                <select className={inputCls} value={clusters[l.id] ?? ""} onChange={(e) => setNum(setClusters, l.id, e.target.value)}>
                  <option value="">Not mapped</option>
                  {catalogClusters.map((c) => <option key={c.id} value={c.id}>#{c.id} {c.name}</option>)}
                </select>
              ) : <input type="number" min={1} placeholder="cluster_id" className={inputCls} value={clusters[l.id] ?? ""} onChange={(e) => setNum(setClusters, l.id, e.target.value)} />}
            </Field>
          ))}
        </div>
      </Card>

      <Card title="Operating systems" sub="Names and versions customers see on the VPS deploy page, mapped to Plexus image ids. Hidden ones are not offered."
        actions={<Button type="button" variant="secondary" onClick={addOs}><Plus />Add OS</Button>}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr><th className={th}>Key</th><th className={th}>Family</th><th className={th}>Name</th><th className={th}>Version</th><th className={th}>Hint</th><th className={th}>Plexus image</th><th className={th}></th></tr></thead>
            <tbody>
              {os.map((o, i) => (
                <tr key={i} className={o.hidden ? "opacity-60" : ""}>
                  <td className={td}><input className={inputCls} value={o.key} onChange={(e) => patchOs(i, { key: e.target.value.toLowerCase() })} /></td>
                  <td className={td}><select className={inputCls} value={o.family} onChange={(e) => patchOs(i, { family: e.target.value as VpsOs["family"] })}><option value="ubuntu">Ubuntu</option><option value="debian">Debian</option><option value="other">Other</option></select></td>
                  <td className={td}><input className={inputCls} value={o.name} onChange={(e) => patchOs(i, { name: e.target.value })} /></td>
                  <td className={td}><input className={inputCls} value={o.version} onChange={(e) => patchOs(i, { version: e.target.value })} /></td>
                  <td className={td}><input className={inputCls} value={o.hint} onChange={(e) => patchOs(i, { hint: e.target.value })} /></td>
                  <td className={td}>
                    {catalogImages.length ? (
                      <select className={inputCls} value={images[o.key] ?? ""} onChange={(e) => setNum(setImages, o.key, e.target.value)}>
                        <option value="">Not mapped</option>
                        {catalogImages.map((im) => <option key={im.id} value={im.id}>#{im.id} {im.name}</option>)}
                      </select>
                    ) : <input type="number" min={1} placeholder="image_id" className={inputCls} value={images[o.key] ?? ""} onChange={(e) => setNum(setImages, o.key, e.target.value)} />}
                  </td>
                  <td className={td}>
                    <div className="flex gap-1">
                      <button type="button" aria-label={o.hidden ? "Show" : "Hide"} className={btn({ variant: "ghost", size: "sm" })} onClick={() => patchOs(i, { hidden: !o.hidden })}>{o.hidden ? <EyeOff /> : <Eye />}</button>
                      <button type="button" aria-label="Move up" className={btn({ variant: "ghost", size: "sm" })} onClick={() => move(i, -1)}><ArrowUp /></button>
                      <button type="button" aria-label="Move down" className={btn({ variant: "ghost", size: "sm" })} onClick={() => move(i, 1)}><ArrowDown /></button>
                      <button type="button" aria-label="Remove" className={btn({ variant: "ghost", size: "sm" })} onClick={() => setOs((l) => l.filter((_, j) => j !== i))}><Trash2 /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">Keys are stored on orders. Changing a key does not move existing services.</p>
      </Card>

      <div className="flex justify-end"><Button type="button" disabled={saving} onClick={() => void submit()}>{saving ? "Saving…" : "Save Plexus settings"}</Button></div>
    </div>
  );
}
