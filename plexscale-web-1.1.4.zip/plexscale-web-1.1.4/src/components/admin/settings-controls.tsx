import { askConfirm } from "@/components/ui-px/ConfirmHost";
import { useEffect, useState } from "react";
import { Plus, Save, RotateCcw, Trash2, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { minecraftVersionSchema, type SiteSettings } from "@/config/settings";
import { Card, Field, inputCls } from "./fields";
import { toast } from "sonner";

export function useSettingsDraft<T>(initial: T) {
  const [draft, setDraft] = useState(initial);
  const [baseline, setBaseline] = useState(initial);
  const dirty = JSON.stringify(draft) !== JSON.stringify(baseline);
  useEffect(() => {
    if (!dirty) { setDraft(initial); setBaseline(initial); }
  }, [initial]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ""; };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  return { draft, setDraft, dirty, discard: () => setDraft(baseline), accept: (saved: T) => { setBaseline(saved); setDraft(saved); } };
}

export function SaveBar({ dirty, saving, onSave, onDiscard, label = "Save changes" }: { dirty: boolean; saving: boolean; onSave: () => void; onDiscard: () => void; label?: string }) {
  return <div className="admin-save-bar sticky bottom-0 z-20 flex flex-wrap items-center justify-between gap-3 border-t border-steel bg-background px-4 py-4">
    <span className="flex items-center gap-2 text-sm text-muted-foreground"><ShieldCheck className="size-4 text-ok" />{saving ? "Saving changes…" : dirty ? "Unsaved changes" : "All changes saved"}</span>
    <div className="flex flex-wrap gap-2">
      <Button type="button" variant="outline" disabled={saving || !dirty} onClick={onDiscard}><RotateCcw />Discard</Button>
      <Button type="button" disabled={saving || !dirty} onClick={onSave}><Save />{saving ? "Saving…" : label}</Button>
    </div>
  </div>;
}

export function LocationsEditor({ value, onChange }: { value: SiteSettings; onChange: (value: SiteSettings) => void }) {
  const patch = (id: string, key: string, next: string | number) => onChange({ ...value, locations: value.locations.map((l) => l.id === id ? { ...l, [key]: next } : l) });
  return <Card title="Locations" sub="How each location is shown to customers.">
    <div className="divide-y divide-steel">
      {value.locations.map((l) => <div key={l.id} className="grid gap-4 py-5 first:pt-0">
        <div className="flex flex-wrap items-center justify-between gap-3"><p className="font-display font-semibold">{l.city}<span className="ml-3 font-mono text-xs font-normal text-muted-foreground">{l.id}</span></p><div className="flex items-center gap-4">
          <Button type="button" variant="ghost" size="icon" aria-label={`Remove ${l.city}`} title={`Remove ${l.city}`} disabled={value.locations.length <= 1} onClick={async () => { if (await askConfirm(`Remove ${l.city} from new deployments? Existing orders are retained.`)) onChange({ ...value, locations: value.locations.filter((x) => x.id !== l.id), ordering: { ...value.ordering, disabledLocations: value.ordering.disabledLocations.filter((id) => id !== l.id), productLocations: Object.fromEntries(Object.entries(value.ordering.productLocations ?? {}).map(([k, ids]) => [k, ids.filter((id) => id !== l.id)]).filter(([, ids]) => (ids as string[]).length > 0)) } }); }}><Trash2 /></Button>
        </div></div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="City"><input className={inputCls} maxLength={60} value={l.city} onChange={(e) => patch(l.id, "city", e.target.value)} /></Field>
          <Field label="Country / region"><input className={inputCls} maxLength={60} value={l.region} onChange={(e) => patch(l.id, "region", e.target.value)} /></Field>
          <Field label="Country code"><input className={inputCls} maxLength={2} value={l.country} onChange={(e) => patch(l.id, "country", e.target.value.toUpperCase())} /></Field>
          <Field label="Estimated latency (ms)"><input className={inputCls} type="number" min={0} max={2000} value={l.mockPing} onChange={(e) => patch(l.id, "mockPing", Number(e.target.value))} /></Field>
        </div>
      </div>)}
    </div>
  </Card>;
}

export function VersionsEditor({ value, onChange }: { value: string[]; onChange: (value: string[]) => void }) {
  const [release, setRelease] = useState("");
  function add() {
    const parsed = minecraftVersionSchema.safeParse(release);
    if (!parsed.success) { toast.error("Enter a release number such as 26.3."); return; }
    if (value.includes(parsed.data)) { toast.error("This version is already listed."); return; }
    onChange(["latest", parsed.data, ...value.filter((v) => v !== "latest")]); setRelease("");
  }
  return <Card title="Minecraft versions">
    <div className="flex flex-wrap gap-3"><Field label="Release number"><input className={inputCls} value={release} maxLength={20} placeholder="26.3" onChange={(e) => setRelease(e.target.value)} /></Field><Button className="self-end" type="button" disabled={!release.trim() || value.length >= 200} onClick={add}><Plus />Add version</Button></div>
    <ul className="mt-5 flex flex-wrap gap-2">{value.map((v) => <li key={v} className="flex items-center gap-2 rounded-md border border-steel py-1 pl-3 pr-1 text-sm"><span>{v === "latest" ? "Latest release" : v}</span>{v !== "latest" && <Button type="button" variant="ghost" size="icon" aria-label={`Remove version ${v}`} title={`Remove ${v}`} onClick={() => onChange(value.filter((x) => x !== v))}><Trash2 /></Button>}</li>)}</ul>
  </Card>;
}