import { Eye } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { td, th } from "./fields";

type Row = { id: string; actor_id: string | null; action: string; target: string | null; details: Record<string, unknown>; ip: string | null; created_at: string };
type Profile = { id: string; email: string | null };

const labels: Record<string, string> = {
  "settings.site.update": "Updated site settings",
  "settings.panel.update": "Updated panel settings",
  "settings.email.update": "Updated SMTP & emails",
  "order.status": "Changed order status",
  "order.provision": "Retried server setup",
  "order.upgrade.retry": "Retried upgrade",
  "refund.paid": "Approved refund",
  "refund.reject": "Rejected refund",
  "admin.grant": "Added admin",
  "admin.revoke": "Removed admin",
  "ticket.reply": "Replied to ticket",
  "ticket.note": "Added ticket note",
  "ticket.update": "Updated ticket",
  "panel.test": "Tested panel connection",
  "email.test": "Sent test email",
  "discord.test": "Sent test Discord alert",
  "alert.resolve": "Resolved system alert",
  "settings.backup.create": "Backed up settings",
  "settings.backup.restore": "Restored settings backup",
  "coupon.create": "Created coupon",
  "coupon.update": "Updated coupon",
  "coupon.disable": "Disabled coupon",
  "coupon.delete": "Deleted coupon",
};

const sectionNames: Record<string, string> = {
  locations: "Locations", minecraftVersions: "Versions", discordUrl: "Links", discordLabel: "Links", supportEmail: "Links",
  gamePanelUrl: "Links", vpsPanelUrl: "Links", announcement: "Alert banner", maintenance: "Maintenance", ordering: "Stock & ordering", plans: "Plans",
};

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });

function detail(a: Row, email: (id: string) => string): string {
  const d = a.details;
  if (a.action === "settings.site.update" && Array.isArray(d["sections"])) {
    const names = [...new Set((d["sections"] as unknown[]).map((s) => sectionNames[String(s)] ?? String(s)))];
    return names.length ? names.join(", ") : "No changes";
  }
  if (a.action === "order.status" && typeof d["from"] === "string" && typeof d["to"] === "string") return `${d["from"]} to ${d["to"]}`;
  if (a.action === "ticket.update") return Object.entries(d).map(([k, v]) => `${k}: ${String(v)}`).join(", ");
  if ((a.action === "admin.grant" || a.action === "admin.revoke") && a.target) return email(a.target);
  if (a.action === "refund.paid" && typeof d["amount"] === "number") return `₹${d["amount"]}`;
  return a.target ? `#${a.target.slice(0, 8)}` : "";
}

/** IP stays hidden until hovered, focused or clicked. */
function IpReveal({ ip }: { ip: string | null }) {
  const [hover, setHover] = useState(false);
  const [pinned, setPinned] = useState(false);
  if (!ip) return <span className="text-muted-foreground">-</span>;
  const shown = hover || pinned;
  return (
    <button type="button" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} onFocus={() => setHover(true)} onBlur={() => { setHover(false); setPinned(false); }} onClick={() => setPinned((p) => !p)}
      aria-label={shown ? `IP address ${ip}` : "Show IP address"} aria-pressed={pinned}
      className={cn("inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-xs transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", shown ? "border-azure/60 text-foreground" : "border-steel text-muted-foreground hover:text-foreground")}>
      {shown ? ip : <><Eye className="size-3.5" />{ip.includes(":") ? "IPv6 hidden" : "•••.•••.•••.•••"}</>}
    </button>
  );
}

export function ActivityPanel({ rows, profiles }: { rows: Row[]; profiles: Profile[] }) {
  const email = (id: string) => profiles.find((p) => p.id === id)?.email ?? id.slice(0, 8);
  return (
    <div className="panel overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr><th className={th}>When</th><th className={th}>Admin</th><th className={th}>Action</th><th className={th}>Details</th><th className={th}>IP</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className={td} colSpan={5}>Nothing yet.</td></tr>}
            {rows.map((a) => (
              <tr key={a.id}>
                <td className={cn(td, "whitespace-nowrap")}>{when(a.created_at)}</td>
                <td className={td}>{a.actor_id ? email(a.actor_id) : "-"}</td>
                <td className={td}>{labels[a.action] ?? a.action}</td>
                <td className={cn(td, "max-w-xs text-muted-foreground")}>{detail(a, email)}</td>
                <td className={td}><IpReveal ip={a.ip} /></td>
              </tr>
            ))}
          </tbody>
        </table>
    </div>
  );
}
