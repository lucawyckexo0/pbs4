import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Headset, Lock, User } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { PageLoader, Spinner } from "@/components/ui-px/Spinner";
import { replyBody, ticketCategories, ticketPriorities, ticketStatusLabel, ticketStatusTone, type TicketStatus } from "@/config/support";
import { productNames, type ProductKey } from "@/config/plans";
import { adminGetTicket, adminListTickets, adminReplyTicket, adminSetTicket } from "@/lib/support.functions";
import { cn } from "@/lib/utils";
import { inputCls, td, th, Toggle } from "./fields";

const when = (s: string) => new Date(s).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
const statuses: TicketStatus[] = ["open", "customer_reply", "answered", "closed"];

export function TicketsPanel() {
  const [openId, setOpenId] = useState<string | null>(null);
  return openId ? <TicketThread id={openId} onBack={() => setOpenId(null)} /> : <TicketList onOpen={setOpenId} />;
}

function TicketList({ onOpen }: { onOpen: (id: string) => void }) {
  const list = useServerFn(adminListTickets);
  const { data, isLoading } = useQuery({ queryKey: ["admin-tickets"], queryFn: () => list(), refetchInterval: 30_000 });
  const [filter, setFilter] = useState<"active" | TicketStatus | "all">("active");
  const [q, setQ] = useState("");
  if (isLoading || !data) return <PageLoader text="Loading tickets" className="min-h-[30vh]" />;
  const who = (id: string) => data.profiles.find((p) => p.id === id)?.email ?? id.slice(0, 8);
  const rows = data.tickets.filter((t) => (filter === "all" || (filter === "active" ? t.status !== "closed" : t.status === filter)) && (!q || `${t.number} ${t.subject} ${who(t.user_id)}`.toLowerCase().includes(q.toLowerCase())));
  const waiting = data.tickets.filter((t) => t.status === "open" || t.status === "customer_reply").length;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search number, subject or email" className={cn(inputCls, "max-w-xs")} />
        <select value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)} className={cn(inputCls, "w-52")}>
          <option value="active">Not closed</option><option value="all">All tickets</option>
          {statuses.map((s) => <option key={s} value={s}>{ticketStatusLabel[s]}</option>)}
        </select>
        <span className="ml-auto text-sm text-muted-foreground">{waiting} waiting for staff</span>
      </div>
      <div className="panel overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr><th className={th}>#</th><th className={th}>Subject</th><th className={th}>Customer</th><th className={th}>Priority</th><th className={th}>Status</th><th className={th}>Last activity</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className={td} colSpan={6}>No tickets.</td></tr>}
            {rows.map((t) => {
              const unread = !t.staff_last_read_at || t.last_message_at > t.staff_last_read_at;
              return (
                <tr key={t.id} className="cursor-pointer hover:bg-accent/40" onClick={() => onOpen(t.id)}>
                  <td className={cn(td, "font-mono text-xs")}>{t.number}</td>
                  <td className={td}><span className={cn("flex items-center gap-2", unread && "font-semibold")}>{unread && <span className="size-2 shrink-0 rounded-full bg-azure" />}{t.subject}</span><span className="text-xs text-muted-foreground">{ticketCategories.find((c) => c.key === t.category)?.label}</span></td>
                  <td className={td}>{who(t.user_id)}</td>
                  <td className={cn(td, t.priority === "urgent" ? "text-destructive" : t.priority === "high" ? "text-azure" : "")}>{t.priority}</td>
                  <td className={td}><span className={cn("rounded-full border px-2 py-0.5 text-xs", ticketStatusTone[t.status as TicketStatus])}>{ticketStatusLabel[t.status as TicketStatus]}</span></td>
                  <td className={td}>{when(t.last_message_at)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TicketThread({ id, onBack }: { id: string; onBack: () => void }) {
  const qc = useQueryClient();
  const get = useServerFn(adminGetTicket);
  const reply = useServerFn(adminReplyTicket);
  const setTicket = useServerFn(adminSetTicket);
  const { data, isLoading } = useQuery({ queryKey: ["admin-ticket", id], queryFn: () => get({ data: { ticketId: id } }), refetchInterval: 20_000 });
  const [body, setBody] = useState("");
  const [internal, setInternal] = useState(false);
  const [busy, setBusy] = useState(false);
  if (isLoading || !data) return <PageLoader text="Loading ticket" className="min-h-[30vh]" />;
  const t = data.ticket;
  const staffName = (aid: string | null) => data.staff.find((s) => s.id === aid)?.display_name || data.staff.find((s) => s.id === aid)?.email || "Staff";
  const refresh = () => { void qc.invalidateQueries({ queryKey: ["admin-ticket", id] }); void qc.invalidateQueries({ queryKey: ["admin-tickets"] }); };

  async function send(close = false) {
    const check = replyBody.safeParse(body);
    if (!check.success) { toast.error(check.error.issues[0]?.message ?? "Write a message first."); return; }
    setBusy(true);
    try { await reply({ data: { ticketId: id, body, internal, close } }); setBody(""); toast.success(internal ? "Note added" : close ? "Replied and closed" : "Reply sent. The customer was emailed."); refresh(); } catch { toast.error("Could not send the reply."); }
    setBusy(false);
  }
  async function update(patch: { status?: string; priority?: string }) {
    try { await setTicket({ data: { ticketId: id, ...patch } }); refresh(); } catch { toast.error("Could not update the ticket."); }
  }

  return (
    <div className="space-y-5">
      <Button type="button" variant="ghost" onClick={onBack} className="-ml-3"><ArrowLeft />All tickets</Button>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="eyebrow">Ticket #{t.number}</p>
          <h2 className="mt-1 break-words text-2xl">{t.subject}</h2>
          <p className="mt-1 text-sm text-muted-foreground">{data.customer?.email} · {ticketCategories.find((c) => c.key === t.category)?.label} · Opened {when(t.created_at)}</p>
          {data.order && <p className="mt-1 text-sm text-muted-foreground">Service: {data.order.server_name || data.order.plan_name} · {productNames[data.order.product as ProductKey] ?? data.order.product} · {data.order.status}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          <select className={cn(inputCls, "h-9 w-40")} value={t.priority} onChange={(e) => void update({ priority: e.target.value })}>{ticketPriorities.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}</select>
          <select className={cn(inputCls, "h-9 w-40")} value={t.status} onChange={(e) => void update({ status: e.target.value })}>{statuses.map((s) => <option key={s} value={s}>{ticketStatusLabel[s]}</option>)}</select>
        </div>
      </div>
      <ol className="space-y-3">
        {data.messages.map((m) => (
          <li key={m.id} className={cn("panel p-4", m.is_internal ? "border-dashed border-azure/50 bg-ink" : m.is_staff ? "border-azure/50 bg-azure-deep/40" : "")}>
            <p className="flex items-center gap-2 text-sm font-semibold">
              {m.is_internal ? <Lock className="size-4 text-azure" /> : m.is_staff ? <Headset className="size-4 text-azure" /> : <User className="size-4 text-muted-foreground" />}
              {m.is_internal ? `Internal note · ${staffName(m.author_id)}` : m.is_staff ? staffName(m.author_id) : data.customer?.display_name || data.customer?.email || "Customer"}
              <span className="font-normal text-muted-foreground">· {when(m.created_at)}</span>
            </p>
            <p className="mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed">{m.body}</p>
          </li>
        ))}
      </ol>
      <div className="panel grid gap-3 p-4">
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={5} maxLength={5000} placeholder={internal ? "Internal note, only staff can see this" : "Write a reply to the customer"} className={cn(inputCls, "h-auto py-3")} />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Toggle checked={internal} onChange={setInternal} label="Internal note (not visible to the customer)" />
          <div className="flex gap-2">
            {!internal && <Button type="button" variant="outline" disabled={busy || !body.trim()} onClick={() => void send(true)}>Reply and close</Button>}
            <Button type="button" disabled={busy || !body.trim()} onClick={() => void send(false)}>{busy && <Spinner size="xs" />}{internal ? "Add note" : "Send reply"}</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
