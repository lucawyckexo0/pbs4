import { cva, type VariantProps } from "class-variance-authority";

/**
 * The one button style for the whole site (public pages, account pages and Administrator).
 * Every variant sets its rest, hover, active and disabled colours together so a label can never
 * end up the same colour as its background, whatever classes it is merged with.
 */
export const btn = cva(
  "inline-flex shrink-0 cursor-pointer select-none items-center justify-center gap-2 whitespace-nowrap rounded-md font-display font-semibold transition-[background-color,border-color,color,box-shadow,transform] duration-150 active:translate-y-px focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        /** Main action: azure fill, dark label in every state. */
        primary: "border border-transparent bg-primary text-primary-foreground shadow-btn hover:bg-azure-bright hover:text-primary-foreground active:bg-azure-bright active:text-primary-foreground",
        /** Secondary action: outlined, light label; fills on hover. */
        secondary: "border border-steel bg-transparent text-foreground hover:border-azure hover:bg-accent hover:text-foreground active:bg-accent active:text-foreground",
        /** Quiet action inside toolbars and menus. */
        ghost: "border border-transparent bg-transparent text-foreground hover:bg-accent hover:text-foreground active:bg-accent active:text-foreground",
        /** For buttons sitting on photos or busy backgrounds: frosted fill so the label always reads. */
        glass: "border border-foreground/25 bg-graphite/70 text-foreground backdrop-blur-md hover:border-azure hover:bg-graphite/90 hover:text-foreground active:bg-graphite active:text-foreground",
        /** Low-emphasis text action (table rows, "Close"). */
        text: "border border-transparent bg-transparent px-2 text-muted-foreground hover:bg-accent hover:text-foreground active:bg-accent active:text-foreground",
        /** Inline link-style action. */
        link: "h-auto border-0 bg-transparent px-0 text-azure underline-offset-4 hover:bg-transparent hover:text-azure-bright hover:underline active:text-azure-bright",
        /** Destructive confirmation: red fill, light label in every state. */
        danger: "border border-transparent bg-destructive text-destructive-foreground hover:bg-destructive-strong hover:text-destructive-foreground active:bg-destructive-strong active:text-destructive-foreground",
        /** Destructive but quiet: red label, red tint on hover. */
        "danger-ghost": "border border-transparent bg-transparent text-destructive hover:bg-destructive/12 hover:text-destructive active:bg-destructive/15 active:text-destructive",
      },
      size: {
        xs: "h-7 px-2 text-xs [&_svg]:size-3.5",
        sm: "h-8 px-3 text-xs",
        md: "h-10 px-4 text-sm",
        lg: "h-12 px-6 text-[15px]",
        icon: "size-9 p-0",
        "icon-sm": "size-8 p-0",
      },
    },
    compoundVariants: [
      { variant: "link", size: ["xs", "sm", "md", "lg"], class: "h-auto px-0" },
    ],
    defaultVariants: { variant: "primary", size: "md" },
  },
);
export type BtnProps = VariantProps<typeof btn>;
export type BtnVariant = NonNullable<BtnProps["variant"]>;
