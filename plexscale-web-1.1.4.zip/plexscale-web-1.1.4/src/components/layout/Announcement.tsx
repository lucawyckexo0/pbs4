import { AlertTriangle, CheckCircle2, Info, OctagonAlert, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useSettings } from "@/hooks/use-settings";
import { cn } from "@/lib/utils";

const tones = {
  info: { icon: Info, cls: "border-azure/40 bg-azure/10 text-foreground", ic: "text-azure" },
  success: { icon: CheckCircle2, cls: "border-ok/40 bg-ok/10 text-foreground", ic: "text-ok" },
  warning: { icon: AlertTriangle, cls: "border-azure/40 bg-azure/15 text-foreground", ic: "text-azure-bright" },
  danger: { icon: OctagonAlert, cls: "border-destructive/50 bg-destructive/15 text-foreground", ic: "text-destructive" },
} as const;

/** Site-wide alert set in Administrator → Site. Dismissal is remembered per message. */
export function Announcement() {
  const { announcement: a } = useSettings();
  const id = `px-dismiss:${a.message}`;
  const [hidden, setHidden] = useState(false);
  useEffect(() => { setHidden(localStorage.getItem(id) === "1"); }, [id]);
  if (!a.enabled || !a.message || hidden) return null;
  const t = tones[a.tone];
  return (
    <div role="status" className={cn("border-b text-sm", t.cls)}>
      <div className="container-px flex items-center gap-3 py-2.5">
        <t.icon className={cn("size-4 shrink-0", t.ic)} aria-hidden />
        <p className="flex-1">
          {a.message}
          {a.linkUrl && a.linkLabel && <a href={a.linkUrl} target="_blank" rel="noopener noreferrer" className="ml-2 font-semibold text-azure underline-offset-4 hover:underline">{a.linkLabel}</a>}
        </p>
        <button type="button" aria-label="Dismiss" onClick={() => { localStorage.setItem(id, "1"); setHidden(true); }} className="rounded p-1 text-muted-foreground hover:text-foreground"><X className="size-4" /></button>
      </div>
    </div>
  );
}
