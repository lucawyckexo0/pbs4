import { Link, useRouterState } from "@tanstack/react-router";
import { House, LogIn, LogOut, ShieldCheck, CreditCard, Wallet, ChevronDown, Gamepad2, MapPin, Menu, MessageCircle, Server, LifeBuoy, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { btn } from "@/components/ui-px/btn";
import { games } from "@/config/products";
import { showsProducts } from "@/config/nav";
import { img, gameMenuImages } from "@/config/images";
import { useSettings } from "@/hooks/use-settings";
import { useCredits } from "@/hooks/use-credits";
import { formatINR } from "@/config/plans";
import { useIsAdmin, useSignOut, useUser } from "@/hooks/use-session";
import { cn } from "@/lib/utils";
import { DiscordIcon } from "@/components/icons/DiscordIcon";

const accountLinks = [
  { to: "/billing", label: "Billing", icon: CreditCard },
  { to: "/support", label: "Support", icon: LifeBuoy },
  { to: "/account", label: "Account", icon: UserRound },
] as const;

const productLinks = [
  { to: "/vps", label: "VPS", icon: Server },
  { to: "/bot-hosting", label: "Bot Hosting", icon: DiscordIcon },
] as const;

function Marker() {
  return <span aria-hidden className="slant-marker absolute -bottom-[1px] left-3 right-3 h-[3px] bg-azure" />;
}

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  useEffect(() => setOpen(false), [path]);
  const s = useSettings();
  const { user } = useUser();
  const credits = useCredits(Boolean(user));
  const isAdmin = useIsAdmin(user?.id);
  const signOut = useSignOut();
  const products = showsProducts(path);
  const panelLinks = [
    { href: s.gamePanelUrl, label: "Game Panel", icon: Gamepad2 },
    { href: s.vpsPanelUrl, label: "VPS Panel", icon: Server },
  ];
  const item = "cursor-pointer px-3 py-3 focus:bg-accent";

  return (
    <header className={cn("sticky top-0 z-50 h-16 border-b transition-colors duration-200", scrolled ? "border-steel bg-ink/80 backdrop-blur-md" : "border-transparent bg-transparent")}>
      <nav aria-label="Main" className={cn("container-px relative flex h-full items-center justify-between gap-4", products && "lg:grid lg:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] lg:gap-3")}>
        <Link to="/" aria-label="PlexScale home" className="flex shrink-0 items-center justify-self-start">
          <span className="flex items-center gap-2.5">
            <img src={img.pmark} alt="" width={36.8} height={36.8} className="size-[36.8px] object-contain" />
            <span className="font-display text-[20.7px] font-semibold text-foreground">PlexScale</span>
          </span>
        </Link>

        {products && (
          <ul className="hidden h-full items-center justify-center gap-1 lg:flex">
            <li className="relative flex h-full items-center">
              <Link to="/" className="flex h-10 items-center gap-1.5 rounded-md px-3 text-sm leading-none text-muted-foreground transition-colors hover:text-foreground">
                <House className="size-4" /> Home
              </Link>
              {path === "/" && <Marker />}
            </li>
            <li className="relative flex h-full items-center">
              <DropdownMenu modal={false}>
                <DropdownMenuTrigger className="group flex h-10 items-center gap-1.5 rounded-md px-3 text-sm leading-none text-muted-foreground transition-colors hover:text-foreground data-[state=open]:text-foreground">
                  <Gamepad2 className="size-4" /> Games <ChevronDown className="size-4 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" sideOffset={8} className="w-64 border-steel bg-graphite p-2 duration-200">
                  {games.map((g) => (
                    <DropdownMenuItem key={g.key} asChild className="cursor-pointer rounded-md px-3 py-3 focus:bg-accent">
                      <Link to={g.to} className="flex items-center gap-3"><img src={gameMenuImages[g.key]} alt="" width={32} height={32} loading="lazy" className="size-8 shrink-0 rounded-sm object-contain" />{g.name}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </li>
            {productLinks.map((l) => (
              <li key={l.to} className="relative flex h-full items-center">
                <Link to={l.to} className="flex h-10 items-center gap-1.5 rounded-md px-3 text-sm leading-none text-muted-foreground transition-colors hover:text-foreground">
                  <l.icon className="size-4" /> {l.label}
                </Link>
                {path.startsWith(l.to) && <Marker />}
              </li>
            ))}
            <li className="relative flex h-full items-center">
              <Link to="/" hash="locations" className="flex h-10 items-center gap-1.5 rounded-md px-3 text-sm leading-none text-muted-foreground transition-colors hover:text-foreground">
                <MapPin className="size-4" /> Locations
              </Link>
            </li>
          </ul>
        )}

        <div className="hidden items-center justify-self-end gap-1 lg:flex xl:gap-2">
          {products && (
            <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "ghost" })}>
              <MessageCircle /> Discord
            </a>
          )}
          {user ? (
            <DropdownMenu modal={false}>
              <DropdownMenuTrigger className={cn(btn(), "group outline-none active:scale-100")}><UserRound /> Manage <ChevronDown className="transition-transform duration-200 group-data-[state=open]:rotate-180" /></DropdownMenuTrigger>
              <DropdownMenuContent align="end" sideOffset={8} className="w-56 border-steel bg-graphite p-2 duration-200">
                {credits.data && (
                  <>
                    <DropdownMenuItem asChild className={item}><Link to="/billing" hash="credits" className="flex items-center gap-3"><Wallet className="size-4 text-azure" /><span className="flex-1">Credits</span><span className="font-semibold tabular-nums text-foreground">{formatINR(credits.data.balance)}</span></Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-steel" />
                  </>
                )}
                {accountLinks.map(({ to, label, icon: Icon }) => (
                  <DropdownMenuItem key={to} asChild className={item}><Link to={to} className="flex items-center gap-3"><Icon className="size-4 text-azure" />{label}</Link></DropdownMenuItem>
                ))}
                <DropdownMenuSeparator className="bg-steel" />
                {panelLinks.map(({ href, label, icon: Icon }) => (
                  <DropdownMenuItem key={label} asChild className={item}><a href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3"><Icon className="size-4 text-azure" />{label}</a></DropdownMenuItem>
                ))}
                {isAdmin && <DropdownMenuItem asChild className={item}><Link to="/administrator" className="flex items-center gap-3"><ShieldCheck className="size-4 text-azure" />Administrator</Link></DropdownMenuItem>}
                <DropdownMenuSeparator className="bg-steel" />
                <DropdownMenuItem onSelect={() => void signOut()} className={cn(item, "gap-3")}><LogOut className="size-4 text-azure" />Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link to="/auth" className={btn()}><LogIn /> Log in</Link>
          )}
        </div>

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger aria-label="Open menu" className={cn(btn({ variant: "ghost" }), "w-10 px-0 lg:hidden")}>
            <Menu className="!size-5" />
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] border-steel bg-graphite p-6">
            <SheetTitle className="sr-only">Menu</SheetTitle>
            <div className="mt-8 flex flex-col gap-1">
              {products && (
                <>
                  <Link to="/" className="mb-3 flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><House className="size-4 text-azure" />Home</Link>
                  <p className="eyebrow mb-2">Games</p>
                  {games.map((g) => <Link key={g.key} to={g.to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><img src={gameMenuImages[g.key]} alt="" width={28} height={28} loading="lazy" className="size-7 shrink-0 rounded-sm object-contain" />{g.name}</Link>)}
                  {productLinks.map((l) => <Link key={l.to} to={l.to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><l.icon className="size-4 text-azure" />{l.label}</Link>)}
                  <Link to="/" hash="locations" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><MapPin className="size-4 text-azure" />Locations</Link>
                  <div className="my-4 h-px bg-steel" />
                  <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><MessageCircle className="size-4 text-azure" />Discord</a>
                </>
              )}
              {user ? (
                <>
                  <p className="eyebrow mb-2 mt-4">Manage</p>
                  {accountLinks.map(({ to, label, icon: Icon }) => <Link key={to} to={to} className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><Icon className="size-4 text-azure" />{label}</Link>)}
                  {panelLinks.map(({ href, label, icon: Icon }) => <a key={label} href={href} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><Icon className="size-4 text-azure" />{label}</a>)}
                  {isAdmin && <Link to="/administrator" className="flex items-center gap-3 rounded-md px-2 py-2 text-foreground hover:bg-accent"><ShieldCheck className="size-4 text-azure" />Administrator</Link>}
                  <button type="button" onClick={() => void signOut()} className="flex items-center gap-3 rounded-md px-2 py-2 text-left text-foreground hover:bg-accent"><LogOut className="size-4 text-azure" />Sign out</button>
                </>
              ) : (
                <Link to="/auth" className={cn(btn(), "mt-4")}><LogIn />Log in</Link>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </nav>
    </header>
  );
}
