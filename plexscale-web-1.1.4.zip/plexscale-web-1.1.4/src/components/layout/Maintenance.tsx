import { Link } from "@tanstack/react-router";
import { MessageCircle, Wrench } from "lucide-react";
import { btn } from "@/components/ui-px/btn";
import { Spinner } from "@/components/ui-px/Spinner";
import { img } from "@/config/images";
import { site } from "@/config/site";
import { useSettings } from "@/hooks/use-settings";

/** Shown on every page to everyone except administrators while maintenance mode is on. */
export function MaintenanceScreen({ checking }: { checking?: boolean }) {
  const s = useSettings();
  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-16">
      <div className="glow-azure pointer-events-none absolute inset-0 opacity-70" />
      <div className="cross-grid pointer-events-none absolute inset-0 opacity-60" />
      <div className="panel animate-pop relative w-full max-w-lg p-10 text-center">
        <span className="mx-auto flex items-center justify-center gap-2.5">
          <img src={img.pmark} alt="" width={40} height={40} className="size-10 object-contain" />
          <span className="font-display text-2xl font-semibold">PlexScale</span>
        </span>
        <span className="mx-auto mt-8 grid size-16 place-items-center rounded-full border border-azure/40 bg-azure/10">
          {checking ? <Spinner size="sm" /> : <Wrench className="size-7 text-azure" />}
        </span>
        <h1 className="mt-6 text-3xl md:text-4xl">{s.maintenance.title || "We’ll be right back"}</h1>
        <p className="mt-4 text-muted-foreground">{s.maintenance.message || "PlexScale is undergoing scheduled maintenance."}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a href={site.statusUrl} target="_blank" rel="noopener noreferrer" className={btn()}>View status</a>
          <a href={s.discordUrl} target="_blank" rel="noopener noreferrer" className={btn({ variant: "secondary" })}><MessageCircle />Discord</a>
        </div>
        <p className="mt-8 text-xs text-muted-foreground">Staff member? <Link to="/auth" className="text-azure hover:underline">Sign in</Link></p>
      </div>
    </main>
  );
}
