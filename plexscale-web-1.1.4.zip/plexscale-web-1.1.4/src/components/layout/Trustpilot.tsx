import { site } from "@/config/site";
import { cn } from "@/lib/utils";

/** Trustpilot star mark (brand green). */
export function TrustpilotMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={cn("fill-trustpilot", className)}>
      <path d="M12 1.6l2.6 7.9h8.3l-6.7 4.9 2.6 7.9L12 17.4l-6.8 4.9 2.6-7.9L1.1 9.5h8.3z" />
    </svg>
  );
}

export function TrustpilotWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 font-display font-semibold text-foreground", className)}>
      <TrustpilotMark className="size-[1.15em]" />
      Trustpilot
    </span>
  );
}

/** Trustpilot-style rating: green squares with white stars, partial fill for decimals. */
export function TrustpilotStars({ score = site.trustpilotScore, size = "md", className }: { score?: number; size?: "sm" | "md" | "lg"; className?: string }) {
  const box = size === "lg" ? "size-9" : size === "sm" ? "size-6" : "size-7";
  const icon = size === "lg" ? "size-6" : size === "sm" ? "size-4" : "size-5";
  return (
    <span className={cn("flex gap-1", className)} role="img" aria-label={`Rated ${score} out of 5 on Trustpilot`}>
      {[0, 1, 2, 3, 4].map((i) => {
        const fill = Math.max(0, Math.min(1, score - i));
        const cls = fill >= 1 ? "tp-star" : fill <= 0 ? "tp-star-empty" : "tp-star-partial";
        return (
          <span key={i} className={cn("grid place-items-center rounded-[3px]", box, cls)} style={fill > 0 && fill < 1 ? ({ "--fill": `${Math.round(fill * 100)}%` } as React.CSSProperties) : undefined}>
            <svg viewBox="0 0 24 24" aria-hidden className={cn("fill-on-accent", icon)}><path d="M12 2.5l2.6 7.2h7.6l-6.1 4.5 2.3 7.3L12 17l-6.4 4.5 2.3-7.3-6.1-4.5h7.6z" /></svg>
          </span>
        );
      })}
    </span>
  );
}

export function TrustpilotLink({ className, children }: { className?: string; children: React.ReactNode }) {
  return <a href={site.trustpilotUrl} target="_blank" rel="noopener noreferrer" className={className}>{children}</a>;
}
