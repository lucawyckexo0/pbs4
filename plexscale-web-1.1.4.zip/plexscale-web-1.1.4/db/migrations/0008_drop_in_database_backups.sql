-- 0008: remove the in-database backup and update machinery.
-- Backups now run outside the database (encrypted restic snapshots and the pre-upgrade archive),
-- and updates are applied by the server's own updater, so these tables and functions are unused.
-- Add-only: earlier migrations are never edited. Every statement is safe to re-run.

DROP FUNCTION IF EXISTS public.restore_system_backup(uuid, uuid);
DROP FUNCTION IF EXISTS public.create_system_backup(uuid, text, text);
DROP FUNCTION IF EXISTS public.backup_tables();
DROP FUNCTION IF EXISTS public.restore_settings_backup(uuid, uuid);
DROP FUNCTION IF EXISTS public.create_settings_backup(uuid, text);

-- system_update_runs references system_backups, so it goes first.
DROP TABLE IF EXISTS public.system_update_runs;
DROP TABLE IF EXISTS public.system_backups;
DROP TABLE IF EXISTS public.settings_backups;
DROP TABLE IF EXISTS public.stack_update_runs;
