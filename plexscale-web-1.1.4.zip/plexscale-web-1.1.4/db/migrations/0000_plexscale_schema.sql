-- ========== Roles ==========
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  display_name text,
  avatar_url text,
  billing_name text,
  billing_phone text,
  billing_address text,
  gstin text,
  welcome_sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT profiles_display_name_len CHECK (display_name IS NULL OR char_length(display_name) <= 100),
  CONSTRAINT profiles_billing_name_len CHECK (billing_name IS NULL OR char_length(billing_name) <= 100),
  CONSTRAINT profiles_billing_phone_fmt CHECK (billing_phone IS NULL OR billing_phone ~ '^[0-9+() -]{6,20}$'),
  CONSTRAINT profiles_billing_address_len CHECK (billing_address IS NULL OR char_length(billing_address) <= 300),
  CONSTRAINT profiles_gstin_fmt CHECK (gstin IS NULL OR gstin ~ '^[0-9]{2}[A-Z0-9]{13}$')
);
GRANT SELECT ON public.profiles TO authenticated;
GRANT UPDATE (display_name, billing_name, billing_phone, billing_address, gstin, updated_at) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users read own profile" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Admins read profiles" ON public.profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name, avatar_url)
  VALUES (
    NEW.id,
    lower(NEW.email),
    left(coalesce(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'user_name', split_part(coalesce(NEW.email, ''), '@', 1)), 100),
    left(NEW.raw_user_meta_data->>'avatar_url', 500)
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.handle_user_email_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    UPDATE public.profiles SET email = lower(NEW.email), updated_at = now() WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_email_changed AFTER UPDATE OF email ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_user_email_change();

-- ========== Coupons ==========
-- Server only: customers never read this table directly, so codes cannot be listed.
CREATE TABLE public.coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE CHECK (code ~ '^[A-Z0-9_-]{3,32}$'),
  kind text NOT NULL CHECK (kind IN ('percent', 'fixed')),
  value integer NOT NULL CHECK (value > 0),
  max_discount integer CHECK (max_discount IS NULL OR max_discount > 0),
  min_amount integer NOT NULL DEFAULT 0 CHECK (min_amount >= 0),
  products text[] NOT NULL DEFAULT '{}',
  max_uses integer CHECK (max_uses IS NULL OR max_uses > 0),
  per_user_limit integer NOT NULL DEFAULT 1 CHECK (per_user_limit BETWEEN 1 AND 100),
  starts_at timestamptz,
  expires_at timestamptz,
  active boolean NOT NULL DEFAULT true,
  note text CHECK (note IS NULL OR char_length(note) <= 200),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT coupons_percent_max CHECK (kind <> 'percent' OR value <= 100),
  CONSTRAINT coupons_window CHECK (starts_at IS NULL OR expires_at IS NULL OR expires_at > starts_at)
);
GRANT ALL ON public.coupons TO service_role;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

-- ========== Orders ==========
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind text NOT NULL DEFAULT 'new' CHECK (kind IN ('new', 'renewal', 'upgrade')),
  parent_order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  product text NOT NULL,
  plan_id text NOT NULL,
  plan_name text NOT NULL,
  billing text NOT NULL,
  location text NOT NULL,
  amount integer NOT NULL CHECK (amount > 0),
  coupon_id uuid REFERENCES public.coupons(id) ON DELETE SET NULL,
  discount integer NOT NULL DEFAULT 0 CHECK (discount >= 0),
  server_name text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  software text,
  version text,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  cpu_percent integer,
  ram_mb integer,
  disk_mb integer,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'provisioning', 'active', 'suspended', 'cancelled', 'refunded', 'failed', 'renewed', 'upgraded')),
  razorpay_order_id text UNIQUE,
  razorpay_payment_id text UNIQUE,
  paid_at timestamptz,
  renews_at timestamptz,
  refunded_at timestamptz,
  ptero_server_id integer,
  ptero_identifier text,
  server_deleted_at timestamptz,
  provision_error text,
  provision_attempts integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT orders_billing_check CHECK (billing IN ('monthly', 'quarterly', 'semiannual', 'yearly'))
);
CREATE INDEX orders_user_idx ON public.orders (user_id, created_at DESC);
CREATE INDEX orders_status_renews_idx ON public.orders (status, renews_at);
CREATE INDEX orders_parent_idx ON public.orders (parent_order_id);
CREATE INDEX orders_coupon_idx ON public.orders (coupon_id) WHERE coupon_id IS NOT NULL;
GRANT SELECT ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own orders" ON public.orders FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read orders" ON public.orders FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.refunds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL UNIQUE REFERENCES public.orders(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'approved', 'rejected', 'paid')),
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT refunds_reason_len CHECK (char_length(reason) BETWEEN 5 AND 500),
  CONSTRAINT refunds_note_len CHECK (admin_note IS NULL OR char_length(admin_note) <= 300)
);
CREATE INDEX refunds_user_idx ON public.refunds (user_id);
GRANT SELECT ON public.refunds TO authenticated;
GRANT ALL ON public.refunds TO service_role;
ALTER TABLE public.refunds ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own refunds" ON public.refunds FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read refunds" ON public.refunds FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number bigint GENERATED ALWAYS AS IDENTITY (START WITH 1001) UNIQUE,
  order_id uuid NOT NULL UNIQUE REFERENCES public.orders(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  amount integer NOT NULL,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  issued_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX invoices_user_idx ON public.invoices (user_id, issued_at DESC);
GRANT SELECT ON public.invoices TO authenticated;
GRANT ALL ON public.invoices TO service_role;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own invoices" ON public.invoices FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read invoices" ON public.invoices FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ========== Settings ==========
CREATE TABLE public.site_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_settings TO anon, authenticated;
GRANT ALL ON public.site_settings TO service_role;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads public site settings" ON public.site_settings FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.panel_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.panel_settings TO service_role;
ALTER TABLE public.panel_settings ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.email_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.email_settings TO service_role;
ALTER TABLE public.email_settings ENABLE ROW LEVEL SECURITY;

INSERT INTO public.site_settings (id, data) VALUES (1, '{}'::jsonb);
INSERT INTO public.panel_settings (id, data) VALUES (1, '{}'::jsonb);
INSERT INTO public.email_settings (id, data) VALUES (1, '{}'::jsonb);

-- ========== Logs ==========
CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid,
  action text NOT NULL,
  target text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip text,
  scope text NOT NULL DEFAULT 'system',
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT audit_log_scope_check CHECK (scope IN ('system', 'admin')),
  CONSTRAINT audit_log_ip_len CHECK (ip IS NULL OR length(ip) <= 45)
);
CREATE INDEX audit_log_created_idx ON public.audit_log (created_at DESC);
CREATE INDEX audit_log_scope_created_idx ON public.audit_log (scope, created_at DESC);
-- Append-only for the app: rows can be added and read, never edited or removed.
GRANT SELECT, INSERT ON public.audit_log TO service_role;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Keeps only the newest 100 admin activity rows (runs as the table owner).
CREATE OR REPLACE FUNCTION public.trim_admin_activity()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.audit_log
  WHERE id IN (
    SELECT id FROM public.audit_log WHERE scope = 'admin'
    ORDER BY created_at DESC, id DESC OFFSET 100
  );
  RETURN NULL;
END;
$$;
REVOKE ALL ON FUNCTION public.trim_admin_activity() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER audit_log_trim_admin
AFTER INSERT ON public.audit_log
FOR EACH ROW WHEN (NEW.scope = 'admin')
EXECUTE FUNCTION public.trim_admin_activity();

CREATE TABLE public.email_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dedupe_key text NOT NULL UNIQUE,
  kind text NOT NULL,
  user_id uuid,
  order_id uuid,
  recipient text,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed', 'skipped')),
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX email_events_created_idx ON public.email_events (created_at DESC);
GRANT ALL ON public.email_events TO service_role;
ALTER TABLE public.email_events ENABLE ROW LEVEL SECURITY;

-- ========== Support tickets ==========
CREATE TABLE public.support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number bigint GENERATED ALWAYS AS IDENTITY (START WITH 10001) UNIQUE,
  user_id uuid NOT NULL,
  subject text NOT NULL CHECK (char_length(subject) BETWEEN 3 AND 120),
  category text NOT NULL CHECK (category IN ('technical', 'billing', 'sales', 'abuse', 'other')),
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'answered', 'customer_reply', 'closed')),
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  user_last_read_at timestamptz NOT NULL DEFAULT now(),
  staff_last_read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX support_tickets_user_idx ON public.support_tickets (user_id, last_message_at DESC);
CREATE INDEX support_tickets_status_idx ON public.support_tickets (status, last_message_at DESC);
GRANT SELECT ON public.support_tickets TO authenticated;
GRANT ALL ON public.support_tickets TO service_role;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own tickets" ON public.support_tickets FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  author_id uuid,
  is_staff boolean NOT NULL DEFAULT false,
  is_internal boolean NOT NULL DEFAULT false,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 5000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ticket_messages_ticket_idx ON public.ticket_messages (ticket_id, created_at);
GRANT SELECT ON public.ticket_messages TO authenticated;
GRANT ALL ON public.ticket_messages TO service_role;
ALTER TABLE public.ticket_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own ticket messages" ON public.ticket_messages FOR SELECT TO authenticated
  USING (NOT is_internal AND EXISTS (SELECT 1 FROM public.support_tickets t WHERE t.id = ticket_id AND t.user_id = auth.uid()));

-- ========== Panel alerts ==========
CREATE TABLE public.panel_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  support_id text NOT NULL UNIQUE CHECK (support_id ~ '^[A-HJ-NP-Z2-9]{6}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  count integer NOT NULL DEFAULT 1 CHECK (count >= 1),
  action text NOT NULL CHECK (action IN ('provision', 'upgrade_resize', 'renewal_unsuspend', 'suspend', 'reserve_ports', 'delete')),
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  user_id uuid,
  user_email text,
  product text,
  http_status integer,
  panel_code text CHECK (panel_code IS NULL OR char_length(panel_code) <= 120),
  panel_detail text CHECK (panel_detail IS NULL OR char_length(panel_detail) <= 1000),
  raw text CHECK (raw IS NULL OR char_length(raw) <= 4000),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
  resolved_by uuid,
  resolved_at timestamptz
);
CREATE UNIQUE INDEX panel_alerts_open_order_action ON public.panel_alerts (order_id, action) WHERE status = 'open';
CREATE INDEX panel_alerts_status_seen_idx ON public.panel_alerts (status, last_seen_at DESC);
GRANT SELECT ON public.panel_alerts TO authenticated;
GRANT UPDATE (status, resolved_by, resolved_at) ON public.panel_alerts TO authenticated;
GRANT ALL ON public.panel_alerts TO service_role;
ALTER TABLE public.panel_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read panel alerts" ON public.panel_alerts FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update panel alerts" ON public.panel_alerts FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- One open alert per order and action: repeats bump the count and keep the same Support ID.
CREATE OR REPLACE FUNCTION public.record_panel_alert(
  _support_id text, _action text, _order_id uuid, _user_id uuid, _user_email text, _product text,
  _http_status integer, _panel_code text, _panel_detail text, _raw text
) RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE sid text;
BEGIN
  IF _order_id IS NOT NULL THEN
    UPDATE public.panel_alerts
      SET count = count + 1, last_seen_at = now(), http_status = _http_status, panel_code = _panel_code, panel_detail = _panel_detail, raw = _raw
      WHERE order_id = _order_id AND action = _action AND status = 'open'
      RETURNING support_id INTO sid;
    IF sid IS NOT NULL THEN RETURN sid; END IF;
  END IF;
  INSERT INTO public.panel_alerts (support_id, action, order_id, user_id, user_email, product, http_status, panel_code, panel_detail, raw)
    VALUES (_support_id, _action, _order_id, _user_id, _user_email, _product, _http_status, _panel_code, _panel_detail, _raw)
    ON CONFLICT (order_id, action) WHERE status = 'open'
    DO UPDATE SET count = public.panel_alerts.count + 1, last_seen_at = now()
    RETURNING support_id INTO sid;
  RETURN sid;
END;
$$;
REVOKE ALL ON FUNCTION public.record_panel_alert(text, text, uuid, uuid, text, text, integer, text, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.record_panel_alert(text, text, uuid, uuid, text, text, integer, text, text, text) TO service_role;

-- ========== Payment webhooks (replay protection) ==========
CREATE TABLE public.webhook_events (
  event_id text PRIMARY KEY CHECK (char_length(event_id) BETWEEN 1 AND 100),
  event text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.webhook_events TO service_role;
ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;

-- ========== Rate limits ==========
CREATE TABLE public.rate_limits (
  key text NOT NULL CHECK (char_length(key) <= 200),
  window_start timestamptz NOT NULL,
  count integer NOT NULL DEFAULT 1,
  PRIMARY KEY (key, window_start)
);
GRANT ALL ON public.rate_limits TO service_role;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

-- Counts one hit in the current fixed window; true while the caller is within the limit.
CREATE OR REPLACE FUNCTION public.hit_rate_limit(_key text, _limit integer, _window_seconds integer)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE c integer;
BEGIN
  INSERT INTO public.rate_limits (key, window_start, count)
    VALUES (_key, to_timestamp(floor(extract(epoch FROM now()) / _window_seconds) * _window_seconds), 1)
    ON CONFLICT (key, window_start) DO UPDATE SET count = public.rate_limits.count + 1
    RETURNING count INTO c;
  RETURN c <= _limit;
END;
$$;
REVOKE ALL ON FUNCTION public.hit_rate_limit(text, integer, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.hit_rate_limit(text, integer, integer) TO service_role;

-- ========== Money-critical functions ==========
-- Applies a coupon to a fresh unpaid order in one transaction. The coupon row is locked so
-- concurrent checkouts can never exceed the use limits.
CREATE OR REPLACE FUNCTION public.apply_coupon(_order_id uuid, _code text)
RETURNS TABLE (new_amount integer, discount integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  o public.orders%ROWTYPE;
  c public.coupons%ROWTYPE;
  used integer;
  mine integer;
  d integer;
BEGIN
  SELECT * INTO o FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR o.kind <> 'new' OR o.status <> 'pending' OR o.coupon_id IS NOT NULL OR o.razorpay_order_id IS NOT NULL THEN
    RAISE EXCEPTION 'coupon_order_invalid';
  END IF;
  SELECT * INTO c FROM public.coupons WHERE code = upper(btrim(_code)) FOR UPDATE;
  IF NOT FOUND OR NOT c.active THEN RAISE EXCEPTION 'coupon_invalid'; END IF;
  IF c.starts_at IS NOT NULL AND now() < c.starts_at THEN RAISE EXCEPTION 'coupon_not_started'; END IF;
  IF c.expires_at IS NOT NULL AND now() >= c.expires_at THEN RAISE EXCEPTION 'coupon_expired'; END IF;
  IF cardinality(c.products) > 0 AND NOT (o.product = ANY (c.products)) THEN RAISE EXCEPTION 'coupon_product'; END IF;
  IF o.amount < c.min_amount THEN RAISE EXCEPTION 'coupon_min_amount'; END IF;
  SELECT count(*) INTO used FROM public.orders WHERE coupon_id = c.id AND status <> 'failed';
  IF c.max_uses IS NOT NULL AND used >= c.max_uses THEN RAISE EXCEPTION 'coupon_used_up'; END IF;
  SELECT count(*) INTO mine FROM public.orders WHERE coupon_id = c.id AND user_id = o.user_id AND status <> 'failed';
  IF mine >= c.per_user_limit THEN RAISE EXCEPTION 'coupon_already_used'; END IF;
  d := CASE WHEN c.kind = 'percent' THEN floor(o.amount * c.value / 100.0)::integer ELSE c.value END;
  IF c.max_discount IS NOT NULL THEN d := least(d, c.max_discount); END IF;
  d := least(d, o.amount - 1);
  IF d <= 0 THEN RAISE EXCEPTION 'coupon_no_discount'; END IF;
  UPDATE public.orders SET coupon_id = c.id, discount = d, amount = o.amount - d WHERE id = o.id;
  RETURN QUERY SELECT o.amount - d, d;
END;
$$;
REVOKE ALL ON FUNCTION public.apply_coupon(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_coupon(uuid, text) TO service_role;

-- Extends a service's paid period atomically, so two renewals paid at once both count.
CREATE OR REPLACE FUNCTION public.extend_service(_order_id uuid, _months integer)
RETURNS timestamptz
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE until timestamptz;
BEGIN
  IF _months NOT IN (1, 3, 6, 12) THEN RAISE EXCEPTION 'invalid_period'; END IF;
  UPDATE public.orders
    SET renews_at = greatest(coalesce(renews_at, now()), now()) + make_interval(months => _months)
    WHERE id = _order_id AND kind = 'new' AND status IN ('active', 'suspended')
    RETURNING renews_at INTO until;
  RETURN until;
END;
$$;
REVOKE ALL ON FUNCTION public.extend_service(uuid, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.extend_service(uuid, integer) TO service_role;

-- ========== updated_at ==========
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public
AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER orders_touch BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER refunds_touch BEFORE UPDATE ON public.refunds FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tickets_touch BEFORE UPDATE ON public.support_tickets FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER email_events_touch BEFORE UPDATE ON public.email_events FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER coupons_touch BEFORE UPDATE ON public.coupons FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
