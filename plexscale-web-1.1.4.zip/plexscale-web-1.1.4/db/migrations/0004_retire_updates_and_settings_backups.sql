DROP FUNCTION IF EXISTS public.restore_settings_backup(uuid, uuid);
DROP FUNCTION IF EXISTS public.create_settings_backup(uuid, text);
DROP FUNCTION IF EXISTS public.set_maintenance_enabled(boolean);
DELETE FROM public.settings_backups;
DELETE FROM public.stack_update_runs;
REVOKE ALL ON public.settings_backups FROM anon, authenticated;
REVOKE ALL ON public.stack_update_runs FROM anon, authenticated;
COMMENT ON TABLE public.settings_backups IS 'DEPRECATED: Updates section and settings backups removed; table is unused and empty.';
COMMENT ON TABLE public.stack_update_runs IS 'DEPRECATED: Updates section removed; table is unused and empty.';
