-- ========== PlexScale Credits ==========
-- Prepaid balance in whole rupees (1 credit = ₹1). Customers top up through Razorpay and can pay for
-- new services, renewals and upgrades from their balance. Every change is one SECURITY DEFINER function
-- call that locks the wallet row, so balances can never go negative or be spent twice.

-- Top-ups reuse the orders table so the webhook, payment verification, reconcile job and invoices all apply.
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_kind_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_kind_check CHECK (kind IN ('new', 'renewal', 'upgrade', 'credits'));
--> statement-breakpoint
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_status_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_status_check CHECK (status IN ('pending', 'provisioning', 'active', 'suspended', 'cancelled', 'refunded', 'failed', 'renewed', 'upgraded', 'credited'));
--> statement-breakpoint
ALTER TABLE public.orders DROP CONSTRAINT IF EXISTS orders_billing_check;
ALTER TABLE public.orders ADD CONSTRAINT orders_billing_check CHECK (billing IN ('monthly', 'quarterly', 'semiannual', 'yearly', 'once'));
ALTER TABLE public.orders ADD CONSTRAINT orders_credits_shape CHECK ((kind = 'credits') = (billing = 'once'));
--> statement-breakpoint
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS paid_with text NOT NULL DEFAULT 'razorpay';
ALTER TABLE public.orders ADD CONSTRAINT orders_paid_with_check CHECK (paid_with IN ('razorpay', 'credits'));
ALTER TABLE public.orders ADD CONSTRAINT orders_credits_not_with_credits CHECK (NOT (kind = 'credits' AND paid_with = 'credits'));
CREATE INDEX IF NOT EXISTS orders_credit_pending_idx ON public.orders (created_at) WHERE status = 'pending' AND paid_with = 'credits';
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS public.credit_wallets (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance integer NOT NULL DEFAULT 0 CHECK (balance >= 0 AND balance <= 10000000),
  updated_at timestamptz NOT NULL DEFAULT now()
);
REVOKE ALL ON public.credit_wallets FROM anon, authenticated;
GRANT SELECT ON public.credit_wallets TO authenticated;
GRANT ALL ON public.credit_wallets TO service_role;
ALTER TABLE public.credit_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own wallet" ON public.credit_wallets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read wallets" ON public.credit_wallets FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

-- Append-only ledger: rows are only ever added by the functions below.
CREATE TABLE IF NOT EXISTS public.credit_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount integer NOT NULL CHECK (amount <> 0 AND amount BETWEEN -10000000 AND 10000000),
  balance_after integer NOT NULL CHECK (balance_after >= 0),
  kind text NOT NULL CHECK (kind IN ('topup', 'spend', 'refund', 'admin_grant', 'admin_deduct')),
  order_id uuid REFERENCES public.orders(id) ON DELETE SET NULL,
  note text CHECK (note IS NULL OR char_length(note) <= 200),
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT credit_transactions_sign CHECK (
    (kind IN ('topup', 'refund', 'admin_grant') AND amount > 0) OR (kind IN ('spend', 'admin_deduct') AND amount < 0)
  )
);
CREATE UNIQUE INDEX IF NOT EXISTS credit_transactions_order_kind ON public.credit_transactions (order_id, kind) WHERE order_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS credit_transactions_user_idx ON public.credit_transactions (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS credit_transactions_created_idx ON public.credit_transactions (created_at DESC);
REVOKE ALL ON public.credit_transactions FROM anon, authenticated;
GRANT SELECT ON public.credit_transactions TO authenticated;
GRANT SELECT, INSERT ON public.credit_transactions TO service_role;
ALTER TABLE public.credit_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own credit transactions" ON public.credit_transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins read credit transactions" ON public.credit_transactions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

-- Adds a paid Razorpay top-up to the wallet exactly once. Returns the new balance, or NULL when already applied.
CREATE OR REPLACE FUNCTION public.credit_topup(_order_id uuid, _payment_id text)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE o public.orders%ROWTYPE; nb integer;
BEGIN
  IF _payment_id IS NULL OR _payment_id !~ '^pay_[A-Za-z0-9]{6,40}$' THEN RAISE EXCEPTION 'credits_payment_invalid'; END IF;
  UPDATE public.orders
     SET status = 'credited', razorpay_payment_id = _payment_id, paid_at = now()
   WHERE id = _order_id AND kind = 'credits' AND status IN ('pending', 'failed') AND razorpay_payment_id IS NULL
   RETURNING * INTO o;
  IF NOT FOUND THEN RETURN NULL; END IF;
  INSERT INTO public.credit_wallets (user_id, balance) VALUES (o.user_id, o.amount)
    ON CONFLICT (user_id) DO UPDATE SET balance = public.credit_wallets.balance + EXCLUDED.balance, updated_at = now()
    RETURNING balance INTO nb;
  INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind, order_id, note)
    VALUES (o.user_id, o.amount, nb, 'topup', o.id, 'Razorpay top-up');
  RETURN nb;
END;
$$;
REVOKE ALL ON FUNCTION public.credit_topup(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.credit_topup(uuid, text) TO service_role;
--> statement-breakpoint

-- Pays a fresh unpaid order from the customer's balance. Locks the order and the wallet; raises when the
-- order is not payable or the balance is too low. Returns the ledger row id used as the payment reference.
CREATE OR REPLACE FUNCTION public.spend_credits(_order_id uuid)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE o public.orders%ROWTYPE; w integer; tx uuid;
BEGIN
  SELECT * INTO o FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR o.kind NOT IN ('new', 'renewal', 'upgrade') OR o.status <> 'pending' OR o.paid_with <> 'razorpay'
     OR o.razorpay_payment_id IS NOT NULL OR o.razorpay_order_id IS NOT NULL OR o.amount <= 0 THEN
    RAISE EXCEPTION 'credits_order_invalid';
  END IF;
  SELECT balance INTO w FROM public.credit_wallets WHERE user_id = o.user_id FOR UPDATE;
  IF w IS NULL OR w < o.amount THEN RAISE EXCEPTION 'credits_insufficient'; END IF;
  UPDATE public.credit_wallets SET balance = balance - o.amount, updated_at = now() WHERE user_id = o.user_id;
  INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind, order_id, note)
    VALUES (o.user_id, -o.amount, w - o.amount, 'spend', o.id, left(o.kind || ': ' || o.plan_name, 200))
    RETURNING id INTO tx;
  UPDATE public.orders SET paid_with = 'credits' WHERE id = o.id;
  RETURN tx;
END;
$$;
REVOKE ALL ON FUNCTION public.spend_credits(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.spend_credits(uuid) TO service_role;
--> statement-breakpoint

-- Returns the amount of a credit-paid order to the customer's balance, once per order.
CREATE OR REPLACE FUNCTION public.refund_order_to_credits(_order_id uuid, _by uuid, _note text)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE o public.orders%ROWTYPE; nb integer;
BEGIN
  SELECT * INTO o FROM public.orders WHERE id = _order_id FOR UPDATE;
  IF NOT FOUND OR o.paid_with <> 'credits' OR o.razorpay_payment_id IS NULL OR o.paid_at IS NULL THEN RAISE EXCEPTION 'credits_refund_invalid'; END IF;
  IF EXISTS (SELECT 1 FROM public.credit_transactions WHERE order_id = o.id AND kind = 'refund') THEN RAISE EXCEPTION 'credits_refund_done'; END IF;
  INSERT INTO public.credit_wallets (user_id, balance) VALUES (o.user_id, o.amount)
    ON CONFLICT (user_id) DO UPDATE SET balance = public.credit_wallets.balance + EXCLUDED.balance, updated_at = now()
    RETURNING balance INTO nb;
  INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind, order_id, note, created_by)
    VALUES (o.user_id, o.amount, nb, 'refund', o.id, left(coalesce(_note, 'Refund to credits'), 200), _by);
  RETURN nb;
END;
$$;
REVOKE ALL ON FUNCTION public.refund_order_to_credits(uuid, uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.refund_order_to_credits(uuid, uuid, text) TO service_role;
--> statement-breakpoint

-- Administrator grant (positive) or deduction (negative). Deductions never take a balance below zero.
CREATE OR REPLACE FUNCTION public.admin_adjust_credits(_user_id uuid, _amount integer, _note text, _by uuid)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE w integer; nb integer;
BEGIN
  IF _amount IS NULL OR _amount = 0 OR abs(_amount) > 1000000 THEN RAISE EXCEPTION 'credits_amount_invalid'; END IF;
  IF _note IS NULL OR char_length(btrim(_note)) < 3 THEN RAISE EXCEPTION 'credits_note_required'; END IF;
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = _user_id) THEN RAISE EXCEPTION 'credits_user_unknown'; END IF;
  IF _amount > 0 THEN
    INSERT INTO public.credit_wallets (user_id, balance) VALUES (_user_id, _amount)
      ON CONFLICT (user_id) DO UPDATE SET balance = public.credit_wallets.balance + EXCLUDED.balance, updated_at = now()
      RETURNING balance INTO nb;
  ELSE
    SELECT balance INTO w FROM public.credit_wallets WHERE user_id = _user_id FOR UPDATE;
    IF w IS NULL OR w < -_amount THEN RAISE EXCEPTION 'credits_insufficient'; END IF;
    UPDATE public.credit_wallets SET balance = balance + _amount, updated_at = now() WHERE user_id = _user_id RETURNING balance INTO nb;
  END IF;
  INSERT INTO public.credit_transactions (user_id, amount, balance_after, kind, note, created_by)
    VALUES (_user_id, _amount, nb, CASE WHEN _amount > 0 THEN 'admin_grant' ELSE 'admin_deduct' END, left(btrim(_note), 200), _by);
  RETURN nb;
END;
$$;
REVOKE ALL ON FUNCTION public.admin_adjust_credits(uuid, integer, text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_adjust_credits(uuid, integer, text, uuid) TO service_role;
