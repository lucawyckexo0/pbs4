-- Flips only the maintenance switch inside site settings, without overwriting other sections.
CREATE OR REPLACE FUNCTION public.set_maintenance_enabled(_on boolean)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE was boolean;
BEGIN
  SELECT coalesce((data->'maintenance'->>'enabled')::boolean, false) INTO was FROM public.site_settings WHERE id = 1 FOR UPDATE;
  UPDATE public.site_settings
     SET data = coalesce(data, '{}'::jsonb) || jsonb_build_object('maintenance', coalesce(data->'maintenance', '{}'::jsonb) || jsonb_build_object('enabled', _on)),
         updated_at = now()
   WHERE id = 1;
  RETURN coalesce(was, false);
END;
$$;
REVOKE ALL ON FUNCTION public.set_maintenance_enabled(boolean) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.set_maintenance_enabled(boolean) TO service_role;
