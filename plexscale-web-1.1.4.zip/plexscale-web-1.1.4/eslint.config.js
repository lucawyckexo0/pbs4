import js from "@eslint/js";
import eslintPluginPrettier from "eslint-plugin-prettier/recommended";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist", ".output"] },
  {
    // Production server, migration runner and deploy helpers: plain Node.js modules.
    extends: [js.configs.recommended],
    files: ["**/*.mjs"],
    languageOptions: { ecmaVersion: 2024, sourceType: "module", globals: globals.node },
  },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "server-only",
              message:
                "TanStack Start does not use the Next.js `server-only` package. Rename the module to `*.server.ts` or mark it with `@tanstack/react-start/server-only`.",
            },
            {
              name: "@/integrations/supabase/client.server",
              message:
                "The service-role client bypasses security rules. Import it only from *.server.ts files, or load it inside a server handler with `await import(...)`.",
            },
          ],
        },
      ],
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
      "@typescript-eslint/no-unused-vars": "off",
    },
  },
  {
    // Server-only modules may use the service-role client directly.
    files: ["**/*.server.ts", "src/integrations/supabase/**"],
    rules: {
      "no-restricted-imports": [
        "error",
        { paths: [{ name: "server-only", message: "Use *.server.ts naming instead of the Next.js `server-only` package." }] },
      ],
    },
  },
  eslintPluginPrettier,
  // The codebase uses long single-line JSX; formatting is checked by `pnpm format`, not as lint errors.
  { rules: { "prettier/prettier": "off" } },
);
